# SolidDebris for Brick Rigs - installer. Run it with "Install.bat".
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$EXE = 'BrickRigsSteam-Win64-Shipping.exe'
function Finish($code) { Write-Host ''; Read-Host 'Press Enter to close' | Out-Null; exit $code }

Write-Host ''
Write-Host '  SolidDebris for Brick Rigs - installer' -ForegroundColor Cyan
Write-Host ''

if (-not (Test-Path (Join-Path $here 'ue4ss\UE4SS.dll'))) {
    Write-Host 'The mod files are not next to this installer.' -ForegroundColor Yellow
    Write-Host 'Extract the whole zip to a folder first (right-click the zip > Extract All), then run Install.bat from there.'
    Finish 1
}

# Find Brick Rigs through Steam's list of library folders.
function Find-Game {
    $roots = @()
    foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        try {
            $p = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($n in 'SteamPath', 'InstallPath') {
                if (($p.PSObject.Properties.Name -contains $n) -and $p.$n) { $roots += ($p.$n -replace '/', '\') }
            }
        } catch {}
    }
    $libs = @()
    foreach ($r in ($roots | Select-Object -Unique)) {
        $libs += $r
        foreach ($vdf in @((Join-Path $r 'steamapps\libraryfolders.vdf'), (Join-Path $r 'config\libraryfolders.vdf'))) {
            if (Test-Path $vdf) {
                foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
            }
        }
    }
    foreach ($l in ($libs | Select-Object -Unique)) {
        $w = Join-Path $l 'steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64'
        if (Test-Path (Join-Path $w $EXE)) { return $w }
    }
    return $null
}

$win64 = Find-Game
if (-not $win64) {
    Write-Host 'Could not find Brick Rigs automatically.' -ForegroundColor Yellow
    Write-Host 'In Steam: right-click Brick Rigs > Manage > Browse local files, copy the folder path from the address bar,'
    $typed = (Read-Host 'then paste it here and press Enter').Trim().Trim('"')
    foreach ($candidate in @($typed, (Join-Path $typed 'BrickRigs\Binaries\Win64'))) {
        if ($candidate -and (Test-Path (Join-Path $candidate $EXE))) { $win64 = $candidate }
    }
    if (-not $win64) { Write-Host 'That folder does not contain Brick Rigs. Nothing was changed.' -ForegroundColor Red; Finish 1 }
}
Write-Host "Brick Rigs found at: $win64"

if (Get-Process -Name 'BrickRigsSteam-Win64-Shipping' -ErrorAction SilentlyContinue) {
    Write-Host 'Brick Rigs is running. Close the game, then run Install.bat again. Nothing was changed.' -ForegroundColor Yellow
    Finish 1
}

try {
    $target = Join-Path $win64 'ue4ss'
    if (Test-Path (Join-Path $target 'UE4SS.dll')) {
        # A script loader is already installed: leave it and its other mods alone, just add this mod.
        Write-Host 'A UE4SS loader is already installed here - keeping it and adding SolidDebris to it.'
        Copy-Item -Path (Join-Path $here 'ue4ss\Mods\SolidDebris') -Destination (Join-Path $target 'Mods') -Recurse -Force
        $txt = Join-Path $target 'Mods\mods.txt'
        if ((Test-Path $txt) -and ((Get-Content $txt -Raw) -notmatch '(?m)^\s*SolidDebris\s*:')) {
            [IO.File]::WriteAllText($txt, "SolidDebris : 1`r`n" + (Get-Content $txt -Raw))
        }
        $json = Join-Path $target 'Mods\mods.json'
        if (Test-Path $json) {
            $list = @(Get-Content $json -Raw | ConvertFrom-Json)
            if (-not ($list | Where-Object { $_.mod_name -eq 'SolidDebris' })) {
                $list = @([pscustomobject]@{ mod_name = 'SolidDebris'; mod_enabled = $true }) + $list
                [IO.File]::WriteAllText($json, (ConvertTo-Json -InputObject $list -Depth 4))
            }
        }
    } else {
        Copy-Item -Path (Join-Path $here 'dwmapi.dll') -Destination $win64 -Force
        Copy-Item -Path (Join-Path $here 'ue4ss') -Destination $win64 -Recurse -Force
        [IO.File]::WriteAllText((Join-Path $target 'installed_by_SolidDebris.txt'), 'The UE4SS loader in this folder was installed by the SolidDebris installer.')
    }
} catch {
    Write-Host ''
    Write-Host "Could not copy the files: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'If it says access is denied: right-click Install.bat > Run as administrator.'
    Finish 1
}

Write-Host ''
Write-Host 'Installed.' -ForegroundColor Green
Write-Host 'Start Brick Rigs (the first start takes about a minute longer). Loose bricks are solid when YOU host.'
Write-Host 'Press 9 in game to switch the mod off/on. To remove it later, run Uninstall.bat.'
Finish 0
