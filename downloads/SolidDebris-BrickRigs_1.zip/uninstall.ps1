# SolidDebris for Brick Rigs - uninstaller. Run it with "Uninstall.bat".
$ErrorActionPreference = 'Stop'
$EXE = 'BrickRigsSteam-Win64-Shipping.exe'
function Finish($code) { Write-Host ''; Read-Host 'Press Enter to close' | Out-Null; exit $code }

Write-Host ''
Write-Host '  SolidDebris for Brick Rigs - uninstaller' -ForegroundColor Cyan
Write-Host ''

function Find-Game {
    $roots = @()
    foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        try {
            $p = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($n in 'SteamPath', 'InstallPath') {
                if (($p.PSObject.Properties.Name -contains $n) -and $p.$n) { $roots += ($p.$n -replace '/', '\') }
            }
        } catch {}
    }
    $libs = @()
    foreach ($r in ($roots | Select-Object -Unique)) {
        $libs += $r
        foreach ($vdf in @((Join-Path $r 'steamapps\libraryfolders.vdf'), (Join-Path $r 'config\libraryfolders.vdf'))) {
            if (Test-Path $vdf) {
                foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
            }
        }
    }
    foreach ($l in ($libs | Select-Object -Unique)) {
        $w = Join-Path $l 'steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64'
        if (Test-Path (Join-Path $w $EXE)) { return $w }
    }
    return $null
}

$win64 = Find-Game
if (-not $win64) {
    Write-Host 'Could not find Brick Rigs automatically.' -ForegroundColor Yellow
    $typed = (Read-Host 'Paste the Brick Rigs folder path (Steam > Brick Rigs > Manage > Browse local files) and press Enter').Trim().Trim('"')
    foreach ($candidate in @($typed, (Join-Path $typed 'BrickRigs\Binaries\Win64'))) {
        if ($candidate -and (Test-Path (Join-Path $candidate $EXE))) { $win64 = $candidate }
    }
    if (-not $win64) { Write-Host 'That folder does not contain Brick Rigs. Nothing was changed.' -ForegroundColor Red; Finish 1 }
}
Write-Host "Brick Rigs found at: $win64"
if (Get-Process -Name 'BrickRigsSteam-Win64-Shipping' -ErrorAction SilentlyContinue) {
    Write-Host 'Brick Rigs is running. Close the game, then run Uninstall.bat again. Nothing was changed.' -ForegroundColor Yellow
    Finish 1
}

$target = Join-Path $win64 'ue4ss'
$modDir = Join-Path $target 'Mods\SolidDebris'
if (-not (Test-Path $modDir)) { Write-Host 'SolidDebris is not installed here. Nothing was changed.'; Finish 0 }

try {
    Remove-Item -Path $modDir -Recurse -Force
    $marker = Join-Path $target 'installed_by_SolidDebris.txt'
    $others = @(Get-ChildItem -Path (Join-Path $target 'Mods') -Directory | Where-Object { $_.Name -notin @('shared', 'Keybinds') })
    if ((Test-Path $marker) -and ($others.Count -eq 0)) {
        # The loader came with this mod and nothing else uses it: take it out too.
        Remove-Item -Path $target -Recurse -Force
        Remove-Item -Path (Join-Path $win64 'dwmapi.dll') -Force -ErrorAction SilentlyContinue
        Write-Host 'Removed SolidDebris and the script loader that came with it.' -ForegroundColor Green
    } else {
        $txt = Join-Path $target 'Mods\mods.txt'
        if (Test-Path $txt) { [IO.File]::WriteAllText($txt, ((Get-Content $txt -Raw) -replace '(?m)^\s*SolidDebris\s*:.*\r?\n?', '')) }
        $json = Join-Path $target 'Mods\mods.json'
        if (Test-Path $json) {
            $list = @(Get-Content $json -Raw | ConvertFrom-Json | Where-Object { $_.mod_name -ne 'SolidDebris' })
            [IO.File]::WriteAllText($json, (ConvertTo-Json -InputObject $list -Depth 4))
        }
        Write-Host 'Removed SolidDebris. The script loader was left in place because other mods use it.' -ForegroundColor Green
    }
} catch {
    Write-Host "Could not remove the files: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'If it says access is denied: right-click Uninstall.bat > Run as administrator.'
    Finish 1
}
Finish 0
