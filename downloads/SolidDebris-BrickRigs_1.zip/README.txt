SolidDebris for Brick Rigs
==========================

What it does
  In multiplayer, bricks that break off a build normally let players walk straight through them.
  With this mod, loose bricks are solid again, like in singleplayer. When a chunk of a build breaks
  apart, the game's collapse sound and dust cloud also play briefly at that spot.

Who needs it
  The HOST of the session. Players joining a host who runs it do not need it, though they may see
  slight rubber-banding on loose bricks unless they install it too.

Install (easy way)
  1. Close Brick Rigs.
  2. Extract this whole zip to a folder (right-click the zip > Extract All).
  3. Double-click "Install.bat". It finds your Brick Rigs folder and copies the mod in.
     Windows may ask whether to run it because it came from the internet; choose Run / More info > Run anyway.
  4. Start the game. The first start takes about a minute longer than usual.

Install (by hand, if you prefer)
  1. Close Brick Rigs.
  2. In Steam: right-click Brick Rigs > Manage > Browse local files, then open BrickRigs > Binaries > Win64.
  3. Copy "dwmapi.dll" and the "ue4ss" folder from this zip into that Win64 folder
     (they sit next to BrickRigsSteam-Win64-Shipping.exe).

Use
  It is on automatically. Press 9 to switch it off/on; a chat line confirms the change
  (everyone in the session sees that line).

Remove
  Double-click "Uninstall.bat", or delete "dwmapi.dll" and the "ue4ss" folder from the Win64 folder by hand.

Good to know
  - This uses UE4SS, an unofficial script loader for Unreal Engine games (MIT licence, included).
    It is not made or supported by the Brick Rigs developers, and a game update can break it.
  - Made for Brick Rigs 1.11.8. If the game will not start after an update, remove the mod.
  - On very large wrecks, freshly broken pieces can take up to about 2 seconds to become solid.
  - The mod writes a small status.txt in ue4ss\Mods\SolidDebris showing what it has done.
