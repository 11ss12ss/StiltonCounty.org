# Stilton Mod Pack for Brick Rigs - uninstaller. Run it with "Uninstall.bat".
$ErrorActionPreference = 'Stop'
$MODS = @('SolidDebris', 'RealisticFire', 'StiltonCAD', 'Medical')
function Finish($code) { Write-Host ''; Read-Host 'Press Enter to close' | Out-Null; exit $code }

Write-Host ''
Write-Host '  Stilton Mod Pack for Brick Rigs - uninstaller' -ForegroundColor Cyan
Write-Host ''

# Is this the folder with the game's program in it? (the program name differs between copies of the game)
function Test-Win64($w) {
    if (-not $w -or -not (Test-Path -LiteralPath $w -PathType Container)) { return $false }
    return [bool](Get-ChildItem -LiteralPath $w -Filter 'BrickRigs*-Win64-Shipping.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1)
}

# Turn whatever folder the user pasted into the game's Binaries\Win64 folder.
# Accepts the game folder, the BrickRigs folder inside it, Binaries, Win64, or the path of a file in any of them.
function Resolve-Win64($typed) {
    if (-not $typed) { return $null }
    $p = $typed.Trim().Trim('"').Trim("'").Trim().TrimEnd('\', '/')
    if (-not $p) { return $null }
    if (Test-Path -LiteralPath $p -PathType Leaf) { $p = Split-Path -Parent $p }
    $dir = $p
    for ($i = 0; $i -lt 6 -and $dir; $i++) {
        foreach ($c in @($dir, (Join-Path $dir 'Win64'), (Join-Path $dir 'Binaries\Win64'), (Join-Path $dir 'BrickRigs\Binaries\Win64'))) {
            if (Test-Win64 $c) { return $c }
        }
        $dir = Split-Path -Parent $dir
    }
    return $null
}

# Find Brick Rigs through Steam's list of library folders, then the usual places on every drive.
function Find-Game {
    $roots = @()
    foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        try {
            $p = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($n in 'SteamPath', 'InstallPath') {
                if (($p.PSObject.Properties.Name -contains $n) -and $p.$n) { $roots += ($p.$n -replace '/', '\') }
            }
        } catch {}
    }
    $libs = @()
    foreach ($r in ($roots | Select-Object -Unique)) {
        $libs += $r
        foreach ($vdf in @((Join-Path $r 'steamapps\libraryfolders.vdf'), (Join-Path $r 'config\libraryfolders.vdf'))) {
            if (Test-Path -LiteralPath $vdf) {
                foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
            }
        }
    }
    try {
        foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction Stop)) {
            $root = $d.Root
            foreach ($sub in 'SteamLibrary', 'Steam', 'Games\Steam', 'Games\SteamLibrary', 'Program Files (x86)\Steam', 'Program Files\Steam') {
                $libs += (Join-Path $root $sub)
            }
        }
    } catch {}
    foreach ($l in ($libs | Select-Object -Unique)) {
        $w = Join-Path $l 'steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64'
        if (Test-Win64 $w) { return $w }
    }
    return $null
}

$win64 = Find-Game
while (-not $win64) {
    Write-Host 'Could not find Brick Rigs automatically.' -ForegroundColor Yellow
    Write-Host 'In Steam: right-click Brick Rigs > Manage > Browse local files, click the address bar at the top of'
    Write-Host 'that window, copy the folder path, then paste it here (right-click pastes) and press Enter.'
    Write-Host 'Leave it empty and press Enter to give up.'
    $typed = Read-Host 'Brick Rigs folder'
    if (-not $typed -or -not $typed.Trim()) { Write-Host 'Nothing was changed.'; Finish 1 }
    $win64 = Resolve-Win64 $typed
    if (-not $win64) { Write-Host "Brick Rigs is not in that folder: $typed" -ForegroundColor Red; Write-Host '' }
}
Write-Host "Brick Rigs found at: $win64"

if (Get-Process -Name 'BrickRigs*-Win64-Shipping' -ErrorAction SilentlyContinue) {
    Write-Host 'Brick Rigs is running. Close the game, then run Uninstall.bat again. Nothing was changed.' -ForegroundColor Yellow
    Finish 1
}

$target = Join-Path $win64 'ue4ss'
$found = @($MODS | Where-Object { Test-Path (Join-Path $target "Mods\$_") })
if ($found.Count -eq 0) { Write-Host 'The mod pack is not installed here. Nothing was changed.'; Finish 0 }

# The CAD's background helper keeps files open: stop it if it is still running.
try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*StiltonCAD*bridge.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}

try {
    foreach ($mod in $found) { Remove-Item -Path (Join-Path $target "Mods\$mod") -Recurse -Force }
    $markers = @((Join-Path $target 'installed_by_StiltonModPack.txt'), (Join-Path $target 'installed_by_SolidDebris.txt')) | Where-Object { Test-Path $_ }
    $others = @(Get-ChildItem -Path (Join-Path $target 'Mods') -Directory | Where-Object { $_.Name -notin @('shared', 'Keybinds') })
    if (($markers.Count -gt 0) -and ($others.Count -eq 0)) {
        # The loader came with this pack and nothing else uses it: take it out too.
        Remove-Item -Path $target -Recurse -Force
        Remove-Item -Path (Join-Path $win64 'dwmapi.dll') -Force -ErrorAction SilentlyContinue
        Write-Host 'Removed the mod pack and the script loader that came with it.' -ForegroundColor Green
    } else {
        $txt = Join-Path $target 'Mods\mods.txt'
        $json = Join-Path $target 'Mods\mods.json'
        foreach ($mod in $found) {
            if (Test-Path $txt) { [IO.File]::WriteAllText($txt, ((Get-Content $txt -Raw) -replace "(?m)^\s*$mod\s*:.*\r?\n?", '')) }
            if (Test-Path $json) {
                $list = @(Get-Content $json -Raw | ConvertFrom-Json | Where-Object { $_.mod_name -ne $mod })
                [IO.File]::WriteAllText($json, (ConvertTo-Json -InputObject $list -Depth 4))
            }
        }
        Write-Host 'Removed the mod pack. The script loader was left in place because other mods use it.' -ForegroundColor Green
    }
} catch {
    Write-Host "Could not remove the files: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'If it says access is denied: right-click Uninstall.bat > Run as administrator.'
    Finish 1
}
Finish 0
