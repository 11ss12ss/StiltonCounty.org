-- RealisticFire logic (re-read by main.lua whenever version.txt changes)
local DIR = RF.dir
local STATUS = DIR .. "..\\status.txt"
local VANILLA = { BurnMin = 10, BurnMax = 15, RoundsMin = 1, RoundsMax = 2, CooldownMin = 5, CooldownMax = 7.5, SpreadChance = 0.05, SpreadDistance = 50 }

RF.flames   = {}            -- flame effects already enlarged
RF.veh      = {}            -- builds and their bricks (reset on reload)
RF.stats    = RF.stats or { pulses = 0, scaled = 0 }
RF.seen     = {}            -- particle templates seen (for diagnostics)
RF.applied  = nil
RF.lastLog  = 0
RF.worst    = 0
RF.spray    = {}            -- address -> scale applied to extinguisher spray
RF.extApplied = nil
RF.matsApplied = nil
RF.burnQueue = {}           -- places where a brick has burned through and is about to give way
RF.columns  = RF.columns or {}   -- cell -> { psc, lastSeen } tall smoke columns over big fires
if RF.hudWidget then
    local old = RF.hudWidget
    RF.hudWidget, RF.hudText, RF.hudBroken = nil, nil, nil
    pcall(function() if old:IsValid() then old:RemoveFromParent() end end)
end

function RF.note(s)
    local f = io.open(STATUS, "a")
    if f then f:write(os.date() .. "  " .. s .. "\n") f:close() end
end

local okS, S = pcall(dofile, DIR .. "settings.lua")
if not okS or type(S) ~= "table" then RF.note("settings.lua could not be read: " .. tostring(S)) S = nil end
RF.S = S

local function fireInfo()
    local info = StaticFindObject("/Game/BrickRigs/Vehicles/BP_BrickVehicle_StaticInfo.Default__BP_BrickVehicle_StaticInfo_C")
    if info and info:IsValid() then return info end
    return nil
end

local function writeFire(info, v)
    info.BurnTimeRange.Min = v.BurnMin
    info.BurnTimeRange.Max = v.BurnMax
    info.NumBurnIntervalsRange.Min = v.RoundsMin
    info.NumBurnIntervalsRange.Max = v.RoundsMax
    info.ExtinguishCooldownRange.Min = v.CooldownMin
    info.ExtinguishCooldownRange.Max = v.CooldownMax
    info.FireSpreadProbability = v.SpreadChance
    info.FireSpreadDistance = v.SpreadDistance
end

local function applySettings(info)
    local want = RF.enabled and "realistic" or "vanilla"
    if RF.applied == want then return end
    writeFire(info, RF.enabled and S or VANILLA)
    RF.applied = want
    RF.note(string.format("fire settings now %s: burn %.0f-%.0fs, rounds %d-%d, spread chance %.2f, distance %.0f", want,
        info.BurnTimeRange.Min, info.BurnTimeRange.Max, info.NumBurnIntervalsRange.Min, info.NumBurnIntervalsRange.Max,
        info.FireSpreadProbability, info.FireSpreadDistance))
end

-- Extinguisher tuning. Normal mode: weaker than vanilla. Hose mode: long reach, wide, reliable.
local function tuneExtinguisher()
    local mode = RF.hose and "hose" or "weak"
    if RF.extApplied == mode then return end
    local ok, err = pcall(function()
        local info = RF.extInfo
        if not (info and info:IsValid()) then
            info = nil
            for _, item in ipairs(FindAllOf("FireExtinguisher") or {}) do
                if item:IsValid() then
                    local i = item:GetStaticInfo()
                    if i and i:IsValid() then info = i break end
                end
            end
            if not info then return end
            RF.extInfo = info
        end
        local p = info.ExtinguisherProperties
        RF.extVanilla = RF.extVanilla or { chance = p.ExtinguishProbability, radius = p.ExtinguishRadius, distance = p.ExtinguishDistance, start = info.ExtinguishStartDistance }
        local v = RF.extVanilla
        v.distance = v.distance or p.ExtinguishDistance          -- older versions of this mod never changed these two
        v.start = v.start or info.ExtinguishStartDistance
        if RF.hose then
            p.ExtinguishProbability = S.HoseChance
            p.ExtinguishRadius = v.radius * S.HoseRadiusMult
            p.ExtinguishDistance = v.distance * S.HoseDistanceMult
            info.ExtinguishStartDistance = v.start * S.HoseDistanceMult
        else
            p.ExtinguishProbability = v.chance * S.ExtinguishChanceMult
            p.ExtinguishRadius = v.radius * S.ExtinguishRadiusMult
            p.ExtinguishDistance = v.distance
            info.ExtinguishStartDistance = v.start
        end
        RF.extApplied = mode
        RF.note(string.format("extinguisher (%s): chance %.2f, radius %.0f, distance %.0f, start distance %.0f  [vanilla %.2f / %.0f / %.0f / %.0f]",
            mode, p.ExtinguishProbability, p.ExtinguishRadius, p.ExtinguishDistance, info.ExtinguishStartDistance, v.chance, v.radius, v.distance, v.start))
    end)
    if not ok and not RF.extErr then RF.extErr = true RF.note("extinguisher tuning failed: " .. tostring(err)) end
end

local SPRAY = "ParticleSystem /Game/BrickRigs/ParticleFX/Fire/P_FireExtinguisher.P_FireExtinguisher"

-- Fire hose. While someone sprays with the hose on, every burning brick in a cone in front of them
-- is put out directly (the extinguisher on its own only hits a few random bricks).
RF.sprays = {}
local function aimOf(c)
    local km = StaticFindObject("/Script/Engine.Default__KismetMathLibrary")
    local a = c:GetOwner()
    for _ = 1, 4 do
        if not (a and a:IsValid()) then break end
        local okR, rot = pcall(function() return a:GetBaseAimRotation() end)
        if okR and rot and rot.Pitch then
            local f = km:GetForwardVector(rot)
            if f and f.X then return { X = f.X, Y = f.Y, Z = f.Z } end
        end
        local nxt = nil
        pcall(function() nxt = a.Instigator end)
        if not (nxt and nxt:IsValid()) then pcall(function() nxt = a:GetOwner() end) end
        a = nxt
    end
    return nil
end
function RF.noteSpray(c)
    local okA, active = pcall(function() return c:IsActive() end)
    if not (okA and active) then return end
    local l = c:K2_GetComponentLocation()
    RF.sprays[#RF.sprays + 1] = { at = os.clock(), loc = { X = l.X, Y = l.Y, Z = l.Z }, dir = aimOf(c) }
end
function RF.hosePass()
    local t = os.clock()
    local live = {}
    for _, sp in ipairs(RF.sprays) do if t - sp.at < 1.0 then live[#live + 1] = sp end end
    RF.sprays = live
    if #live == 0 then return end
    local reach, width, spreadK = S.HoseReach or 1500.0, S.HoseWidth or 120.0, S.HoseConeSpread or 0.25
    local chance = S.HosePutOutChance or 0.6
    local out = 0
    for _, v in pairs(RF.veh) do
        for key, st in pairs(v.state) do
            local b = st.b
            if b and st.loc then
                for _, sp in ipairs(live) do
                    local dx, dy, dz = st.loc.X - sp.loc.X, st.loc.Y - sp.loc.Y, st.loc.Z - sp.loc.Z
                    local d2 = dx * dx + dy * dy + dz * dz
                    local hit = false
                    if d2 <= reach * reach then
                        if sp.dir then
                            local along = dx * sp.dir.X + dy * sp.dir.Y + dz * sp.dir.Z
                            if along > -50 then
                                local perp2 = d2 - along * along
                                local w = width + along * spreadK
                                hit = perp2 <= w * w
                            end
                        else
                            hit = d2 <= 400 * 400        -- no aim known: only close by
                        end
                    end
                    if hit then
                        if math.random() < chance and b:IsValid() then
                            pcall(function() b:ExtinguishFire() end)
                            v.state[key] = nil
                            out = out + 1
                        end
                        break
                    end
                end
            end
        end
    end
    if out > 0 then RF.stats.hosed = (RF.stats.hosed or 0) + out end
end

local function say(text)
    local ok, err = pcall(function()
        local msg = StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(text)
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then pc:SendChatMessage(1, msg) return end
        end
    end)
    if not ok then RF.note("chat notice failed: " .. tostring(err)) end
end

function RF.toggleHose()
    RF.hose = not RF.hose
    pcall(tuneExtinguisher)
    say("[RealisticFire] extinguisher is now " .. (RF.hose and "a FIRE HOSE (long reach)" or "a normal extinguisher"))
end

-- The on-screen "Fire" and "Hose" buttons (in the CAD mod) leave a command here; the state goes back
-- the same way, so the buttons can show it.
local CMD_FILE   = DIR .. "..\\command.txt"
local STATE_FILE = DIR .. "..\\state.txt"

local function writeState()
    local want = (RF.enabled and "on" or "off") .. "\nhose=" .. (RF.hose and "on" or "off") .. "\n"
    if RF.stateWritten == want then return end
    local f = io.open(STATE_FILE, "w")
    if f then f:write(want) f:close() RF.stateWritten = want end
end

local function readCommands()
    local f = io.open(CMD_FILE, "r")
    if not f then return end
    local s = f:read("*a") or ""
    f:close()
    os.remove(CMD_FILE)
    for line in s:gmatch("[^\r\n]+") do
        local c = line:match("^%s*(%a+)")
        if c == "toggle" and RF.toggle then pcall(RF.toggle)
        elseif c == "hose" then pcall(RF.toggleHose) end
    end
end

-- Write a marker the first time a feature is used, so a crash can be traced to it.
local function first(name)
    RF.firsts = RF.firsts or {}
    if not RF.firsts[name] then RF.firsts[name] = true RF.note("first use: " .. name) end
end

-- Per-material flammability: realistic values while the mod is on, the game's own when off.
local function applyMaterials()
    local want = RF.enabled and "realistic" or "vanilla"
    if RF.matsApplied == want then return end
    RF.matsApplied = want
    RF.matVanilla = RF.matVanilla or {}
    pcall(function()
        for _, m in ipairs(FindAllOf("BrickPhysicalMaterial") or {}) do
            if m:IsValid() then
                local name = m:GetFName():ToString()
                if RF.matVanilla[name] == nil then RF.matVanilla[name] = m.Flammability end
                local target = RF.matVanilla[name]
                if RF.enabled and S.Flammability and S.Flammability[name] ~= nil then target = S.Flammability[name] end
                if m.Flammability ~= target then
                    RF.note(string.format("material %s: flammability %.2f -> %.2f", name, m.Flammability, target))
                    m.Flammability = target
                end
            end
        end
    end)
end

-- Status line at the top of the screen.
local function hud(text)
    if not S.HudEnabled or RF.hudBroken then return end
    local ok, err = pcall(function()
        if not (RF.hudText and RF.hudText:IsValid() and RF.hudWidget and RF.hudWidget:IsValid()) then
            first("status line (creating widget)")
            local gi = FindFirstOf("BrickGameInstance")
            local w = StaticConstructObject(StaticFindObject("/Script/UMG.UserWidget"), gi)
            w.WidgetTree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
            -- the game's own text widget: plain engine text has no font in this game and draws nothing
            local tb = StaticConstructObject(StaticFindObject("/Script/BrickRigs.BrickTextBlock"), w.WidgetTree)
            pcall(function() tb:SetTextStyle(10) end)
            -- a widget added to the screen is stretched over all of it, so the root is an invisible
            -- full-screen box with the status line centred at the top inside it
            local screen = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), w.WidgetTree)
            local slot = screen:AddChildToVerticalBox(tb)
            slot:SetHorizontalAlignment(2)
            slot:SetPadding({ Left = 0.0, Top = 6.0, Right = 0.0, Bottom = 0.0 })
            w.WidgetTree.RootWidget = screen
            pcall(function() tb:SetTextStyle(3) end)
            pcall(function() tb:SetColorStyle(3) end)
            w:AddToViewport(50)
            pcall(function() w:SetVisibility(3) end)
            RF.hudWidget, RF.hudText, RF.hudShown = w, tb, nil
            first("status line (widget created)")
        end
        if RF.hudShown ~= text then
            RF.hudShown = text
            RF.hudText:SetText(StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(text))
        end
    end)
    if not ok then RF.hudBroken = true RF.note("status line failed, switched off: " .. tostring(err)) end
end

-- ---------------------------------------------------------------------------------------------
-- The fire logic works from the bricks themselves (is this brick on fire / burnt), not from the
-- flame effects: the game only draws flame effects near the camera, so they miss most of a fire.
-- The work is cut into small slices with a time limit, so it never holds up a frame for long.
-- ---------------------------------------------------------------------------------------------
RF.veh = RF.veh or {}        -- address -> record for every spawned build
RF.tickN = 0

local function refreshVehicles(now)
    if RF.vehAt and now - RF.vehAt < 4 then return end
    RF.vehAt = now
    local seen = {}
    for _, a in ipairs(FindAllOf("BrickVehicle") or {}) do
        if a:IsValid() then
            local k = a:GetAddress()
            local name = a:GetFName():ToString()
            seen[k] = true
            local v = RF.veh[k]
            if not v or v.name ~= name then
                RF.veh[k] = { actor = a, name = name, state = {}, done = {}, doneCount = 0, pos = 1, hot = false, burning = 0, cBurning = 0, cycle = 0 }
            end
        end
    end
    for k in pairs(RF.veh) do if not seen[k] then RF.veh[k] = nil end end
end

-- The brick list is fetched fresh at the start of every round, so it never points at bricks that are gone.
local function buildList(v)
    local arr = v.actor:GetBricks()
    local list = {}
    for i = 1, #arr do
        local okG, obj = pcall(function() return arr[i]:get() end)
        if okG and obj then list[#list + 1] = obj end
    end
    v.list, v.pos = list, 1
    v.cycle = v.cycle + 1
end

-- Look at bricks of one build until the time runs out, carrying on where the last slice stopped.
-- Returns true when it got through the whole build.
local function sweep(v, deadline, now, env)
    if not v.actor:IsValid() then return true end
    if not v.list then buildList(v) end
    local list = v.list
    local n = #list
    local cyc = v.cycle
    while v.pos <= n do
        if os.clock() >= deadline then return false end
        local b = list[v.pos]
        v.pos = v.pos + 1
        if b:IsValid() then
            local key = b:GetAddress()
            if not v.done[key] then
                if b:IsOnFire() then
                    v.cBurning = v.cBurning + 1
                    v.hot = true
                    local st = v.state[key]
                    if not st then
                        local l = b:GetWorldLocation()
                        st = { since = now, loc = { X = l.X, Y = l.Y, Z = l.Z } }
                        v.state[key] = st
                    end
                    st.cycle = cyc
                    st.b = b
                    v.cx = (v.cx or 0) + st.loc.X
                    v.cy = (v.cy or 0) + st.loc.Y
                    if not v.cz or st.loc.Z > v.cz then v.cz = st.loc.Z end
                    local ck = math.floor(st.loc.X / S.SmokeCellSize) .. ":" .. math.floor(st.loc.Y / S.SmokeCellSize)
                    local cell = env.cells[ck]
                    if not cell then cell = { n = 0, x = 0, y = 0, z = st.loc.Z } env.cells[ck] = cell end
                    cell.n = cell.n + 1
                    cell.x = cell.x + st.loc.X
                    cell.y = cell.y + st.loc.Y
                    if st.loc.Z > cell.z then cell.z = st.loc.Z end
                    -- fire climbs: light whatever is above this brick
                    if S.ClimbEnabled and RF.climbsThisSec < S.ClimbMaxPerPass
                       and now - st.since >= S.ClimbAfter and now - (st.lastClimb or 0) >= S.ClimbEvery then
                        st.lastClimb = now
                        RF.climbsThisSec = RF.climbsThisSec + 1
                        first("climb (SpreadFire)")
                        env.bs:SpreadFire(v.actor,
                            { Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 }, Translation = st.loc, Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 } },
                            { X = -S.ClimbWidth, Y = -S.ClimbWidth, Z = 0.0 }, { X = S.ClimbWidth, Y = S.ClimbWidth, Z = S.ClimbHeight },
                            S.ClimbDistance, S.ClimbChance)
                        RF.stats.climbs = (RF.stats.climbs or 0) + 1
                    end
                    -- fire weakens what it is burning
                    if S.WeakenEnabled and RF.pulsesThisSec < S.WeakenMaxPerPass
                       and (v.burning or 0) + (v.doneCount or 0) >= (S.StructuralMinFire or 0)
                       and now - st.since >= S.WeakenAfter and now - (st.lastHit or 0) >= S.WeakenEvery then
                        st.lastHit = now
                        RF.pulsesThisSec = RF.pulsesThisSec + 1
                        env.gs:ApplyRadialDamage(v.actor, S.WeakenDamage, st.loc, S.WeakenRadius, env.dmgType, {}, nil, nil, true, 0)
                        RF.stats.pulses = RF.stats.pulses + 1
                    end
                elseif b:IsBrickBurnt() then
                    -- burned out: this brick gives way
                    local st = v.state[key]
                    v.done[key] = true
                    v.state[key] = nil
                    -- Only a brick we saw burning for a long time has really burned through. A brick that was
                    -- put out (hose or extinguisher) is also marked burnt by the game: it stays, only charred.
                    local burnedLong = st and st.loc and (now - st.since) >= (S.BurnThroughMinBurn or 30)
                    if burnedLong then v.doneCount = v.doneCount + 1 end
                    v.queued = v.queued or 0
                    -- a small fire only chars bricks; a big one starts breaking the structure
                    if S.BurnThroughEnabled and burnedLong and #RF.burnQueue < 300
                       and v.queued < (S.BurnThroughMaxPerBuild or 80)
                       and (v.burning or 0) + (v.doneCount or 0) >= (S.StructuralMinFire or 0) then
                        v.queued = v.queued + 1
                        RF.burnQueue[#RF.burnQueue + 1] = { loc = st.loc, actor = v.actor }
                    end
                elseif v.state[key] then
                    v.state[key] = nil      -- put out before it burned through
                end
            end
        end
    end
    -- end of the round: publish the count, forget bricks that are gone, fetch a fresh list next time
    v.burning = v.cBurning
    if v.cBurning > 0 then v.fireX, v.fireY, v.fireZ = v.cx / v.cBurning, v.cy / v.cBurning, v.cz end
    v.cx, v.cy, v.cz = 0, 0, nil
    v.cBurning = 0
    v.hot = v.burning > 0
    for k, st in pairs(v.state) do if st.cycle ~= cyc then v.state[k] = nil end end
    v.list = nil
    return true
end

function RF.pass()
    if not S then return end
    local t0 = os.clock()
    RF.tickN = RF.tickN + 1
    local tick = RF.tickN
    if tick % 2 == 0 then readCommands() end     -- button presses, twice a second
    writeState()
    local info = fireInfo()
    if not info then return end
    applySettings(info)
    if not RF.enabled then applyMaterials() hud("Fire: vanilla (mod OFF)") return end
    -- looking for an extinguisher searches the whole game, so only do it now and then
    if RF.extApplied ~= (RF.hose and "hose" or "weak") and (tick % 20 == 1) then tuneExtinguisher() end
    applyMaterials()

    local now = os.time()
    if RF.secAt ~= now then RF.secAt, RF.climbsThisSec, RF.pulsesThisSec, RF.hitsThisSec = now, 0, 0, 0 end
    local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
    -- the game's own explosion damage is what breaks brick connections; plain damage barely does
    local dmgType = RF.dmgType
    if not (dmgType and dmgType:IsValid()) then
        dmgType = StaticFindObject("/Script/BrickRigs.DamageType_Explosion")
        if not (dmgType and dmgType:IsValid()) then dmgType = StaticFindObject("/Script/Engine.DamageType") end
        RF.dmgType = dmgType
        if not RF.dmgNoted then RF.dmgNoted = true RF.note("structural damage type: " .. dmgType:GetFullName()) end
    end
    RF.cells = RF.cells or {}
    local env = { cells = RF.cells, gs = gs, dmgType = dmgType,
                  bs = StaticFindObject("/Script/BrickRigs.Default__BrickStatics") }

    -- 1. Bricks: a few milliseconds per slice; builds that are burning get most of the time.
    local okW, errW = pcall(function()
        refreshVehicles(now)
        local hot, cold = {}, {}
        for _, v in pairs(RF.veh) do
            if v.hot then hot[#hot + 1] = v else cold[#cold + 1] = v end
        end
        local budget = S.SweepBudgetMs / 1000
        local tStart = os.clock()
        local hotEnd = tStart + ((#cold > 0) and budget * 0.75 or budget)
        if #hot > 0 then
            local share = (hotEnd - tStart) / #hot
            for i, v in ipairs(hot) do sweep(v, math.min(hotEnd, os.clock() + share), now, env) end
        end
        local deadline = tStart + budget
        if #cold > 0 and os.clock() < deadline then
            table.sort(cold, function(a, b) return a.name < b.name end)
            local tries = 0
            while os.clock() < deadline and tries < #cold do
                RF.coldI = ((RF.coldI or 0) % #cold) + 1
                if not sweep(cold[RF.coldI], deadline, now, env) then RF.coldI = RF.coldI - 1 break end
                tries = tries + 1
            end
        end
    end)
    if not okW and not RF.sweepErr then RF.sweepErr = true RF.note("ERROR in brick sweep: " .. tostring(errW)) end

    local burning, builds, burningBuilds, gaveWay = 0, 0, 0, 0
    for _, v in pairs(RF.veh) do
        builds = builds + 1
        local b = math.max(v.burning, v.cBurning)
        burning = burning + b
        if b > 0 then burningBuilds = burningBuilds + 1 end
        gaveWay = gaveWay + v.doneCount
    end

    -- 2. Burn-through: each burned-out brick takes one sharp, small hit that snaps its connections.
    if #RF.burnQueue > 0 then
        local okB, errB = pcall(function()
            local perSlice = math.max(1, math.ceil(S.BurnThroughMaxPerPass / 4))
            local nHit = 0
            while nHit < perSlice and RF.hitsThisSec < S.BurnThroughMaxPerPass and #RF.burnQueue > 0 do
                local item = table.remove(RF.burnQueue, 1)
                if item.actor:IsValid() then
                    nHit = nHit + 1
                    RF.hitsThisSec = RF.hitsThisSec + 1
                    first("burn-through (ApplyRadialDamage)")
                    gs:ApplyRadialDamage(item.actor, S.BurnThroughDamage, item.loc, S.BurnThroughRadius, dmgType, {}, nil, nil, true, 0)
                    RF.stats.burnt = (RF.stats.burnt or 0) + 1
                end
            end
        end)
        if not okB and not RF.burnErr then RF.burnErr = true RF.note("burn-through failed: " .. tostring(errB)) end
    end

    -- 2b. Fire hose: put out every burning brick in a cone in front of each active spray.
    if RF.hose and S.HoseDirect ~= false then
        local okH, errH = pcall(RF.hosePass)
        if not okH and not RF.hoseErr then RF.hoseErr = true RF.note("hose failed: " .. tostring(errH)) end
    end

    -- Everything below runs once a second at most.
    if tick % 4 ~= 0 then return end
    local cells = RF.cells
    RF.cells = {}
    if burning > 0 then RF.lastBurningAt = now end
    local fireNearby = RF.lastBurningAt and now - RF.lastBurningAt < 30

    -- 3. Flame effects near the camera: make them bigger and taller (host's screen only).
    --    Searching for effects is costly, so only while there is a fire, and every other second.
    if fireNearby and (tick % 8 == 0 or RF.hose) then
        local comps = FindAllOf("ParticleSystemComponent") or {}
        local fireName = nil
        pcall(function() fireName = info.FireEmitter:GetFullName() end)
        local alive = {}
        for _, c in ipairs(comps) do
            local okC, errC = pcall(function()
                if not c:IsValid() then return end
                local key = c:GetAddress()
                if RF.flames[key] then alive[key] = true return end
                local tpl = c.Template
                if not (tpl and tpl:IsValid()) then return end
                local name = tpl:GetFullName()
                if name == SPRAY then
                    if RF.hose then RF.noteSpray(c) end
                    local want = RF.hose and S.HoseSprayScale or 1.0
                    if RF.spray[key] ~= want then
                        RF.spray[key] = want
                        c:SetRelativeScale3D({ X = want, Y = want, Z = want })
                    end
                    return
                end
                if name ~= fireName then return end
                alive[key] = true
                if S.FlameScale ~= 1.0 or S.FlameScaleZ ~= 1.0 then
                    c:SetRelativeScale3D({ X = S.FlameScale, Y = S.FlameScale, Z = S.FlameScaleZ })
                    RF.stats.scaled = RF.stats.scaled + 1
                end
            end)
            if not okC and not RF.compErr then RF.compErr = true RF.note("ERROR handling a flame: " .. tostring(errC)) end
        end
        RF.flames = alive
    end

    -- 4. Automatic fire calls: a big fire that keeps burning is reported to the CAD helper, which
    --    files one SCFD call for it. Only the host does this, so the same fire is not reported twice.
    if S.AutoFireCalls then
        pcall(function()
            if RF.isHost == nil or tick % 40 == 0 then
                local okH, host = pcall(function()
                    local ks = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
                    for _, v in pairs(RF.veh) do if v.actor:IsValid() then return ks:IsServer(v.actor) end end
                    return nil
                end)
                if okH and host ~= nil then RF.isHost = host end
            end
            if not RF.isHost then return end
            for _, v in pairs(RF.veh) do
                if v.burning >= S.AutoFireMinBricks and v.fireX then
                    v.fireSince = v.fireSince or now
                    if now - v.fireSince >= S.AutoFireAfter and now - (v.fireReported or 0) >= S.AutoFireRepeat then
                        v.fireReported = now
                        local f = io.open(DIR .. "..\\..\\StiltonCAD\\fire_reports.txt", "a")
                        if f then
                            f:write(string.format("fire|%.0f|%.0f|%.0f|%d|%s|%d\n", v.fireX, v.fireY, v.fireZ or 0, v.burning, (v.name:gsub("[|\r\n]", " ")), now))
                            f:close()
                            RF.note(string.format("reported a fire to the CAD: %d bricks burning in %s", v.burning, v.name))
                        end
                    end
                elseif v.burning == 0 then
                    v.fireSince = nil
                end
            end
        end)
    end

    -- 5. Tall smoke column over each big fire (host's screen only).
    if S.SmokeColumnEnabled and not RF.smokeColBroken and (burning > 0 or next(RF.columns)) then
        local okS2, errS2 = pcall(function()
            local ctx = nil
            for _, v in pairs(RF.veh) do if v.actor:IsValid() then ctx = v.actor break end end
            local live = 0
            for ck, col in pairs(RF.columns) do
                local cell = cells[ck]
                if cell and cell.n >= 1 then col.lastSeen = now end
                if now - col.lastSeen >= S.SmokeLinger then
                    RF.columns[ck] = nil
                    pcall(function() if col.psc and col.psc:IsValid() then col.psc:Deactivate() end end)
                else
                    live = live + 1
                end
            end
            if not ctx then return end
            for ck, cell in pairs(cells) do
                if live >= S.SmokeMaxColumns then break end
                if cell.n >= S.SmokeMinFlames and not RF.columns[ck] then
                    local path = "/Game/BrickRigs/Buildings/PowerPlant/P_PowerPlant_Smoke.P_PowerPlant_Smoke"
                    local tpl = StaticFindObject(path)
                    if not (tpl and tpl:IsValid()) then
                        if RF.smokeLoadTried then return end
                        RF.smokeLoadTried = true             -- loading an asset stalls the game: only try once
                        pcall(function() LoadAsset(path) end)
                        tpl = StaticFindObject(path)
                    end
                    if not (tpl and tpl:IsValid()) then
                        RF.smokeColBroken = true
                        RF.note("smoke column effect is not available, switched off")
                        return
                    end
                    first("smoke column (SpawnEmitterAtLocation)")
                    local k = S.SmokeColumnScale
                    local psc = gs:SpawnEmitterAtLocation(ctx, tpl,
                        { X = cell.x / cell.n, Y = cell.y / cell.n, Z = cell.z + S.SmokeColumnLift },
                        { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }, { X = k, Y = k, Z = k }, true, 0, true)
                    RF.columns[ck] = { psc = psc, lastSeen = now }
                    RF.stats.columns = (RF.stats.columns or 0) + 1
                    live = live + 1
                end
            end
        end)
        if not okS2 then RF.smokeColBroken = true RF.note("smoke column failed, switched off: " .. tostring(errS2)) end
    end

    hud(string.format("Fire: REALISTIC   Tool: %s   Burning: %d", RF.hose and "FIRE HOSE" or "extinguisher", burning))
    local dt = (os.clock() - t0) * 1000
    if dt > RF.worst then RF.worst = dt end
    if now - RF.lastLog >= 15 and (burning > 0 or #RF.burnQueue > 0 or RF.lastCount ~= burning) then
        RF.lastLog = now
        RF.lastCount = burning
        RF.note(string.format("bricks on fire=%d in %d of %d builds, burned out=%d, hits done=%d (waiting %d), weakening pulses=%d, climb attempts=%d, smoke columns=%d, flames enlarged=%d, slice=%.1f ms (slowest %.1f ms)",
            burning, burningBuilds, builds, gaveWay, RF.stats.burnt or 0, #RF.burnQueue, RF.stats.pulses, RF.stats.climbs or 0, RF.stats.columns or 0, RF.stats.scaled, dt, RF.worst))
    end
end

function RF.toggle()
    RF.enabled = not RF.enabled
    local info = fireInfo()
    if info then pcall(applySettings, info) end
    if not RF.enabled then
        -- put flames and extinguisher back
        pcall(function()
            for _, c in ipairs(FindAllOf("ParticleSystemComponent") or {}) do
                if c:IsValid() and RF.flames[c:GetAddress()] then c:SetRelativeScale3D({ X = 1, Y = 1, Z = 1 }) end
            end
        end)
        RF.flames = {}
        RF.burnQueue = {}
        RF.veh = {}
        for ck, col in pairs(RF.columns) do
            pcall(function() if col.psc and col.psc:IsValid() then col.psc:Deactivate() end end)
        end
        RF.columns = {}
    end
    local ok, err = pcall(function()
        local msg = StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(
            "[RealisticFire] fire is now " .. (RF.enabled and "REALISTIC (mod ON)" or "vanilla (mod OFF)"))
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then pc:SendChatMessage(1, msg) return end
        end
    end)
    if not ok then RF.note("chat notice failed: " .. tostring(err)) end
end

RF.note("logic loaded (enabled=" .. tostring(RF.enabled) .. ", folder found automatically=" .. tostring(RF.dirAuto == true) .. ", folder=" .. tostring(DIR) .. ")")
