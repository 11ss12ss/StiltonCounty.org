-- RealisticFire logic (re-read by main.lua whenever version.txt changes)
local DIR = RF.dir
local STATUS = DIR .. "..\\status.txt"
local VANILLA = { BurnMin = 10, BurnMax = 15, RoundsMin = 1, RoundsMax = 2, CooldownMin = 5, CooldownMax = 7.5, SpreadChance = 0.05, SpreadDistance = 50 }

RF.flames   = {}            -- address -> { since, lastHit, scaled }
RF.stats    = RF.stats or { pulses = 0, scaled = 0 }
RF.seen     = {}            -- particle templates seen (for diagnostics)
RF.applied  = nil
RF.lastLog  = 0
RF.worst    = 0
RF.spray    = {}            -- address -> scale applied to extinguisher spray
RF.extApplied = nil
RF.matsApplied = nil
RF.burnQueue = {}           -- places where a brick has burned through and is about to give way
RF.columns  = RF.columns or {}   -- cell -> { psc, lastSeen } tall smoke columns over big fires
if RF.hudWidget then
    local old = RF.hudWidget
    RF.hudWidget, RF.hudText, RF.hudBroken = nil, nil, nil
    pcall(function() if old:IsValid() then old:RemoveFromParent() end end)
end

function RF.note(s)
    local f = io.open(STATUS, "a")
    if f then f:write(os.date() .. "  " .. s .. "\n") f:close() end
end

local okS, S = pcall(dofile, DIR .. "settings.lua")
if not okS or type(S) ~= "table" then RF.note("settings.lua could not be read: " .. tostring(S)) S = nil end
RF.S = S

local function fireInfo()
    local info = StaticFindObject("/Game/BrickRigs/Vehicles/BP_BrickVehicle_StaticInfo.Default__BP_BrickVehicle_StaticInfo_C")
    if info and info:IsValid() then return info end
    return nil
end

local function writeFire(info, v)
    info.BurnTimeRange.Min = v.BurnMin
    info.BurnTimeRange.Max = v.BurnMax
    info.NumBurnIntervalsRange.Min = v.RoundsMin
    info.NumBurnIntervalsRange.Max = v.RoundsMax
    info.ExtinguishCooldownRange.Min = v.CooldownMin
    info.ExtinguishCooldownRange.Max = v.CooldownMax
    info.FireSpreadProbability = v.SpreadChance
    info.FireSpreadDistance = v.SpreadDistance
end

local function applySettings(info)
    local want = RF.enabled and "realistic" or "vanilla"
    if RF.applied == want then return end
    writeFire(info, RF.enabled and S or VANILLA)
    RF.applied = want
    RF.note(string.format("fire settings now %s: burn %.0f-%.0fs, rounds %d-%d, spread chance %.2f, distance %.0f", want,
        info.BurnTimeRange.Min, info.BurnTimeRange.Max, info.NumBurnIntervalsRange.Min, info.NumBurnIntervalsRange.Max,
        info.FireSpreadProbability, info.FireSpreadDistance))
end

-- Extinguisher tuning. Normal mode: weaker than vanilla. Hose mode: long reach, wide, reliable.
local function tuneExtinguisher()
    local mode = RF.hose and "hose" or "weak"
    if RF.extApplied == mode then return end
    local ok, err = pcall(function()
        local info = RF.extInfo
        if not (info and info:IsValid()) then
            info = nil
            for _, item in ipairs(FindAllOf("FireExtinguisher") or {}) do
                if item:IsValid() then
                    local i = item:GetStaticInfo()
                    if i and i:IsValid() then info = i break end
                end
            end
            if not info then return end
            RF.extInfo = info
        end
        local p = info.ExtinguisherProperties
        RF.extVanilla = RF.extVanilla or { chance = p.ExtinguishProbability, radius = p.ExtinguishRadius, distance = p.ExtinguishDistance, start = info.ExtinguishStartDistance }
        local v = RF.extVanilla
        v.distance = v.distance or p.ExtinguishDistance          -- older versions of this mod never changed these two
        v.start = v.start or info.ExtinguishStartDistance
        if RF.hose then
            p.ExtinguishProbability = S.HoseChance
            p.ExtinguishRadius = v.radius * S.HoseRadiusMult
            p.ExtinguishDistance = v.distance * S.HoseDistanceMult
            info.ExtinguishStartDistance = v.start * S.HoseDistanceMult
        else
            p.ExtinguishProbability = v.chance * S.ExtinguishChanceMult
            p.ExtinguishRadius = v.radius * S.ExtinguishRadiusMult
            p.ExtinguishDistance = v.distance
            info.ExtinguishStartDistance = v.start
        end
        RF.extApplied = mode
        RF.note(string.format("extinguisher (%s): chance %.2f, radius %.0f, distance %.0f, start distance %.0f  [vanilla %.2f / %.0f / %.0f / %.0f]",
            mode, p.ExtinguishProbability, p.ExtinguishRadius, p.ExtinguishDistance, info.ExtinguishStartDistance, v.chance, v.radius, v.distance, v.start))
    end)
    if not ok and not RF.extErr then RF.extErr = true RF.note("extinguisher tuning failed: " .. tostring(err)) end
end

local SPRAY = "ParticleSystem /Game/BrickRigs/ParticleFX/Fire/P_FireExtinguisher.P_FireExtinguisher"

local function say(text)
    local ok, err = pcall(function()
        local msg = StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(text)
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then pc:SendChatMessage(1, msg) return end
        end
    end)
    if not ok then RF.note("chat notice failed: " .. tostring(err)) end
end

function RF.toggleHose()
    RF.hose = not RF.hose
    pcall(tuneExtinguisher)
    say("[RealisticFire] extinguisher is now " .. (RF.hose and "a FIRE HOSE (long reach)" or "a normal extinguisher"))
end

if not RF.hoseKeyBound then
    RF.hoseKeyBound = true
    RegisterKeyBind(Key.SEVEN, function()
        ExecuteInGameThread(function() pcall(RF.toggleHose) end)
    end)
end

-- Write a marker the first time a feature is used, so a crash can be traced to it.
local function first(name)
    RF.firsts = RF.firsts or {}
    if not RF.firsts[name] then RF.firsts[name] = true RF.note("first use: " .. name) end
end

-- Per-material flammability: realistic values while the mod is on, the game's own when off.
local function applyMaterials()
    local want = RF.enabled and "realistic" or "vanilla"
    if RF.matsApplied == want then return end
    RF.matsApplied = want
    RF.matVanilla = RF.matVanilla or {}
    pcall(function()
        for _, m in ipairs(FindAllOf("BrickPhysicalMaterial") or {}) do
            if m:IsValid() then
                local name = m:GetFName():ToString()
                if RF.matVanilla[name] == nil then RF.matVanilla[name] = m.Flammability end
                local target = RF.matVanilla[name]
                if RF.enabled and S.Flammability and S.Flammability[name] ~= nil then target = S.Flammability[name] end
                if m.Flammability ~= target then
                    RF.note(string.format("material %s: flammability %.2f -> %.2f", name, m.Flammability, target))
                    m.Flammability = target
                end
            end
        end
    end)
end

-- Status line at the top of the screen.
local function hud(text)
    if not S.HudEnabled or RF.hudBroken then return end
    local ok, err = pcall(function()
        if not (RF.hudText and RF.hudText:IsValid() and RF.hudWidget and RF.hudWidget:IsValid()) then
            first("status line (creating widget)")
            local gi = FindFirstOf("BrickGameInstance")
            local w = StaticConstructObject(StaticFindObject("/Script/UMG.UserWidget"), gi)
            w.WidgetTree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
            -- the game's own text widget: plain engine text has no font in this game and draws nothing
            local tb = StaticConstructObject(StaticFindObject("/Script/BrickRigs.BrickTextBlock"), w.WidgetTree)
            pcall(function() tb:SetTextStyle(10) end)
            -- a widget added to the screen is stretched over all of it, so the root is an invisible
            -- full-screen box with the status line centred at the top inside it
            local screen = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), w.WidgetTree)
            local slot = screen:AddChildToVerticalBox(tb)
            slot:SetHorizontalAlignment(2)
            slot:SetPadding({ Left = 0.0, Top = 6.0, Right = 0.0, Bottom = 0.0 })
            w.WidgetTree.RootWidget = screen
            pcall(function() tb:SetTextStyle(3) end)
            pcall(function() tb:SetColorStyle(3) end)
            w:AddToViewport(50)
            pcall(function() w:SetVisibility(3) end)
            RF.hudWidget, RF.hudText, RF.hudShown = w, tb, nil
            first("status line (widget created)")
        end
        if RF.hudShown ~= text then
            RF.hudShown = text
            RF.hudText:SetText(StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(text))
        end
    end)
    if not ok then RF.hudBroken = true RF.note("status line failed, switched off: " .. tostring(err)) end
end

function RF.pass()
    if not S then return end
    local t0 = os.clock()
    local info = fireInfo()
    if not info then return end
    applySettings(info)
    if not RF.enabled then applyMaterials() hud("Fire: vanilla (mod OFF)") return end
    tuneExtinguisher()
    applyMaterials()

    local fireName = nil
    pcall(function() fireName = info.FireEmitter:GetFullName() end)
    local now = os.time()
    local alive, pulses, count, climbs, idle = {}, 0, 0, 0, 0
    local cells = {}
    local bs = StaticFindObject("/Script/BrickRigs.Default__BrickStatics")
    local pulseLoc = nil
    local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
    local dmgType = StaticFindObject("/Script/Engine.DamageType")
    local comps = FindAllOf("ParticleSystemComponent") or {}
    for _, c in ipairs(comps) do
        local okC, errC = pcall(function()
            if not c:IsValid() then return end
            local tpl = c.Template
            if not (tpl and tpl:IsValid()) then return end
            local name = tpl:GetFullName()
            if not RF.seen[name] then RF.seen[name] = true RF.note("particle effect seen: " .. name) end
            if name == SPRAY then
                local want = RF.hose and S.HoseSprayScale or 1.0
                local k = c:GetAddress()
                if RF.spray[k] ~= want then
                    RF.spray[k] = want
                    c:SetRelativeScale3D({ X = want, Y = want, Z = want })
                end
                return
            end
            if name ~= fireName then return end
            -- the game keeps flame effects around after the fire is out; only ones that are really burning count
            local okA, isOn = pcall(function() return c:IsActive() end)
            if okA and isOn == false then idle = idle + 1 return end
            count = count + 1
            local key = c:GetAddress()
            local st = RF.flames[key] or { since = now, lastHit = 0 }
            alive[key] = st
            if not st.loc or now - (st.locAt or 0) >= 10 then
                local l = c:K2_GetComponentLocation()
                st.loc = { X = l.X, Y = l.Y, Z = l.Z }
                st.locAt = now
            end
            do
                local ck = math.floor(st.loc.X / S.SmokeCellSize) .. ":" .. math.floor(st.loc.Y / S.SmokeCellSize)
                local cell = cells[ck]
                if not cell then cell = { n = 0, x = 0, y = 0, z = st.loc.Z } cells[ck] = cell end
                cell.n = cell.n + 1
                cell.x = cell.x + st.loc.X
                cell.y = cell.y + st.loc.Y
                if st.loc.Z > cell.z then cell.z = st.loc.Z end
            end
            if not st.scaled and (S.FlameScale ~= 1.0 or S.FlameScaleZ ~= 1.0) then
                c:SetRelativeScale3D({ X = S.FlameScale, Y = S.FlameScale, Z = S.FlameScaleZ })
                st.scaled = true
                RF.stats.scaled = RF.stats.scaled + 1
            end
            if S.WeakenEnabled and pulses < S.WeakenMaxPerPass
               and now - st.since >= S.WeakenAfter and now - st.lastHit >= S.WeakenEvery then
                st.lastHit = now
                pulses = pulses + 1
                local loc = c:K2_GetComponentLocation()
                gs:ApplyRadialDamage(c, S.WeakenDamage, { X = loc.X, Y = loc.Y, Z = loc.Z }, S.WeakenRadius,
                    dmgType, {}, c:GetOwner(), nil, true, 0)
                RF.stats.pulses = RF.stats.pulses + 1
                pulseLoc = { X = loc.X, Y = loc.Y, Z = loc.Z }
            end
            if S.ClimbEnabled and climbs < S.ClimbMaxPerPass
               and now - st.since >= S.ClimbAfter and now - (st.lastClimb or 0) >= S.ClimbEvery then
                st.lastClimb = now
                climbs = climbs + 1
                local loc = c:K2_GetComponentLocation()
                first("climb (SpreadFire)")
                bs:SpreadFire(c,
                    { Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 }, Translation = { X = loc.X, Y = loc.Y, Z = loc.Z }, Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 } },
                    { X = -S.ClimbWidth, Y = -S.ClimbWidth, Z = 0.0 }, { X = S.ClimbWidth, Y = S.ClimbWidth, Z = S.ClimbHeight },
                    S.ClimbDistance, S.ClimbChance)
                RF.stats.climbs = (RF.stats.climbs or 0) + 1
            end
        end)
        if not okC and not RF.compErr then RF.compErr = true RF.note("ERROR handling a flame: " .. tostring(errC)) end
    end
    -- Burn-through: a flame that burned long enough and has now gone out leaves a brick too weak to hold.
    -- A sharp, small hit there snaps its connections, so whatever it was carrying comes down.
    if S.BurnThroughEnabled then
        for key, st in pairs(RF.flames) do
            if not alive[key] and st.loc and now - st.since >= S.BurnThroughAfter and #RF.burnQueue < 200 then
                RF.burnQueue[#RF.burnQueue + 1] = st.loc
            end
        end
    end
    RF.flames = alive
    local ctx = nil
    for _, c in ipairs(comps) do if c:IsValid() then ctx = c break end end
    if ctx and #RF.burnQueue > 0 then
        local okB, errB = pcall(function()
            local n = 0
            while n < S.BurnThroughMaxPerPass and #RF.burnQueue > 0 do
                local loc = table.remove(RF.burnQueue, 1)
                n = n + 1
                first("burn-through (ApplyRadialDamage)")
                gs:ApplyRadialDamage(ctx, S.BurnThroughDamage, loc, S.BurnThroughRadius, dmgType, {}, nil, nil, true, 0)
                RF.stats.burnt = (RF.stats.burnt or 0) + 1
                pulseLoc = pulseLoc or loc
            end
        end)
        if not okB and not RF.burnErr then RF.burnErr = true RF.note("burn-through failed: " .. tostring(errB)) end
    end
    -- Tall smoke column over each big fire (host's screen only)
    if S.SmokeColumnEnabled and not RF.smokeColBroken then
        local okS2, errS2 = pcall(function()
            local live = 0
            for ck, col in pairs(RF.columns) do
                local cell = cells[ck]
                if cell and cell.n >= 1 then col.lastSeen = now end
                if now - col.lastSeen >= S.SmokeLinger then
                    RF.columns[ck] = nil
                    pcall(function() if col.psc and col.psc:IsValid() then col.psc:Deactivate() end end)
                else
                    live = live + 1
                end
            end
            if not ctx then return end
            for ck, cell in pairs(cells) do
                if live >= S.SmokeMaxColumns then break end
                if cell.n >= S.SmokeMinFlames and not RF.columns[ck] then
                    local path = "/Game/BrickRigs/Buildings/PowerPlant/P_PowerPlant_Smoke.P_PowerPlant_Smoke"
                    local tpl = StaticFindObject(path)
                    if not (tpl and tpl:IsValid()) then
                        pcall(function() LoadAsset(path) end)
                        tpl = StaticFindObject(path)
                    end
                    if not (tpl and tpl:IsValid()) then
                        RF.smokeColBroken = true
                        RF.note("smoke column effect is not available, switched off")
                        return
                    end
                    first("smoke column (SpawnEmitterAtLocation)")
                    local k = S.SmokeColumnScale
                    local psc = gs:SpawnEmitterAtLocation(ctx, tpl,
                        { X = cell.x / cell.n, Y = cell.y / cell.n, Z = cell.z + S.SmokeColumnLift },
                        { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }, { X = k, Y = k, Z = k }, true, 0, true)
                    RF.columns[ck] = { psc = psc, lastSeen = now }
                    RF.stats.columns = (RF.stats.columns or 0) + 1
                    live = live + 1
                end
            end
        end)
        if not okS2 then RF.smokeColBroken = true RF.note("smoke column failed, switched off: " .. tostring(errS2)) end
    end
    -- Collapse effect: one short burst of the game's collapse sound and dust where fire is breaking the build.
    -- Both are started as components we keep hold of, so they can be cut off instead of piling up.
    if RF.burst and now >= RF.burst.stopAt then
        local bst = RF.burst
        RF.burst = nil
        pcall(function() if bst.audio and bst.audio:IsValid() then bst.audio:FadeOut(1.5, 0.0, 0) end end)
        pcall(function() if bst.dust and bst.dust:IsValid() then bst.dust:Deactivate() end end)
    end
    if pulseLoc and not RF.burst and now - (RF.lastBurst or 0) >= S.CollapseEvery then
        RF.lastBurst = now
        local bst = { stopAt = now + S.CollapseLength }
        local cdo = StaticFindObject("/Game/BrickRigs/Buildings/Blueprints/BP_BuildingDebris.Default__BP_BuildingDebris_C")
        local rot = { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }
        if cdo and cdo:IsValid() then
            if S.CollapseSoundEnabled then
                pcall(function()
                    local snd = cdo.CollapseSound
                    if snd and snd:IsValid() then
                        first("collapse sound (SpawnSoundAtLocation)")
                        bst.audio = gs:SpawnSoundAtLocation(comps[1], snd, pulseLoc, rot, S.CollapseSoundVolume, 1.0, 0.0, nil, nil, true)
                        RF.stats.sounds = (RF.stats.sounds or 0) + 1
                    end
                end)
            end
            if S.CollapseSmokeEnabled then
                local okD, errD = pcall(function()
                    local sys = cdo.CollapseSystem
                    if sys and sys:IsValid() then
                        first("collapse smoke (Niagara)")
                        local nlib = StaticFindObject("/Script/Niagara.Default__NiagaraFunctionLibrary")
                        local k = S.CollapseSmokeScale
                        bst.dust = nlib:SpawnSystemAtLocation(comps[1], sys, pulseLoc, rot, { X = k, Y = k, Z = k }, true, true, 0, true)
                        RF.stats.smokes = (RF.stats.smokes or 0) + 1
                    end
                end)
                if not okD and not RF.smokeErr then RF.smokeErr = true RF.note("collapse smoke failed: " .. tostring(errD)) end
            end
        elseif not RF.noSoundNoted then
            RF.noSoundNoted = true
            RF.note("collapse sound/smoke not available on this map")
        end
        RF.burst = bst
    end
    hud(string.format("Fire: REALISTIC   Tool: %s   Burning: %d", RF.hose and "FIRE HOSE" or "extinguisher", count))
    local dt = (os.clock() - t0) * 1000
    if dt > RF.worst then RF.worst = dt end
    if now - RF.lastLog >= 15 and (count > 0 or RF.lastCount ~= count) then
        RF.lastLog = now
        RF.lastCount = count
        RF.note(string.format("flames burning=%d (leftover, not burning=%d), flames enlarged=%d, weakening pulses=%d, climb attempts=%d, bricks burned through=%d (waiting %d), smoke columns=%d, pass=%.1f ms (slowest %.1f ms), particle components=%d",
            count, idle, RF.stats.scaled, RF.stats.pulses, RF.stats.climbs or 0, RF.stats.burnt or 0, #RF.burnQueue, RF.stats.columns or 0, dt, RF.worst, #comps))
    end
end

function RF.toggle()
    RF.enabled = not RF.enabled
    local info = fireInfo()
    if info then pcall(applySettings, info) end
    if not RF.enabled then
        -- put flames and extinguisher back
        pcall(function()
            for _, c in ipairs(FindAllOf("ParticleSystemComponent") or {}) do
                if c:IsValid() and RF.flames[c:GetAddress()] then c:SetRelativeScale3D({ X = 1, Y = 1, Z = 1 }) end
            end
        end)
        RF.flames = {}
        RF.burnQueue = {}
        for ck, col in pairs(RF.columns) do
            pcall(function() if col.psc and col.psc:IsValid() then col.psc:Deactivate() end end)
        end
        RF.columns = {}
    end
    local ok, err = pcall(function()
        local msg = StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(
            "[RealisticFire] fire is now " .. (RF.enabled and "REALISTIC (mod ON)" or "vanilla (mod OFF)"))
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then pc:SendChatMessage(1, msg) return end
        end
    end)
    if not ok then RF.note("chat notice failed: " .. tostring(err)) end
end

RF.note("logic loaded (enabled=" .. tostring(RF.enabled) .. ", folder found automatically=" .. tostring(RF.dirAuto == true) .. ", folder=" .. tostring(DIR) .. ")")
