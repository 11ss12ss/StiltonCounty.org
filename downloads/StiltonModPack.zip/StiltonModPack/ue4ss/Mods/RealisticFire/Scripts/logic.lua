-- RealisticFire logic (re-read by main.lua whenever version.txt changes)
local DIR = RF.dir
local STATUS = DIR .. "..\\status.txt"
local VANILLA = { BurnMin = 10, BurnMax = 15, RoundsMin = 1, RoundsMax = 2, CooldownMin = 5, CooldownMax = 7.5, SpreadChance = 0.05, SpreadDistance = 50 }

RF.flames   = {}            -- flame effects already enlarged
RF.veh      = {}            -- builds and their bricks (reset on reload)
RF.stats    = RF.stats or { pulses = 0, scaled = 0 }
RF.seen     = {}            -- particle templates seen (for diagnostics)
RF.applied  = nil
RF.lastLog  = 0
RF.worst    = 0
RF.spray    = {}            -- address -> scale applied to extinguisher spray
RF.extApplied = nil
RF.matsApplied = nil
RF.burnQueue = {}           -- places where a brick has burned through and is about to give way
RF.columns  = RF.columns or {}   -- cell -> { psc, lastSeen } tall smoke columns over big fires
if RF.hudWidget then
    local old = RF.hudWidget
    RF.hudWidget, RF.hudText, RF.hudBroken = nil, nil, nil
    pcall(function() if old:IsValid() then old:RemoveFromParent() end end)
end

function RF.note(s)
    local f = io.open(STATUS, "a")
    if f then f:write(os.date() .. "  " .. s .. "\n") f:close() end
end

local okS, S = pcall(dofile, DIR .. "settings.lua")
if not okS or type(S) ~= "table" then RF.note("settings.lua could not be read: " .. tostring(S)) S = nil end
RF.S = S

local function fireInfo()
    local info = StaticFindObject("/Game/BrickRigs/Vehicles/BP_BrickVehicle_StaticInfo.Default__BP_BrickVehicle_StaticInfo_C")
    if info and info:IsValid() then return info end
    return nil
end

local function writeFire(info, v)
    info.BurnTimeRange.Min = v.BurnMin
    info.BurnTimeRange.Max = v.BurnMax
    info.NumBurnIntervalsRange.Min = v.RoundsMin
    info.NumBurnIntervalsRange.Max = v.RoundsMax
    info.ExtinguishCooldownRange.Min = v.CooldownMin
    info.ExtinguishCooldownRange.Max = v.CooldownMax
    info.FireSpreadProbability = v.SpreadChance
    info.FireSpreadDistance = v.SpreadDistance
end

local function applySettings(info)
    local want = RF.enabled and "realistic" or "vanilla"
    if RF.applied == want then return end
    writeFire(info, RF.enabled and S or VANILLA)
    RF.applied = want
    RF.note(string.format("fire settings now %s: burn %.0f-%.0fs, rounds %d-%d, spread chance %.2f, distance %.0f", want,
        info.BurnTimeRange.Min, info.BurnTimeRange.Max, info.NumBurnIntervalsRange.Min, info.NumBurnIntervalsRange.Max,
        info.FireSpreadProbability, info.FireSpreadDistance))
end

-- Extinguisher tuning. Normal mode: weaker than vanilla. Hose mode: long reach, wide, reliable.
local function tuneExtinguisher()
    local mode = RF.hose and "hose" or "weak"
    if RF.extApplied == mode then return end
    local ok, err = pcall(function()
        local info = RF.extInfo
        if not (info and info:IsValid()) then
            info = nil
            for _, item in ipairs(FindAllOf("FireExtinguisher") or {}) do
                if item:IsValid() then
                    local i = item:GetStaticInfo()
                    if i and i:IsValid() then info = i break end
                end
            end
            if not info then return end
            RF.extInfo = info
        end
        local p = info.ExtinguisherProperties
        RF.extVanilla = RF.extVanilla or { chance = p.ExtinguishProbability, radius = p.ExtinguishRadius, distance = p.ExtinguishDistance, start = info.ExtinguishStartDistance }
        local v = RF.extVanilla
        v.distance = v.distance or p.ExtinguishDistance          -- older versions of this mod never changed these two
        v.start = v.start or info.ExtinguishStartDistance
        if RF.hose then
            p.ExtinguishProbability = S.HoseChance
            p.ExtinguishRadius = v.radius * S.HoseRadiusMult
            p.ExtinguishDistance = v.distance * S.HoseDistanceMult
            info.ExtinguishStartDistance = v.start * S.HoseDistanceMult
        else
            p.ExtinguishProbability = v.chance * S.ExtinguishChanceMult
            p.ExtinguishRadius = v.radius * S.ExtinguishRadiusMult
            p.ExtinguishDistance = v.distance
            info.ExtinguishStartDistance = v.start
        end
        RF.extApplied = mode
        RF.note(string.format("extinguisher (%s): chance %.2f, radius %.0f, distance %.0f, start distance %.0f  [vanilla %.2f / %.0f / %.0f / %.0f]",
            mode, p.ExtinguishProbability, p.ExtinguishRadius, p.ExtinguishDistance, info.ExtinguishStartDistance, v.chance, v.radius, v.distance, v.start))
    end)
    if not ok and not RF.extErr then RF.extErr = true RF.note("extinguisher tuning failed: " .. tostring(err)) end
end

local SPRAY = "ParticleSystem /Game/BrickRigs/ParticleFX/Fire/P_FireExtinguisher.P_FireExtinguisher"

local function say(text)
    local ok, err = pcall(function()
        local msg = StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(text)
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then pc:SendChatMessage(1, msg) return end
        end
    end)
    if not ok then RF.note("chat notice failed: " .. tostring(err)) end
end

function RF.toggleHose()
    RF.hose = not RF.hose
    pcall(tuneExtinguisher)
    say("[RealisticFire] extinguisher is now " .. (RF.hose and "a FIRE HOSE (long reach)" or "a normal extinguisher"))
end

if not RF.hoseKeyBound then
    RF.hoseKeyBound = true
    RegisterKeyBind(Key.SEVEN, function()
        ExecuteInGameThread(function() pcall(RF.toggleHose) end)
    end)
end

-- Write a marker the first time a feature is used, so a crash can be traced to it.
local function first(name)
    RF.firsts = RF.firsts or {}
    if not RF.firsts[name] then RF.firsts[name] = true RF.note("first use: " .. name) end
end

-- Per-material flammability: realistic values while the mod is on, the game's own when off.
local function applyMaterials()
    local want = RF.enabled and "realistic" or "vanilla"
    if RF.matsApplied == want then return end
    RF.matsApplied = want
    RF.matVanilla = RF.matVanilla or {}
    pcall(function()
        for _, m in ipairs(FindAllOf("BrickPhysicalMaterial") or {}) do
            if m:IsValid() then
                local name = m:GetFName():ToString()
                if RF.matVanilla[name] == nil then RF.matVanilla[name] = m.Flammability end
                local target = RF.matVanilla[name]
                if RF.enabled and S.Flammability and S.Flammability[name] ~= nil then target = S.Flammability[name] end
                if m.Flammability ~= target then
                    RF.note(string.format("material %s: flammability %.2f -> %.2f", name, m.Flammability, target))
                    m.Flammability = target
                end
            end
        end
    end)
end

-- Status line at the top of the screen.
local function hud(text)
    if not S.HudEnabled or RF.hudBroken then return end
    local ok, err = pcall(function()
        if not (RF.hudText and RF.hudText:IsValid() and RF.hudWidget and RF.hudWidget:IsValid()) then
            first("status line (creating widget)")
            local gi = FindFirstOf("BrickGameInstance")
            local w = StaticConstructObject(StaticFindObject("/Script/UMG.UserWidget"), gi)
            w.WidgetTree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
            -- the game's own text widget: plain engine text has no font in this game and draws nothing
            local tb = StaticConstructObject(StaticFindObject("/Script/BrickRigs.BrickTextBlock"), w.WidgetTree)
            pcall(function() tb:SetTextStyle(10) end)
            -- a widget added to the screen is stretched over all of it, so the root is an invisible
            -- full-screen box with the status line centred at the top inside it
            local screen = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), w.WidgetTree)
            local slot = screen:AddChildToVerticalBox(tb)
            slot:SetHorizontalAlignment(2)
            slot:SetPadding({ Left = 0.0, Top = 6.0, Right = 0.0, Bottom = 0.0 })
            w.WidgetTree.RootWidget = screen
            pcall(function() tb:SetTextStyle(3) end)
            pcall(function() tb:SetColorStyle(3) end)
            w:AddToViewport(50)
            pcall(function() w:SetVisibility(3) end)
            RF.hudWidget, RF.hudText, RF.hudShown = w, tb, nil
            first("status line (widget created)")
        end
        if RF.hudShown ~= text then
            RF.hudShown = text
            RF.hudText:SetText(StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(text))
        end
    end)
    if not ok then RF.hudBroken = true RF.note("status line failed, switched off: " .. tostring(err)) end
end

-- ---------------------------------------------------------------------------------------------
-- The fire logic works from the bricks themselves (is this brick on fire / burnt), not from the
-- flame effects: the game only draws flame effects near the camera, so they miss most of a fire.
-- ---------------------------------------------------------------------------------------------
RF.veh = RF.veh or {}        -- address -> record for every spawned build

local function refreshVehicles(now)
    if RF.vehAt and now - RF.vehAt < 5 then return end
    RF.vehAt = now
    local seen = {}
    for _, a in ipairs(FindAllOf("BrickVehicle") or {}) do
        if a:IsValid() then
            local k = a:GetAddress()
            local name = a:GetFName():ToString()
            seen[k] = true
            local v = RF.veh[k]
            if not v or v.name ~= name then
                RF.veh[k] = { actor = a, name = name, state = {}, done = {}, doneCount = 0, pos = 1, hot = false, burning = 0, cBurning = 0 }
            end
        end
    end
    for k in pairs(RF.veh) do if not seen[k] then RF.veh[k] = nil end end
end

local function buildList(v)
    local arr = v.actor:GetBricks()
    local list = {}
    for i = 1, #arr do
        local b = arr[i]
        if type(b) ~= "nil" then
            local okG, obj = pcall(function() return b:get() end)
            if okG and obj then list[#list + 1] = obj end
        end
    end
    v.list, v.pos, v.state, v.done, v.doneCount, v.cBurning = list, 1, {}, {}, 0, 0
end

-- Look at up to `budget` bricks of one build, carrying on where the last pass stopped.
local function sweep(v, budget, now, env)
    if not v.actor:IsValid() then return 0 end
    if not v.list then buildList(v) end
    local list = v.list
    local n = #list
    if n == 0 then return 0 end
    local used = 0
    while used < budget do
        local i = v.pos
        used = used + 1
        if not v.done[i] then
            local b = list[i]
            if not b:IsValid() then v.list = nil return used end       -- build was repaired/rebuilt: start over next pass
            if b:IsOnFire() then
                v.cBurning = v.cBurning + 1
                v.hot = true
                local st = v.state[i]
                if not st then st = { since = now } v.state[i] = st end
                if not st.loc then
                    local l = b:GetWorldLocation()
                    st.loc = { X = l.X, Y = l.Y, Z = l.Z }
                end
                local ck = math.floor(st.loc.X / S.SmokeCellSize) .. ":" .. math.floor(st.loc.Y / S.SmokeCellSize)
                local cell = env.cells[ck]
                if not cell then cell = { n = 0, x = 0, y = 0, z = st.loc.Z } env.cells[ck] = cell end
                cell.n = cell.n + 1
                cell.x = cell.x + st.loc.X
                cell.y = cell.y + st.loc.Y
                if st.loc.Z > cell.z then cell.z = st.loc.Z end
                -- fire climbs: light whatever is above this brick
                if S.ClimbEnabled and env.climbs < S.ClimbMaxPerPass
                   and now - st.since >= S.ClimbAfter and now - (st.lastClimb or 0) >= S.ClimbEvery then
                    st.lastClimb = now
                    env.climbs = env.climbs + 1
                    first("climb (SpreadFire)")
                    env.bs:SpreadFire(v.actor,
                        { Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 }, Translation = st.loc, Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 } },
                        { X = -S.ClimbWidth, Y = -S.ClimbWidth, Z = 0.0 }, { X = S.ClimbWidth, Y = S.ClimbWidth, Z = S.ClimbHeight },
                        S.ClimbDistance, S.ClimbChance)
                    RF.stats.climbs = (RF.stats.climbs or 0) + 1
                end
                -- fire weakens what it is burning
                if S.WeakenEnabled and env.pulses < S.WeakenMaxPerPass
                   and now - st.since >= S.WeakenAfter and now - (st.lastHit or 0) >= S.WeakenEvery then
                    st.lastHit = now
                    env.pulses = env.pulses + 1
                    env.gs:ApplyRadialDamage(v.actor, S.WeakenDamage, st.loc, S.WeakenRadius, env.dmgType, {}, nil, nil, true, 0)
                    RF.stats.pulses = RF.stats.pulses + 1
                end
            else
                local st = v.state[i]
                if b:IsBrickBurnt() then
                    -- burned out: this brick gives way
                    v.done[i] = true
                    v.doneCount = v.doneCount + 1
                    v.state[i] = nil
                    if S.BurnThroughEnabled and #RF.burnQueue < 3000 then
                        local loc = st and st.loc
                        if not loc then
                            local l = b:GetWorldLocation()
                            loc = { X = l.X, Y = l.Y, Z = l.Z }
                        end
                        RF.burnQueue[#RF.burnQueue + 1] = { loc = loc, actor = v.actor }
                    end
                elseif st then
                    v.state[i] = nil      -- put out before it burned through
                end
            end
        end
        v.pos = i + 1
        if v.pos > n then
            v.pos = 1
            v.burning = v.cBurning
            v.cBurning = 0
            v.hot = v.burning > 0
            break
        end
    end
    return used
end

function RF.pass()
    if not S then return end
    local t0 = os.clock()
    local info = fireInfo()
    if not info then return end
    applySettings(info)
    if not RF.enabled then applyMaterials() hud("Fire: vanilla (mod OFF)") return end
    tuneExtinguisher()
    applyMaterials()

    local now = os.time()
    local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
    -- the game's own explosion damage is what breaks brick connections; plain damage barely does
    local dmgType = StaticFindObject("/Script/BrickRigs.DamageType_Explosion")
    if not (dmgType and dmgType:IsValid()) then dmgType = StaticFindObject("/Script/Engine.DamageType") end
    if not RF.dmgNoted then RF.dmgNoted = true RF.note("structural damage type: " .. dmgType:GetFullName()) end
    local env = { cells = {}, climbs = 0, pulses = 0, gs = gs, dmgType = dmgType,
                  bs = StaticFindObject("/Script/BrickRigs.Default__BrickStatics") }

    -- 1. Bricks: walk through every build a slice at a time; builds that are burning get most of the time.
    local okW, errW = pcall(function()
        refreshVehicles(now)
        local hot, cold = {}, {}
        for _, v in pairs(RF.veh) do
            if v.hot then hot[#hot + 1] = v else cold[#cold + 1] = v end
        end
        local budget = S.SweepBricksPerPass
        local hotBudget = (#cold > 0) and math.floor(budget * 0.75) or budget
        if #hot > 0 then
            local each = math.max(150, math.floor(hotBudget / #hot))
            for _, v in ipairs(hot) do budget = budget - sweep(v, each, now, env) end
        end
        if #cold > 0 and budget > 0 then
            table.sort(cold, function(a, b) return a.name < b.name end)
            local tries = 0
            while budget > 0 and tries < #cold do
                RF.coldI = ((RF.coldI or 0) % #cold) + 1
                local v = cold[RF.coldI]
                local used = sweep(v, budget, now, env)
                budget = budget - math.max(used, 1)
                if v.pos ~= 1 and v.list then RF.coldI = RF.coldI - 1 break end   -- not finished: carry on with it next pass
                tries = tries + 1
            end
        end
    end)
    if not okW and not RF.sweepErr then RF.sweepErr = true RF.note("ERROR in brick sweep: " .. tostring(errW)) end

    local burning, builds, burningBuilds, gaveWay = 0, 0, 0, 0
    for _, v in pairs(RF.veh) do
        builds = builds + 1
        local b = math.max(v.burning, v.cBurning)
        burning = burning + b
        if b > 0 then burningBuilds = burningBuilds + 1 end
        gaveWay = gaveWay + v.doneCount
    end

    -- 2. Burn-through: each burned-out brick takes one sharp, small hit that snaps its connections.
    if #RF.burnQueue > 0 then
        local okB, errB = pcall(function()
            local nHit = 0
            while nHit < S.BurnThroughMaxPerPass and #RF.burnQueue > 0 do
                local item = table.remove(RF.burnQueue, 1)
                if item.actor:IsValid() then
                    nHit = nHit + 1
                    first("burn-through (ApplyRadialDamage)")
                    gs:ApplyRadialDamage(item.actor, S.BurnThroughDamage, item.loc, S.BurnThroughRadius, dmgType, {}, nil, nil, true, 0)
                    RF.stats.burnt = (RF.stats.burnt or 0) + 1
                end
            end
        end)
        if not okB and not RF.burnErr then RF.burnErr = true RF.note("burn-through failed: " .. tostring(errB)) end
    end

    -- 3. Flame effects near the camera: make them bigger and taller (host's screen only).
    local comps = FindAllOf("ParticleSystemComponent") or {}
    local fireName = nil
    pcall(function() fireName = info.FireEmitter:GetFullName() end)
    local alive = {}
    for _, c in ipairs(comps) do
        local okC, errC = pcall(function()
            if not c:IsValid() then return end
            local tpl = c.Template
            if not (tpl and tpl:IsValid()) then return end
            local name = tpl:GetFullName()
            if name == SPRAY then
                local want = RF.hose and S.HoseSprayScale or 1.0
                local k = c:GetAddress()
                if RF.spray[k] ~= want then
                    RF.spray[k] = want
                    c:SetRelativeScale3D({ X = want, Y = want, Z = want })
                end
                return
            end
            if name ~= fireName then return end
            local key = c:GetAddress()
            alive[key] = true
            if not RF.flames[key] and (S.FlameScale ~= 1.0 or S.FlameScaleZ ~= 1.0) then
                c:SetRelativeScale3D({ X = S.FlameScale, Y = S.FlameScale, Z = S.FlameScaleZ })
                RF.stats.scaled = RF.stats.scaled + 1
            end
        end)
        if not okC and not RF.compErr then RF.compErr = true RF.note("ERROR handling a flame: " .. tostring(errC)) end
    end
    RF.flames = alive

    -- 4. Tall smoke column over each big fire (host's screen only).
    if S.SmokeColumnEnabled and not RF.smokeColBroken then
        local okS2, errS2 = pcall(function()
            local ctx = nil
            for _, v in pairs(RF.veh) do if v.actor:IsValid() then ctx = v.actor break end end
            local live = 0
            for ck, col in pairs(RF.columns) do
                local cell = env.cells[ck]
                if cell and cell.n >= 1 then col.lastSeen = now end
                if now - col.lastSeen >= S.SmokeLinger then
                    RF.columns[ck] = nil
                    pcall(function() if col.psc and col.psc:IsValid() then col.psc:Deactivate() end end)
                else
                    live = live + 1
                end
            end
            if not ctx then return end
            for ck, cell in pairs(env.cells) do
                if live >= S.SmokeMaxColumns then break end
                if cell.n >= S.SmokeMinFlames and not RF.columns[ck] then
                    local path = "/Game/BrickRigs/Buildings/PowerPlant/P_PowerPlant_Smoke.P_PowerPlant_Smoke"
                    local tpl = StaticFindObject(path)
                    if not (tpl and tpl:IsValid()) then
                        pcall(function() LoadAsset(path) end)
                        tpl = StaticFindObject(path)
                    end
                    if not (tpl and tpl:IsValid()) then
                        RF.smokeColBroken = true
                        RF.note("smoke column effect is not available, switched off")
                        return
                    end
                    first("smoke column (SpawnEmitterAtLocation)")
                    local k = S.SmokeColumnScale
                    local psc = gs:SpawnEmitterAtLocation(ctx, tpl,
                        { X = cell.x / cell.n, Y = cell.y / cell.n, Z = cell.z + S.SmokeColumnLift },
                        { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }, { X = k, Y = k, Z = k }, true, 0, true)
                    RF.columns[ck] = { psc = psc, lastSeen = now }
                    RF.stats.columns = (RF.stats.columns or 0) + 1
                    live = live + 1
                end
            end
        end)
        if not okS2 then RF.smokeColBroken = true RF.note("smoke column failed, switched off: " .. tostring(errS2)) end
    end

    hud(string.format("Fire: REALISTIC   Tool: %s   Burning: %d", RF.hose and "FIRE HOSE" or "extinguisher", burning))
    local dt = (os.clock() - t0) * 1000
    if dt > RF.worst then RF.worst = dt end
    if now - RF.lastLog >= 15 and (burning > 0 or #RF.burnQueue > 0 or RF.lastCount ~= burning) then
        RF.lastLog = now
        RF.lastCount = burning
        RF.note(string.format("bricks on fire=%d in %d of %d builds, burned out=%d, hits done=%d (waiting %d), weakening pulses=%d, climb attempts=%d, smoke columns=%d, flames enlarged=%d, pass=%.1f ms (slowest %.1f ms)",
            burning, burningBuilds, builds, gaveWay, RF.stats.burnt or 0, #RF.burnQueue, RF.stats.pulses, RF.stats.climbs or 0, RF.stats.columns or 0, RF.stats.scaled, dt, RF.worst))
        for _, v in pairs(RF.veh) do
            if math.max(v.burning, v.cBurning) > 0 or v.doneCount > 0 then
                local pin = "?"
                pcall(function() pin = tostring(v.actor.PinMode) end)
                RF.note(string.format("  build %s: bricks=%d, on fire=%d, burned out=%d, pin mode=%s (0 none, 1 root brick, 2 all bricks)",
                    v.name, v.list and #v.list or 0, math.max(v.burning, v.cBurning), v.doneCount, pin))
            end
        end
    end
end

function RF.toggle()
    RF.enabled = not RF.enabled
    local info = fireInfo()
    if info then pcall(applySettings, info) end
    if not RF.enabled then
        -- put flames and extinguisher back
        pcall(function()
            for _, c in ipairs(FindAllOf("ParticleSystemComponent") or {}) do
                if c:IsValid() and RF.flames[c:GetAddress()] then c:SetRelativeScale3D({ X = 1, Y = 1, Z = 1 }) end
            end
        end)
        RF.flames = {}
        RF.burnQueue = {}
        RF.veh = {}
        for ck, col in pairs(RF.columns) do
            pcall(function() if col.psc and col.psc:IsValid() then col.psc:Deactivate() end end)
        end
        RF.columns = {}
    end
    local ok, err = pcall(function()
        local msg = StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(
            "[RealisticFire] fire is now " .. (RF.enabled and "REALISTIC (mod ON)" or "vanilla (mod OFF)"))
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then pc:SendChatMessage(1, msg) return end
        end
    end)
    if not ok then RF.note("chat notice failed: " .. tostring(err)) end
end

RF.note("logic loaded (enabled=" .. tostring(RF.enabled) .. ", folder found automatically=" .. tostring(RF.dirAuto == true) .. ", folder=" .. tostring(DIR) .. ")")
