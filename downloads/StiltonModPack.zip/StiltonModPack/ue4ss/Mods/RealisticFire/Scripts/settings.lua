-- RealisticFire settings. Edit and save, then change the text in version.txt to apply without restarting.
return {
    -- How fire burns and spreads (game's own settings; vanilla in brackets)
    BurnMin = 30.0,  BurnMax = 50.0,       -- seconds each brick keeps burning        (10-15)
    RoundsMin = 2,   RoundsMax = 3,        -- burn/spread rounds per brick             (1-2)
    CooldownMin = 6.0, CooldownMax = 9.0,  -- seconds before a put-out brick can reignite (5-7.5)
    SpreadChance = 0.06,                   -- chance fire jumps sideways to a nearby brick (0.05)
    SpreadDistance = 65.0,                 -- how far fire can jump                    (50)

    -- Fire climbs: each flame keeps trying to light whatever is above it
    ClimbEnabled = true,
    ClimbAfter = 15.0,                     -- seconds a flame burns before it starts climbing
    ClimbEvery = 12.0,                     -- seconds between climb attempts from the same flame
    ClimbHeight = 200.0,                   -- how far above the flame it can reach
    ClimbWidth = 35.0,                     -- half-width of the column above the flame
    ClimbDistance = 30.0,                  -- extra reach around that column
    ClimbChance = 0.30,                    -- chance each brick in the column catches
    ClimbMaxPerPass = 4,                    -- cap on climb attempts per second, to keep it light

    -- Collapse effect while fire is breaking the structure: a short burst of sound and dust
    CollapseEvery = 10.0,                  -- at most one burst every this many seconds
    CollapseLength = 3.0,                  -- seconds each burst lasts before it is cut off
    CollapseSoundEnabled = false,          -- off: the SolidDebris mod now plays the collapse effect for every kind of collapse
    CollapseSoundVolume = 0.8,
    CollapseSmokeEnabled = false,
    CollapseSmokeScale = 0.5,              -- size of the dust cloud (1.0 = a full building collapse)

    -- Milliseconds the mod may spend checking bricks, four times a second (more = reacts faster, costs more time)
    SweepBudgetMs = 2.5,

    -- Small status line at the top of the screen
    HudEnabled = true,

    -- How easily each material catches fire, 0 = never, 1 = very easily (vanilla in brackets)
    Flammability = {
        PM_Wood = 0.70,      -- (0.50)
        PM_Foam = 0.80,      -- (0.80)
        PM_Rubber = 0.55,    -- (0.75)
        PM_Plastic = 0.55,   -- (0.50)
        PM_Carbon = 0.25,    -- (0.60)
        PM_Glass = 0.00,     -- (0.20)
        -- metals and stone stay at 0: they never burn
    },

    -- Bigger flames (host's screen only)
    FlameScale = 1.0,                      -- width, 1.0 = vanilla size
    FlameScaleZ = 1.0,                     -- height: taller flames and higher smoke (was 4.0: too laggy)

    -- Tall smoke column over each big fire (host's screen only)
    -- Automatic fire calls: a fire this big that keeps burning files a call in the CAD for SCFD
    -- (host only; needs the Stilton CAD mod, logged in or with the bank linked on the host's PC)
    AutoFireCalls = true,
    AutoFireMinBricks = 12,                -- burning bricks in one build
    AutoFireAfter = 20,                    -- seconds it has to keep burning first
    AutoFireRepeat = 900,                  -- at most one report per build every this many seconds

    SmokeColumnEnabled = false,
    SmokeColumnScale = 0.25,               -- size of the column (1.0 = the power plant chimney plume)
    SmokeColumnLift = 150.0,               -- how far above the highest flame it starts
    SmokeMinFlames = 10,                   -- burning bricks needed in one area before a column appears
    SmokeMaxColumns = 2,                   -- most columns at once
    SmokeCellSize = 1500.0,                -- size of the area that shares one column
    SmokeLinger = 10.0,                    -- seconds the column keeps going after the fire there is out

    -- Burn-through: a brick that has burned out gives way,
    -- so whatever it was holding up falls
    BurnThroughEnabled = true,
    StructuralMinFire = 40,                -- bricks a fire must have reached in one build (burning + burned out)
                                           -- before it weakens or breaks anything: small fires only char bricks
    BurnThroughDamage = 1500.0,             -- strength of the hit that snaps its connections
    BurnThroughRadius = 40.0,              -- reach of that hit
    BurnThroughMaxPerPass = 4,              -- cap per second, to keep it light

    -- Fire extinguisher is less effective
    ExtinguishChanceMult = 0.85,           -- multiplier on the extinguisher's chance to put a brick out
    ExtinguishRadiusMult = 1.0,            -- multiplier on the extinguisher's reach around the spray

    -- Fire hose mode (the "Hose" button): the extinguisher reaches much further and puts fire out reliably
    HoseChance = 0.90,                     -- chance to put a brick out per hit
    HoseRadiusMult = 2.5,                  -- width of the area hit, relative to vanilla
    HoseDistanceMult = 4.0,                -- reach, relative to vanilla
    HoseSprayScale = 3.0,                  -- size of the spray effect (host's screen only)
    HoseDirect = true,                     -- the hose puts out every burning brick in a cone in front of the nozzle
    HoseReach = 1500.0,                    -- how far that cone reaches (100 = 1 m)
    HoseWidth = 120.0,                     -- half-width of the cone at the nozzle
    HoseConeSpread = 0.25,                 -- how much the cone widens with distance
    HosePutOutChance = 0.6,                -- chance per brick, four times a second, while the spray hits it

    -- Fire weakens the structure: bricks that have burned a while take damage, so connections fail
    WeakenEnabled = true,
    WeakenAfter = 60.0,                    -- seconds a flame must burn before it starts damaging
    WeakenEvery = 15.0,                    -- seconds between damage pulses from the same flame
    WeakenDamage = 250.0,                  -- damage per pulse
    WeakenRadius = 40.0,                   -- reach of each pulse
    WeakenMaxPerPass = 3,                  -- cap on pulses per second, to keep it light
}
