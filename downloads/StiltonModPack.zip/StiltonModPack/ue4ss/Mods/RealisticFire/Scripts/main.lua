-- RealisticFire for Brick Rigs (UE4SS Lua mod) - loader
-- The behaviour lives in logic.lua and the numbers in settings.lua, next to this file.
-- Both are re-read while the game runs (when version.txt changes), so tuning needs no restart.
-- Switched on/off with the "Fire" button (press F4 for the mouse). A chat line confirms the new state.

local DIR = [[C:\Program Files (x86)\Steam\steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64\ue4ss\Mods\RealisticFire\Scripts\]]
RF = RF or { enabled = true }
-- Use the folder this mod is actually installed in (Steam libraries are not always on C:).
pcall(function()
    local here = debug.getinfo(1, "S").source:match("^@?(.*[\\/])[^\\/]+$")
    local f = here and io.open(here .. "main.lua", "r")
    if f then f:close() else here = nil end
    if here then DIR = here:gsub("/", "\\") RF.dirAuto = true end
end)
RF.dir = DIR
local loadedVersion = nil
local queuedAt = 0

local function readVersion()
    local f = io.open(DIR .. "version.txt", "r")
    if not f then return "none" end
    local v = f:read("*a") or ""
    f:close()
    return v
end

local tickN = 0
local function tick()
    tickN = tickN + 1
    local v = (tickN % 8 == 1) and readVersion() or loadedVersion   -- look for a new version every 2 s
    if v ~= loadedVersion then
        loadedVersion = v
        local ok, err = pcall(dofile, DIR .. "logic.lua")
        if not ok then print("[RealisticFire] logic error: " .. tostring(err) .. "\n") end
    end
    if RF.pass then
        local ok, err = pcall(RF.pass)
        if not ok and RF.note then RF.note("ERROR in pass: " .. tostring(err)) end
    end
end

LoopAsync(250, function()
    -- A queued tick can be dropped when the game changes map; don't wait on it forever.
    if queuedAt == 0 or os.time() - queuedAt > 4 then
        queuedAt = os.time()
        ExecuteInGameThread(function() pcall(tick) queuedAt = 0 end)
    end
    return false
end)


print("[RealisticFire] loaded\n")
