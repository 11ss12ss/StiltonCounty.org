-- SolidDebris for Brick Rigs (UE4SS Lua mod)
-- In multiplayer the game sets detached brick pieces to ignore players (collision response
-- to the Pawn channel = Ignore). This mod switches every such piece back to Block, so loose
-- bricks are solid like they are in singleplayer. Run it on the host.
--
-- It also adds a collapse effect: when a chunk of a build breaks apart (any cause: fire, bombs,
-- crashes), the game's building-collapse dust cloud plays briefly at that spot (no sound).
--
-- Switched on/off with the "Solid debris" button (press F4 for the mouse). A chat line confirms the new state.

local INTERVAL_MS   = 100   -- a short slice of work this often
local SLICE_MS      = 3.0   -- most milliseconds one slice may take (keeps frames smooth)
local ROUND_MIN_SEC = 1.0   -- shortest time between rounds through every piece
local PAWN_CHANNEL = 2     -- ECC_Pawn
local IGNORE       = 0     -- ECR_Ignore
local BLOCK        = 2     -- ECR_Block
local COLLAPSE_EFFECT   = true   -- dust cloud when a build breaks apart (host sees it)
local COLLAPSE_MIN_PIECES = 6     -- pieces that must break off at once to count as a collapse
local COLLAPSE_EVERY    = 6      -- at most one effect every this many seconds
local COLLAPSE_LENGTH   = 3      -- seconds the effect lasts before it is cut off
local COLLAPSE_DUST_SCALE = 0.5  -- 1.0 = a full building collapse
local DIR          = [[C:\Program Files (x86)\Steam\steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64\ue4ss\Mods\SolidDebris\]]
-- Use the folder this mod is actually installed in (Steam libraries are not always on C:).
pcall(function()
    local here = debug.getinfo(1, "S").source:match("^@?(.*[\\/])[Ss]cripts[\\/][^\\/]+$")
    local f = here and io.open(here .. "Scripts\\main.lua", "r")
    if f then f:close() else here = nil end
    if here then DIR = here end
end)
local STATUS_FILE  = DIR .. "status.txt"
local DIAG_FILE    = DIR .. "diagnostic.txt"

local enabled     = true
local queuedAt    = 0      -- when a pass was last handed to the game thread (0 = none waiting)
local totalFixed  = 0
local passes      = 0
local lastStatus  = 0
local diagDone    = true    -- set to false to record a one-time collision diagnostic
local notifyResult = "not used yet"
local known       = nil    -- addresses of brick pieces seen last pass (nil until the first pass)
local knownOwners = {}     -- address of each build -> when it was first seen
local burst       = nil    -- the collapse effect currently playing
local lastBurst   = 0
local bursts      = 0
local burstNote   = "none yet"

local function stopBurst()
    local b = burst
    burst = nil
    if not b then return end
    pcall(function() if b.audio and b.audio:IsValid() then b.audio:FadeOut(1.5, 0.0, 0) end end)
    pcall(function() if b.dust and b.dust:IsValid() then b.dust:Deactivate() end end)
end

local function startBurst(ctx, loc)
    lastBurst = os.time()
    local b = { stopAt = os.time() + COLLAPSE_LENGTH }
    local ok, err = pcall(function()
        local cdo = StaticFindObject("/Game/BrickRigs/Buildings/Blueprints/BP_BuildingDebris.Default__BP_BuildingDebris_C")
        if not (cdo and cdo:IsValid()) then error("collapse assets not loaded on this map") end
        local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
        local rot = { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }
        local sys = cdo.CollapseSystem
        if sys and sys:IsValid() then
            local nlib = StaticFindObject("/Script/Niagara.Default__NiagaraFunctionLibrary")
            local k = COLLAPSE_DUST_SCALE
            b.dust = nlib:SpawnSystemAtLocation(ctx, sys, loc, rot, { X = k, Y = k, Z = k }, true, true, 0, true)
        end
        burstNote = string.format("dust=%s", tostring(b.dust ~= nil and b.dust:IsValid()))
    end)
    if not ok then burstNote = "failed: " .. tostring(err) end
    bursts = bursts + 1
    burst = b
end

local lastFindMs, lastRoundSec, lastRoundPieces, slowestSlice, errNoted, lastError
local function writeStatus()
    local f = io.open(STATUS_FILE, "w")
    if not f then return end
    f:write(string.format("%s  enabled=%s  rounds=%d  pieces made solid=%d  pieces per round=%d  round took %.1f s  finding pieces %.0f ms  slowest slice=%.1f ms  notice=%s  collapse effects=%d (%s)%s\n",
        os.date(), tostring(enabled), passes, totalFixed, lastRoundPieces or 0, lastRoundSec or 0, lastFindMs or 0, slowestSlice or 0, notifyResult, bursts, burstNote,
        lastError and ("  first error: " .. lastError) or ""))
    f:close()
end

local function responses(c)
    local t = {}
    for ch = 0, 31 do
        local ok, r = pcall(function() return c:GetCollisionResponseToChannel(ch) end)
        t[#t + 1] = ok and tostring(r) or "?"
    end
    return table.concat(t, "")
end

-- One-time record of how a loose piece, an attached piece and the player are set up.
local function diagnose(loose, attached)
    diagDone = true
    local f = io.open(DIAG_FILE, "w")
    if not f then return end
    f:write(os.date() .. "\nresponse per channel 0..31 (0 ignore, 1 overlap, 2 block)\n")
    pcall(function() f:write("loose piece (before fix): " .. responses(loose) .. " objType=" .. tostring(loose:GetCollisionObjectType()) .. " enabled=" .. tostring(loose:GetCollisionEnabled()) .. "\n") end)
    if attached then
        pcall(function() f:write("attached piece:           " .. responses(attached) .. " objType=" .. tostring(attached:GetCollisionObjectType()) .. " enabled=" .. tostring(attached:GetCollisionEnabled()) .. "\n") end)
    end
    pcall(function()
        for _, ch in ipairs(FindAllOf("BrickCharacter") or {}) do
            if ch:IsValid() then
                local cap = ch.CapsuleComponent
                f:write("character " .. ch:GetFName():ToString() .. " capsule:  " .. responses(cap)
                    .. " objType=" .. tostring(cap:GetCollisionObjectType())
                    .. " profile=" .. cap:GetCollisionProfileName():ToString() .. "\n")
            end
        end
    end)
    f:close()
end

-- The work is cut into slices of a few milliseconds, so it never holds up a frame for long.
-- One round = find every brick piece once, then check them a slice at a time.
local list, cursor = nil, 1          -- pieces found at the start of this round, and where the next slice starts
local roundSeen = {}                 -- addresses of pieces seen this round (for the collapse effect)
local roundOwners = {}
local roundFresh, roundFreshComp = 0, nil
local roundStart, lastRefresh = 0, 0
lastFindMs, lastRoundSec, lastRoundPieces, slowestSlice = 0, 0, 0, 0

local function endRound()
    if COLLAPSE_EFFECT then
        if known then
            for o, t in pairs(knownOwners) do roundOwners[o] = roundOwners[o] or t end   -- keep builds we already knew
        else
            pcall(function()
                for _, v in ipairs(FindAllOf("BrickVehicle") or {}) do roundOwners[v:GetAddress()] = os.time() - 60 end
            end)
        end
        known, knownOwners = roundSeen, roundOwners
        if burst and os.time() >= burst.stopAt then stopBurst() end
        if roundFresh >= COLLAPSE_MIN_PIECES and not burst and os.time() - lastBurst >= COLLAPSE_EVERY then
            pcall(function()
                local l = roundFreshComp:K2_GetComponentLocation()
                startBurst(roundFreshComp, { X = l.X, Y = l.Y, Z = l.Z })
            end)
        end
    end
    lastRoundSec = os.clock() - roundStart
    lastRoundPieces = list and #list or 0
    passes = passes + 1
    list, cursor = nil, 1
    roundSeen, roundOwners, roundFresh, roundFreshComp = {}, {}, 0, nil
    if os.time() - lastStatus >= 15 then
        lastStatus = os.time()
        writeStatus()
    end
end

-- Check pieces until the time runs out. One error only skips the piece that caused it.
local function work(deadline)
    local now = os.time()
    local n = #list
    while cursor <= n do
        if os.clock() >= deadline then return end
        local c = list[cursor]
        cursor = cursor + 1
        if c:IsValid() then
            if c:GetCollisionResponseToChannel(PAWN_CHANNEL) == IGNORE then
                c:SetCollisionResponseToChannel(PAWN_CHANNEL, BLOCK)
                totalFixed = totalFixed + 1
            end
            if COLLAPSE_EFFECT then
                local a = c:GetAddress()
                roundSeen[a] = true
                if known and not known[a] then
                    -- a piece that did not exist last round: broken off, unless its whole build is new (just spawned)
                    local o = c:GetOwner():GetAddress()
                    roundOwners[o] = knownOwners[o] or now
                    -- builds are assembled over several seconds after spawning; don't count that as breaking
                    if knownOwners[o] and now - knownOwners[o] >= 10 then
                        roundFresh = roundFresh + 1
                        roundFreshComp = roundFreshComp or c
                    end
                end
            end
        end
    end
end

local function slice()
    local t0 = os.clock()
    local deadline = t0 + SLICE_MS / 1000
    if not list then
        if t0 - lastRefresh < ROUND_MIN_SEC then return end
        lastRefresh = t0
        roundStart = t0
        list = FindAllOf("BrickStaticMeshComponent") or {}
        cursor = 1
        lastFindMs = (os.clock() - t0) * 1000
        deadline = os.clock() + SLICE_MS / 1000
    end
    while cursor <= #list and os.clock() < deadline do
        local ok, err = pcall(work, deadline)
        if not ok and not errNoted then errNoted = true lastError = tostring(err) end
    end
    if cursor > #list then endRound() end
    local dt = (os.clock() - t0) * 1000
    if dt > slowestSlice then slowestSlice = dt end
end

-- Show a line in the in-game chat box (visible to everyone in the session).
local function notify(text)
    local ok, err = pcall(function()
        local lib = StaticFindObject("/Script/Engine.Default__KismetTextLibrary")
        local msg = lib:Conv_StringToText(text)
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then
                pc:SendChatMessage(1, msg)   -- 1 = global chat
                return
            end
        end
        error("no local player controller")
    end)
    notifyResult = ok and "ok" or ("failed: " .. tostring(err))
    writeStatus()
end

-- The on-screen "Solid debris" button (in the CAD mod) leaves a command here; the state goes back
-- the same way, so the button can show it.
local CMD_FILE   = DIR .. "command.txt"
local STATE_FILE = DIR .. "state.txt"
local stateWritten = nil
local loopN = 0

local function writeState()
    local want = enabled and "on" or "off"
    if stateWritten == want then return end
    local f = io.open(STATE_FILE, "w")
    if f then f:write(want .. "\n") f:close() stateWritten = want end
end

local function toggle()
    enabled = not enabled
    writeState()
    ExecuteInGameThread(function()
        notify("[SolidDebris] loose bricks are now " .. (enabled and "SOLID (mod ON)" or "pass-through (mod OFF)"))
    end)
end

local function readCommands()
    local f = io.open(CMD_FILE, "r")
    if not f then return end
    local s = f:read("*a") or ""
    f:close()
    os.remove(CMD_FILE)
    for line in s:gmatch("[^\r\n]+") do
        if line:match("^%s*toggle") then toggle() end
    end
end

writeState()

LoopAsync(INTERVAL_MS, function()
    loopN = loopN + 1
    if loopN % 5 == 0 then pcall(readCommands) end      -- button presses, twice a second
    -- A queued pass can be dropped when the game changes map; don't wait on it forever.
    if enabled and (queuedAt == 0 or os.time() - queuedAt > 3) then
        queuedAt = os.time()
        ExecuteInGameThread(function()
            pcall(slice)
            queuedAt = 0
        end)
    end
    return false
end)

print("[SolidDebris] loaded\n")
