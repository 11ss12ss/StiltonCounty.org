-- SolidDebris for Brick Rigs (UE4SS Lua mod)
-- In multiplayer the game sets detached brick pieces to ignore players (collision response
-- to the Pawn channel = Ignore). This mod switches every such piece back to Block, so loose
-- bricks are solid like they are in singleplayer. Run it on the host.
--
-- It also adds a collapse effect: when a chunk of a build breaks apart (any cause: fire, bombs,
-- crashes), the game's building-collapse dust cloud plays briefly at that spot (no sound).
--
-- Press 9 to turn the mod on/off. A chat line confirms the new state.

local INTERVAL_MS  = 500   -- how often to look for newly detached pieces (backs off to 2 s when a pass is slow)
local PAWN_CHANNEL = 2     -- ECC_Pawn
local IGNORE       = 0     -- ECR_Ignore
local BLOCK        = 2     -- ECR_Block
local COLLAPSE_EFFECT   = true   -- dust cloud when a build breaks apart (host sees it)
local COLLAPSE_MIN_PIECES = 6     -- pieces that must break off at once to count as a collapse
local COLLAPSE_EVERY    = 6      -- at most one effect every this many seconds
local COLLAPSE_LENGTH   = 3      -- seconds the effect lasts before it is cut off
local COLLAPSE_DUST_SCALE = 0.5  -- 1.0 = a full building collapse
local DIR          = [[C:\Program Files (x86)\Steam\steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64\ue4ss\Mods\SolidDebris\]]
-- Use the folder this mod is actually installed in (Steam libraries are not always on C:).
pcall(function()
    local here = debug.getinfo(1, "S").source:match("^@?(.*[\\/])[Ss]cripts[\\/][^\\/]+$")
    local f = here and io.open(here .. "Scripts\\main.lua", "r")
    if f then f:close() else here = nil end
    if here then DIR = here end
end)
local STATUS_FILE  = DIR .. "status.txt"
local DIAG_FILE    = DIR .. "diagnostic.txt"

local enabled     = true
local queuedAt    = 0      -- when a pass was last handed to the game thread (0 = none waiting)
local totalFixed  = 0
local passes      = 0
local worstPass   = 0
local lastStatus  = 0
local diagDone    = true    -- set to false to record a one-time collision diagnostic
local skipTicks   = 0       -- ticks to sit out after a slow pass, so big wrecks don't cause stutter
local notifyResult = "not used yet"
local known       = nil    -- addresses of brick pieces seen last pass (nil until the first pass)
local knownOwners = {}     -- address of each build -> when it was first seen
local burst       = nil    -- the collapse effect currently playing
local lastBurst   = 0
local bursts      = 0
local burstNote   = "none yet"

local function stopBurst()
    local b = burst
    burst = nil
    if not b then return end
    pcall(function() if b.audio and b.audio:IsValid() then b.audio:FadeOut(1.5, 0.0, 0) end end)
    pcall(function() if b.dust and b.dust:IsValid() then b.dust:Deactivate() end end)
end

local function startBurst(ctx, loc)
    lastBurst = os.time()
    local b = { stopAt = os.time() + COLLAPSE_LENGTH }
    local ok, err = pcall(function()
        local cdo = StaticFindObject("/Game/BrickRigs/Buildings/Blueprints/BP_BuildingDebris.Default__BP_BuildingDebris_C")
        if not (cdo and cdo:IsValid()) then error("collapse assets not loaded on this map") end
        local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
        local rot = { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }
        local sys = cdo.CollapseSystem
        if sys and sys:IsValid() then
            local nlib = StaticFindObject("/Script/Niagara.Default__NiagaraFunctionLibrary")
            local k = COLLAPSE_DUST_SCALE
            b.dust = nlib:SpawnSystemAtLocation(ctx, sys, loc, rot, { X = k, Y = k, Z = k }, true, true, 0, true)
        end
        burstNote = string.format("dust=%s", tostring(b.dust ~= nil and b.dust:IsValid()))
    end)
    if not ok then burstNote = "failed: " .. tostring(err) end
    bursts = bursts + 1
    burst = b
end

local function writeStatus(lastPass)
    local f = io.open(STATUS_FILE, "w")
    if not f then return end
    f:write(string.format("%s  enabled=%s  passes=%d  pieces made solid=%d  last pass=%.1f ms  slowest pass=%.1f ms  notice=%s  collapse effects=%d (%s)\n",
        os.date(), tostring(enabled), passes, totalFixed, lastPass * 1000, worstPass * 1000, notifyResult, bursts, burstNote))
    f:close()
end

local function responses(c)
    local t = {}
    for ch = 0, 31 do
        local ok, r = pcall(function() return c:GetCollisionResponseToChannel(ch) end)
        t[#t + 1] = ok and tostring(r) or "?"
    end
    return table.concat(t, "")
end

-- One-time record of how a loose piece, an attached piece and the player are set up.
local function diagnose(loose, attached)
    diagDone = true
    local f = io.open(DIAG_FILE, "w")
    if not f then return end
    f:write(os.date() .. "\nresponse per channel 0..31 (0 ignore, 1 overlap, 2 block)\n")
    pcall(function() f:write("loose piece (before fix): " .. responses(loose) .. " objType=" .. tostring(loose:GetCollisionObjectType()) .. " enabled=" .. tostring(loose:GetCollisionEnabled()) .. "\n") end)
    if attached then
        pcall(function() f:write("attached piece:           " .. responses(attached) .. " objType=" .. tostring(attached:GetCollisionObjectType()) .. " enabled=" .. tostring(attached:GetCollisionEnabled()) .. "\n") end)
    end
    pcall(function()
        for _, ch in ipairs(FindAllOf("BrickCharacter") or {}) do
            if ch:IsValid() then
                local cap = ch.CapsuleComponent
                f:write("character " .. ch:GetFName():ToString() .. " capsule:  " .. responses(cap)
                    .. " objType=" .. tostring(cap:GetCollisionObjectType())
                    .. " profile=" .. cap:GetCollisionProfileName():ToString() .. "\n")
            end
        end
    end)
    f:close()
end

local function pass()
    local t0 = os.clock()
    local comps = FindAllOf("BrickStaticMeshComponent")
    if comps then
        local firstLoose, firstAttached = nil, nil
        if not diagDone then
            for _, c in ipairs(comps) do
                local ok, r = pcall(function() return c:IsValid() and c:GetCollisionResponseToChannel(PAWN_CHANNEL) end)
                if ok and r == IGNORE and not firstLoose then firstLoose = c end
                if ok and r == BLOCK and not firstAttached then firstAttached = c end
                if firstLoose and firstAttached then break end
            end
            if firstLoose then pcall(diagnose, firstLoose, firstAttached) end
        end
        local seen, owners = {}, {}
        local fresh, freshComp = 0, nil
        for _, c in ipairs(comps) do
            pcall(function()
                if not c:IsValid() then return end
                if c:GetCollisionResponseToChannel(PAWN_CHANNEL) == IGNORE then
                    c:SetCollisionResponseToChannel(PAWN_CHANNEL, BLOCK)
                    totalFixed = totalFixed + 1
                end
                if COLLAPSE_EFFECT then
                    local a = c:GetAddress()
                    seen[a] = true
                    if known and not known[a] then
                        -- a piece that did not exist last pass: broken off, unless its whole build is new (just spawned)
                        local o = c:GetOwner():GetAddress()
                        owners[o] = knownOwners[o] or os.time()
                        -- builds are assembled over several seconds after spawning; don't count that as breaking
                        if knownOwners[o] and os.time() - knownOwners[o] >= 10 then
                            fresh = fresh + 1
                            freshComp = freshComp or c
                        end
                    end
                end
            end)
        end
        if COLLAPSE_EFFECT then
            if known then
                for o, t in pairs(knownOwners) do owners[o] = owners[o] or t end   -- keep builds we already knew
            else
                pcall(function()
                    for _, v in ipairs(FindAllOf("BrickVehicle") or {}) do owners[v:GetAddress()] = os.time() - 60 end
                end)
            end
            -- builds present now: every owner of a piece we saw (new builds become known for the next pass)
            known, knownOwners = seen, owners
            if burst and os.time() >= burst.stopAt then stopBurst() end
            if fresh >= COLLAPSE_MIN_PIECES and not burst and os.time() - lastBurst >= COLLAPSE_EVERY then
                pcall(function()
                    local l = freshComp:K2_GetComponentLocation()
                    startBurst(freshComp, { X = l.X, Y = l.Y, Z = l.Z })
                end)
            end
        end
    end
    local dt = os.clock() - t0
    passes = passes + 1
    if dt > worstPass then worstPass = dt end
    skipTicks = math.min(3, math.floor(dt * 1000 / 8))   -- 8 ms+ pass: wait 1 extra tick, up to 3
    if os.time() - lastStatus >= 15 then
        lastStatus = os.time()
        writeStatus(dt)
    end
end

-- Show a line in the in-game chat box (visible to everyone in the session).
local function notify(text)
    local ok, err = pcall(function()
        local lib = StaticFindObject("/Script/Engine.Default__KismetTextLibrary")
        local msg = lib:Conv_StringToText(text)
        for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
            if pc:IsValid() and pc:IsLocalPlayerController() then
                pc:SendChatMessage(1, msg)   -- 1 = global chat
                return
            end
        end
        error("no local player controller")
    end)
    notifyResult = ok and "ok" or ("failed: " .. tostring(err))
    writeStatus(0)
end

LoopAsync(INTERVAL_MS, function()
    -- A queued pass can be dropped when the game changes map; don't wait on it forever.
    if skipTicks > 0 then skipTicks = skipTicks - 1 return false end
    if enabled and (queuedAt == 0 or os.time() - queuedAt > 3) then
        queuedAt = os.time()
        ExecuteInGameThread(function()
            pcall(pass)
            queuedAt = 0
        end)
    end
    return false
end)

RegisterKeyBind(Key.NINE, function()
    enabled = not enabled
    ExecuteInGameThread(function()
        notify("[SolidDebris] loose bricks are now " .. (enabled and "SOLID (mod ON)" or "pass-through (mod OFF)"))
    end)
end)

print("[SolidDebris] loaded\n")
