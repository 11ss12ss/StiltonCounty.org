-- Medical settings. Health runs from 0 (dead) to 1 (full).
return {
    -- multipliers on the game's own character settings (1.0 = unchanged)
    CollisionDamageMult = 1.0,   -- damage from hard impacts: being hit by vehicles or bricks, being thrown around
    RadialDamageMult    = 1.0,   -- damage from explosions
    AutoHealDelayMult   = 6.0,   -- how long before a hurt character starts recovering on its own
    AutoHealTimeMult    = 4.0,   -- how long that natural recovery takes

    -- knock-out (added by this mod; the game on its own goes straight from hurt to dead)
    KnockoutEnabled = true,
    KnockoutBelow   = 0.6,       -- alive with health at or below this: knocked out
    WakeAbove       = 0.8,       -- health back above this: you come round
    TryLimp         = true,      -- also ask the game to put the character in its unconscious pose
    BlackoutFadeIn  = 0.6,       -- seconds to fade to black
    BlackoutFadeOut = 2.0,       -- seconds to fade back in
}
