-- Medical for Brick Rigs (UE4SS Lua mod) - loader
-- Makes injuries matter: hard impacts and crashes hurt far more, and characters recover slowly on
-- their own, so an unconscious player needs someone with a first aid kit. Run it on the host.
-- Behaviour lives in logic.lua and the numbers in settings.lua; both are re-read when version.txt changes.

local DIR = [[C:\Program Files (x86)\Steam\steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64\ue4ss\Mods\Medical\Scripts\]]
MED = MED or {}
pcall(function()
    local here = debug.getinfo(1, "S").source:match("^@?(.*[\\/])[^\\/]+$")
    local f = here and io.open(here .. "main.lua", "r")
    if f then f:close() else here = nil end
    if here then DIR = here:gsub("/", "\\") end
end)
MED.dir = DIR
local loadedVersion = nil
local queuedAt = 0

local function readVersion()
    local f = io.open(DIR .. "version.txt", "r")
    if not f then return "none" end
    local v = f:read("*a") or ""
    f:close()
    return v
end

local function tick()
    local v = readVersion()
    if v ~= loadedVersion then
        loadedVersion = v
        local ok, err = pcall(dofile, DIR .. "logic.lua")
        if not ok then print("[Medical] logic error: " .. tostring(err) .. "\n") end
    end
    if MED.pass then
        local ok, err = pcall(MED.pass)
        if not ok and MED.note then MED.note("ERROR in pass: " .. tostring(err)) end
    end
end

LoopAsync(500, function()
    -- A queued tick can be dropped when the game changes map; don't wait on it forever.
    if queuedAt == 0 or os.time() - queuedAt > 4 then
        queuedAt = os.time()
        ExecuteInGameThread(function() pcall(tick) queuedAt = 0 end)
    end
    return false
end)

print("[Medical] loaded\n")
