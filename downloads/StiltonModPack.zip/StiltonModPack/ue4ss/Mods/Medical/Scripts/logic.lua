-- Medical logic (re-read by main.lua whenever version.txt changes)
local DIR = MED.dir
local STATUS = DIR .. "..\\status.txt"

MED.vanilla = MED.vanilla or {}     -- settings object name -> the game's original values
MED.applied = {}                    -- settings objects retuned by this copy of the logic
MED.kitLogged = MED.kitLogged or false

function MED.note(s)
    local f = io.open(STATUS, "a")
    if f then f:write(os.date() .. "  " .. s .. "\n") f:close() end
end

local okS, S = pcall(dofile, DIR .. "settings.lua")
if not okS or type(S) ~= "table" then MED.note("settings.lua could not be read: " .. tostring(S)) S = nil end

-- The settings object ("class default object") behind a character's StaticInfoClass.
local function settingsFor(ch)
    local cls = ch.StaticInfoClass
    if not (cls and cls:IsValid()) then return nil end
    local okC, cdo = pcall(function() return cls:GetCDO() end)
    if okC and cdo and cdo:IsValid() then return cdo end
    -- fall back to looking it up by name: "<package>.Default__<class>"
    local full = cls:GetFullName()                      -- e.g. "BlueprintGeneratedClass /Game/X/BP_Y.BP_Y_C"
    local pkg, name = full:match("^%S+%s+(.-)%.([^%.]+)$")
    if not pkg then return nil end
    local obj = StaticFindObject(pkg .. ".Default__" .. name)
    if obj and obj:IsValid() then return obj end
    return nil
end

local function describe(v)
    return string.format("max health %.0f, impact damage x%.2f, explosion damage x%.2f, self-heal after %.0fs over %.0fs",
        v.MaxHealth, v.Collision, v.Radial, v.HealDelay, v.HealTime)
end

local function retune(info)
    local name = info:GetFullName()
    if MED.applied[name] then return end
    MED.applied[name] = true
    local v = MED.vanilla[name]
    if not v then
        v = { MaxHealth = info.MaxHealth, Collision = info.CollisionDamageScale, Radial = info.RadialDamageScale,
              HealDelay = info.AutoHealDelay, HealTime = info.AutoHealTime, MinDamage = info.MinDamage, RunOver = info.RunOverSpeed }
        MED.vanilla[name] = v
        MED.note("found " .. name)
        MED.note(string.format("  vanilla: %s, min damage %.1f, run-over speed %.0f", describe(v), v.MinDamage, v.RunOver))
    end
    info.CollisionDamageScale = v.Collision * S.CollisionDamageMult
    info.RadialDamageScale    = v.Radial * S.RadialDamageMult
    info.AutoHealDelay        = v.HealDelay * S.AutoHealDelayMult
    info.AutoHealTime         = v.HealTime * S.AutoHealTimeMult
    MED.note("  now:     " .. describe({ MaxHealth = info.MaxHealth, Collision = info.CollisionDamageScale, Radial = info.RadialDamageScale,
        HealDelay = info.AutoHealDelay, HealTime = info.AutoHealTime }))
end

function MED.pass()
    if not S then return end
    if S.KnockoutEnabled then
        local okB, errB = pcall(MED.blackout)
        if not okB and not MED.blackErr then MED.blackErr = true MED.note("blackout failed: " .. tostring(errB)) end
    end
    -- the settings below only need checking now and then
    MED.n = (MED.n or 0) + 1
    if MED.n % 4 ~= 1 then return end
    for _, ch in ipairs(FindAllOf("BaseCharacter") or {}) do
        if ch:IsValid() then
            local ok, err = pcall(function()
                local info = settingsFor(ch)
                if info then retune(info) end
            end)
            if not ok and not MED.err then MED.err = true MED.note("ERROR reading character settings: " .. tostring(err)) end
        end
    end
    -- record how the first aid kit is set up, once, so its numbers can be tuned later
    if not MED.kitLogged then
        pcall(function()
            for _, kit in ipairs(FindAllOf("FirstAidKit") or {}) do
                if kit:IsValid() then
                    local info = kit:GetStaticInfo()
                    if info and info:IsValid() then
                        MED.kitLogged = true
                        MED.note(string.format("first aid kit: %.0f health per bandage, starts after %.1fs, takes %.1fs", info.HealthPerBandage, info.HealDelay, info.HealTime))
                        return
                    end
                end
            end
        end)
    end
end

-- Knock-out: the game itself takes a character straight from hurt to dead, so the mod adds the
-- in-between. When your character is alive but its health is at or below KnockoutBelow, you are
-- knocked out: the screen goes black, you cannot move or look, and (if the game allows it) the
-- character goes limp. You come round when health is back above WakeAbove - from a first aid kit
-- or slow natural healing.
local BLACK = { R = 0.0, G = 0.0, B = 0.0, A = 1.0 }

local function setLimp(ch, limp)
    if not S.TryLimp then return end
    local ok, err = pcall(function()
        ch.StateOfHealth = limp and 1 or 0          -- 0 conscious, 1 unconscious, 2 dead
        ch:OnStateOfHealthChanged()
    end)
    if not ok and not MED.limpErr then MED.limpErr = true MED.note("could not change the character's pose: " .. tostring(err)) end
end

function MED.blackout()
    local pc = nil
    for _, c in ipairs(FindAllOf("BrickPlayerController") or {}) do
        if c:IsValid() and c:IsLocalPlayerController() then pc = c break end
    end
    if not pc then return end
    local ch = pc.PlayerCharacter
    local st, hp, seen = nil, nil, "no character"
    if ch and ch:IsValid() then
        st = ch.StateOfHealth
        local okH, h = pcall(function() return ch:GetHealth() end)
        if okH then hp = h end
        seen = string.format("state=%s health=%s", tostring(st), hp and string.format("%.1f", hp) or "?")
    end
    -- record every change in what the game reports, so the trigger can be checked afterwards
    if seen ~= MED.lastSeen then MED.lastSeen = seen MED.note("your character: " .. seen) end

    local alive = (st ~= nil and st ~= 2 and hp ~= nil)
    local want = MED.ko or false
    if not alive then
        want = false                                   -- dead or no character: the game's own screens take over
    elseif MED.ko then
        if hp >= S.WakeAbove then want = false end     -- recovered enough to come round
    elseif hp <= S.KnockoutBelow then
        want = true
    end
    if want == (MED.ko or false) then return end
    MED.ko = want
    local cam = pc.PlayerCameraManager
    if want then
        if cam and cam:IsValid() then cam:StartCameraFade(0.0, 1.0, S.BlackoutFadeIn, BLACK, false, true) end   -- fade to black and hold
        pcall(function() pc:SetIgnoreMoveInput(true) pc:SetIgnoreLookInput(true) end)
        setLimp(ch, true)
        MED.note(string.format("KNOCKED OUT at health %.2f: screen black, controls locked", hp))
    else
        if cam and cam:IsValid() then cam:StartCameraFade(1.0, 0.0, S.BlackoutFadeOut, BLACK, false, false) end -- fade back in
        pcall(function() pc:ResetIgnoreMoveInput() pc:ResetIgnoreLookInput() end)
        if alive and ch and ch:IsValid() then setLimp(ch, false) end
        MED.note("knock-out ended (" .. (alive and string.format("health %.2f", hp) or "character gone") .. "): screen and controls restored")
    end
end

MED.note("logic loaded")
