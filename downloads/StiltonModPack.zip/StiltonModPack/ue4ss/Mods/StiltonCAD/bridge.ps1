# StiltonCAD bridge: reads the Stilton County CAD (Firestore) and writes a text panel for the Brick Rigs mod.
# Started by the mod; exits on its own when Brick Rigs closes. Signs in the same way the website does (anonymous Firebase sign-in).
param([string]$Dir)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$panelPath = Join-Path $Dir 'cad_panel.txt'
$logPath   = Join-Path $Dir 'bridge_log.txt'
$cfgPath   = Join-Path $Dir 'cad_config.txt'
$cmdPath   = Join-Path $Dir 'cad_cmd.txt'
$tokPath   = Join-Path $Dir 'bridge_token.txt'
$pidPath   = Join-Path $Dir 'bridge_pid.txt'
$idPath    = Join-Path $Dir 'cad_identity.txt'
$LOGIN_PORT = 47821
$verPath   = Join-Path $Dir 'Scripts\version.txt'
$SITE      = 'https://stiltoncounty.org'
$STATUSES  = @('Available', 'En route', 'On scene', 'Busy')
$GRACE_MS  = 180000
$script:hotUntil = [datetime]::MinValue

function Log($m) {
    try { Add-Content -Path $logPath -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) } catch {}
}
function NowMs { [int64]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) }
function ReadText($p) { if (Test-Path $p) { return [IO.File]::ReadAllText($p) } else { return '' } }

# Only one bridge at a time: the newest one replaces any older one.
try {
    $old = (ReadText $pidPath).Trim()
    if ($old -and ($old -ne "$PID")) {
        $proc = Get-Process -Id ([int]$old) -ErrorAction SilentlyContinue
        if ($proc -and $proc.ProcessName -like 'powershell*') { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    }
} catch {}
[IO.File]::WriteAllText($pidPath, "$PID")
$startVersion = ReadText $verPath
Log "bridge started (pid $PID)"

function ReadConfig {
    $c = @{ discord_id = ''; name = ''; callsign = ''; dept = 'Police'; allow_actions = 'false' }
    # identity from the Discord login first, then anything typed into cad_config.txt on top of it
    foreach ($path in @($idPath, $cfgPath)) {
        foreach ($line in ((ReadText $path) -split "`r?`n")) {
            if ($line -match '^\s*([a-z_]+)\s*=\s*(.*?)\s*$' -and $Matches[2] -ne '') { $c[$Matches[1]] = $Matches[2] }
        }
    }
    # logging in with Discord is what switches the quick actions on
    if ((ReadText $idPath) -match 'discord_id\s*=\s*\d') { $c.allow_actions = 'true' }
    return $c
}

# Firebase project settings come from the website itself, so nothing is copied into this mod.
$script:apiKey = $null; $script:project = $null; $script:clientId = $null; $script:guildId = $null
function LoadSite {
    $html = (Invoke-WebRequest -Uri "$SITE/" -UseBasicParsing).Content
    $m = [regex]::Match($html, 'src="([^"]*app\.js[^"]*)"')
    $appUrl = if ($m.Success) { $m.Groups[1].Value } else { 'app.js' }
    if ($appUrl -notmatch '^https?://') { $appUrl = "$SITE/" + $appUrl.TrimStart('/') }
    $js = (Invoke-WebRequest -Uri $appUrl -UseBasicParsing).Content
    $k = [regex]::Match($js, 'apiKey\s*:\s*"([^"]+)"')
    $p = [regex]::Match($js, 'projectId\s*:\s*"([^"]+)"')
    if (-not ($k.Success -and $p.Success)) { throw 'could not find the Firebase settings on the website' }
    $script:apiKey = $k.Groups[1].Value
    $script:project = $p.Groups[1].Value
    $ci = [regex]::Match($js, 'DISCORD_CLIENT_ID\s*:\s*"(\d+)"')
    $gi = [regex]::Match($js, 'GUILD_ID\s*:\s*"(\d+)"')
    if ($ci.Success) { $script:clientId = $ci.Groups[1].Value }
    if ($gi.Success) { $script:guildId = $gi.Groups[1].Value }
    Log "site settings loaded (project $($script:project))"
}

$script:idToken = $null; $script:tokenExpires = [datetime]::MinValue
function GetToken {
    if ($script:idToken -and ((Get-Date) -lt $script:tokenExpires)) { return $script:idToken }
    $refresh = (ReadText $tokPath).Trim()
    if ($refresh) {
        try {
            $r = Invoke-RestMethod -Method Post -Uri "https://securetoken.googleapis.com/v1/token?key=$($script:apiKey)" -ContentType 'application/x-www-form-urlencoded' -Body "grant_type=refresh_token&refresh_token=$refresh"
            $script:idToken = $r.id_token
            $script:tokenExpires = (Get-Date).AddSeconds([int]$r.expires_in - 300)
            [IO.File]::WriteAllText($tokPath, $r.refresh_token)
            return $script:idToken
        } catch { Log "token refresh failed, signing in again: $($_.Exception.Message)" }
    }
    $r = Invoke-RestMethod -Method Post -Uri "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$($script:apiKey)" -ContentType 'application/json' -Body '{"returnSecureToken":true}'
    $script:idToken = $r.idToken
    $script:tokenExpires = (Get-Date).AddSeconds([int]$r.expiresIn - 300)
    [IO.File]::WriteAllText($tokPath, $r.refreshToken)
    Log 'signed in (anonymous)'
    return $script:idToken
}

function Base { "https://firestore.googleapis.com/v1/projects/$($script:project)/databases/(default)/documents" }
function Headers { @{ Authorization = "Bearer $(GetToken)" } }

function Val($v) {
    if ($null -eq $v) { return $null }
    $names = $v.PSObject.Properties.Name
    if ($names -contains 'stringValue')  { return [string]$v.stringValue }
    if ($names -contains 'integerValue') { return [double]$v.integerValue }
    if ($names -contains 'doubleValue')  { return [double]$v.doubleValue }
    if ($names -contains 'booleanValue') { return [bool]$v.booleanValue }
    if ($names -contains 'arrayValue') {
        $out = @()
        if ($v.arrayValue -and ($v.arrayValue.PSObject.Properties.Name -contains 'values')) { foreach ($x in $v.arrayValue.values) { $out += , (Val $x) } }
        return , $out
    }
    return $null
}
function Doc($d) {
    $o = @{ id = ($d.name -split '/')[-1] }
    if ($d.PSObject.Properties.Name -contains 'fields') { foreach ($p in $d.fields.PSObject.Properties) { $o[$p.Name] = Val $p.Value } }
    return $o
}
# Read the newest documents of a collection whose $field is at least $min. Asking only for recent
# documents matters: Firestore bills (and rate-limits) per document read, and this runs constantly.
function Query($collection, $field, $min, $limit) {
    $q = @{
        from    = @(@{ collectionId = $collection })
        where   = @{ fieldFilter = @{ field = @{ fieldPath = $field }; op = 'GREATER_THAN_OR_EQUAL'; value = @{ integerValue = "$([int64]$min)" } } }
        orderBy = @(@{ field = @{ fieldPath = $field }; direction = 'DESCENDING' })
        limit   = $limit
    }
    $body = @{ structuredQuery = $q } | ConvertTo-Json -Depth 10
    $r = Invoke-RestMethod -Method Post -Uri ((Base) + ':runQuery') -Headers (Headers) -ContentType 'application/json' -Body $body
    $docs = @()
    foreach ($e in @($r)) { if ($e -and ($e.PSObject.Properties.Name -contains 'document')) { $docs += , (Doc $e.document) } }
    return $docs
}
# Read only the documents of a collection whose $field is one of $values (e.g. calls that are still open).
function QueryIn($collection, $field, $values, $limit) {
    $q = @{
        from  = @(@{ collectionId = $collection })
        where = @{ fieldFilter = @{ field = @{ fieldPath = $field }; op = 'IN'; value = @{ arrayValue = @{ values = @($values | ForEach-Object { @{ stringValue = $_ } }) } } } }
        limit = $limit
    }
    $body = @{ structuredQuery = $q } | ConvertTo-Json -Depth 12
    $r = Invoke-RestMethod -Method Post -Uri ((Base) + ':runQuery') -Headers (Headers) -ContentType 'application/json' -Body $body
    $docs = @()
    foreach ($e in @($r)) { if ($e -and ($e.PSObject.Properties.Name -contains 'document')) { $docs += , (Doc $e.document) } }
    return $docs
}

# --- Staying inside Firestore's free allowance -------------------------------------------------
# The free plan allows a limited number of document reads per day for the whole project (website
# included). This helper counts its own reads per day and slows itself down as it nears its share.
$DAILY_READS   = 8000      # this PC's share of the daily allowance
$ALERTS_HOT_MS = 2000      # calls + panics refresh while something just happened
$ALERTS_MS     = 6000      # calls + panics refresh otherwise
$UNITS_MS      = 15000     # units-on-duty refresh
$readsPath = Join-Path $Dir 'bridge_reads.txt'
$script:readsDay = ''; $script:readsToday = 0
function CountReads($n) {
    $today = Get-Date -Format 'yyyy-MM-dd'
    if ($script:readsDay -ne $today) {
        $script:readsDay = $today; $script:readsToday = 0
        $saved = (ReadText $readsPath).Trim()
        if ($saved -match "^$today=(\d+)$") { $script:readsToday = [int]$Matches[1] }
    }
    $script:readsToday += $n
    try { [IO.File]::WriteAllText($readsPath, "$today=$($script:readsToday)") } catch {}
}
function Slowdown {
    $used = $script:readsToday / $DAILY_READS
    if ($used -ge 1.0) { return 10 } elseif ($used -ge 0.85) { return 4 } elseif ($used -ge 0.6) { return 2 } else { return 1 }
}

function ListAll($collection) {
    $r = Invoke-RestMethod -Method Get -Uri ((Base) + "/$collection" + '?pageSize=300') -Headers (Headers)
    $docs = @()
    if ($r.PSObject.Properties.Name -contains 'documents') { foreach ($d in $r.documents) { $docs += , (Doc $d) } }
    return $docs
}
function Patch($path, $fields) {
    $mask = ($fields.Keys | ForEach-Object { "updateMask.fieldPaths=$_" }) -join '&'
    $f = @{}
    foreach ($k in $fields.Keys) {
        $v = $fields[$k]
        if ($v -is [array]) { $f[$k] = @{ arrayValue = @{ values = @($v | ForEach-Object { @{ stringValue = [string]$_ } }) } } }
        elseif ($v -is [string]) { $f[$k] = @{ stringValue = $v } }
        else { $f[$k] = @{ integerValue = "$([int64]$v)" } }
    }
    $body = @{ fields = $f } | ConvertTo-Json -Depth 10
    Invoke-RestMethod -Method Patch -Uri ((Base) + "/$path" + "?$mask&currentDocument.exists=true") -Headers (Headers) -ContentType 'application/json' -Body $body | Out-Null
}

function Num($x) { if ($null -eq $x) { return 0 } else { return [double]$x } }
function LastSeen($u) { [math]::Max((Num $u.seen), (Num $u.updated)) }
function EffStatus($u) {
    if ($u -and $u.status -and ($u.status -ne 'Off duty') -and (((NowMs) - (LastSeen $u)) -lt $GRACE_MS)) { return [string]$u.status }
    return 'Off duty'
}
function Age($ms) {
    $m = [math]::Max(0, [math]::Round(((NowMs) - (Num $ms)) / 60000))
    if ($m -lt 1) { return 'just now' } elseif ($m -lt 60) { return "$m min ago" } else { return ("{0}h {1}m ago" -f [math]::Floor($m / 60), ($m % 60)) }
}
function Cut($s, $n) { $s = ([string]$s -replace '\s+', ' ').Trim(); if ($s.Length -gt $n) { return $s.Substring(0, $n - 1) + '~' } else { return $s } }

$script:lastMsg = ''
$script:seenPanics = $null     # ids of panic alerts already announced (null until the first poll)

# Play an alarm through Windows when a new panic alert comes in.
function PanicAlarm($panics) {
    $ids = @($panics | ForEach-Object { $_.id })
    if ($null -eq $script:seenPanics) { $script:seenPanics = @{}; foreach ($i in $ids) { $script:seenPanics[$i] = $true }; return }
    $new = @($ids | Where-Object { -not $script:seenPanics.ContainsKey($_) })
    foreach ($i in $new) { $script:seenPanics[$i] = $true }
    if ($new.Count -eq 0) { return }
    Log "panic alert: playing alarm ($($new.Count) new)"
    try {
        $wav = Join-Path $Dir 'panic.wav'
        if (-not (Test-Path $wav)) { $wav = Join-Path $env:WINDIR 'Media\Alarm05.wav' }
        if (Test-Path $wav) {
            $player = New-Object System.Media.SoundPlayer $wav
            $script:alarmPlayer = $player   # keep a reference so it is not cleaned up mid-sound
            $player.Play()
        } else {
            1..3 | ForEach-Object { [System.Media.SystemSounds]::Hand.Play(); Start-Sleep -Milliseconds 700 }
        }
    } catch { Log "alarm failed: $($_.Exception.Message)" }
}
$script:lastBeat = [datetime]::MinValue


function WritePanelLines($lines) {
    $all = @("ts=$([int64]([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()))") + $lines
    $tmp = "$panelPath.tmp"
    [IO.File]::WriteAllLines($tmp, [string[]]$all)
    Move-Item -Path $tmp -Destination $panelPath -Force
}

function Reply($ctx, $html) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($html)
    $ctx.Response.ContentType = 'text/html; charset=utf-8'
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.Close()
}

# Log in with Discord: opens the browser, Discord sends the player back to a page served by this helper on
# this PC only. The login token is used once to read the player's Discord ID and server nickname, then dropped.
function DoLogin {
    if (-not $script:clientId) { $script:lastMsg = 'Login is not available: the website settings are missing.'; return }
    Add-Type -AssemblyName System.Web
    $state = [guid]::NewGuid().ToString('N')
    $redirect = "http://localhost:$LOGIN_PORT/"
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add($redirect)
    try { $listener.Start() } catch { $script:lastMsg = "Login could not start (port $LOGIN_PORT is busy)."; Log "login listener failed: $($_.Exception.Message)"; return }
    try {
        WritePanelLines @('T|STILTON COUNTY CAD', 'M|Waiting for your Discord login...', 'B|A browser window has opened. Approve the login there,', 'B|then come back to the game.')
        Start-Process ("https://discord.com/oauth2/authorize?client_id=$($script:clientId)&response_type=token&scope=identify+guilds.members.read&redirect_uri=" + [uri]::EscapeDataString($redirect) + "&state=$state")
        $page = '<!doctype html><html><head><meta charset="utf-8"><title>Stilton CAD login</title></head><body style="font-family:sans-serif;background:#16181d;color:#eee;text-align:center;padding-top:15vh"><h2>Stilton County CAD</h2><p id="m">Finishing login...</p><script>var h=location.hash.slice(1);var m=document.getElementById("m");if(h){fetch("/t?"+h).then(function(r){return r.text()}).then(function(t){m.textContent=t;history.replaceState(null,"","/")}).catch(function(){m.textContent="Could not reach the game helper. Go back to Brick Rigs and try again."})}else{m.textContent="No login was received. Go back to Brick Rigs and click Log in again."}</script></body></html>'
        $deadline = (Get-Date).AddSeconds(150)
        $task = $listener.GetContextAsync()
        $done = $false
        while (-not $done -and ((Get-Date) -lt $deadline)) {
            if (-not $task.Wait(500)) { continue }
            $ctx = $task.Result
            $task = $listener.GetContextAsync()
            if ($ctx.Request.Url.AbsolutePath -ne '/t') { Reply $ctx $page; continue }
            $q = [System.Web.HttpUtility]::ParseQueryString($ctx.Request.Url.Query)
            $done = $true
            if ($q['error']) { Reply $ctx 'Login was cancelled. You can close this tab.'; $script:lastMsg = 'Discord login was cancelled.'; break }
            if (($q['state'] -ne $state) -or (-not $q['access_token'])) { Reply $ctx 'Login could not be verified. Go back to Brick Rigs and try again.'; $script:lastMsg = 'Discord login could not be verified.'; break }
            try {
                $h = @{ Authorization = "Bearer $($q['access_token'])" }
                $user = Invoke-RestMethod -Uri 'https://discord.com/api/v10/users/@me' -Headers $h
                $name = if ($user.global_name) { $user.global_name } else { $user.username }
                if ($script:guildId) {
                    try {
                        $member = Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me/guilds/$($script:guildId)/member" -Headers $h
                        if ($member.nick) { $name = $member.nick }
                    } catch {
                        Reply $ctx 'You need to be a member of the Republic of Stilton Discord to use the CAD.'
                        $script:lastMsg = 'Login refused: not a member of the ROS Discord.'
                        break
                    }
                }
                $name = ([string]$name -replace '[\r\n=]', ' ').Trim()
                [IO.File]::WriteAllLines($idPath, [string[]]@("discord_id=$($user.id)", "name=$name"))
                Reply $ctx "Logged in as $([System.Web.HttpUtility]::HtmlEncode($name)). You can close this tab and go back to Brick Rigs."
                $script:lastMsg = "Logged in as $name"
                Log "logged in as $name ($($user.id))"
            } catch {
                Reply $ctx 'Discord did not answer. Go back to Brick Rigs and try again.'
                $script:lastMsg = 'Login failed: Discord did not answer.'
                Log "login failed: $($_.Exception.Message)"
            }
        }
        if (-not $done) { $script:lastMsg = 'Login timed out. Click Log in to try again.' }
    } finally {
        try { $listener.Stop(); $listener.Close() } catch {}
    }
}

$script:selected = ''      # id of the highlighted panic/call ("p:<id>" or "c:<id>")

# Everything a unit can respond to, panics first, in the order the panel lists them.
function Targets($calls, $panics) {
    $t = @()
    foreach ($p in $panics) { $t += , @{ key = "p:$($p.id)"; kind = 'panic'; doc = $p } }
    $n = 0
    foreach ($c in $calls) { $n++; if ($n -gt 5) { break }; $t += , @{ key = "c:$($c.id)"; kind = 'call'; doc = $c } }
    return $t
}
function Selected($calls, $panics) {
    $t = @(Targets $calls $panics)
    if ($t.Count -eq 0) { $script:selected = ''; return $null }
    $cur = $t | Where-Object { $_.key -eq $script:selected } | Select-Object -First 1
    if (-not $cur) {
        # default: the first one nobody is handling yet, else the first
        $cur = $t | Where-Object { ($_.kind -eq 'panic' -and $_.doc.status -eq 'active') -or ($_.kind -eq 'call' -and $_.doc.status -eq 'open') } | Select-Object -First 1
        if (-not $cur) { $cur = $t[0] }
        $script:selected = $cur.key
    }
    return $cur
}

# Redraw the panel from the data we already hold (used to show a change before the network confirms it).
$script:cur = $null
function Redraw { if ($script:cur) { try { BuildPanel $script:cur.cfg $script:cur.calls $script:cur.units $script:cur.panics $script:cur.me } catch {} } }

function DoCommands($cfg, $calls, $panics, $me) {
    if (-not (Test-Path $cmdPath)) { return }
    $lines = @((ReadText $cmdPath) -split "`r?`n" | Where-Object { $_.Trim() })
    Remove-Item $cmdPath -Force -ErrorAction SilentlyContinue
    foreach ($cmd in $lines) {
        $script:hotUntil = (Get-Date).AddSeconds(30)
        try {
            if ($cmd.Trim() -eq 'login') {
                if ($cfg.discord_id) { $script:lastMsg = "Already logged in as $($cfg.name)" } else { DoLogin }
                continue
            }
            if (-not $cfg.discord_id) { $script:lastMsg = 'Click Log in first'; continue }
            if ($cmd.Trim() -eq 'select_next') {
                $t = @(Targets $calls $panics)
                if ($t.Count -eq 0) { $script:lastMsg = 'Nothing to select'; continue }
                $cur = Selected $calls $panics
                $i = 0; for ($k = 0; $k -lt $t.Count; $k++) { if ($t[$k].key -eq $cur.key) { $i = $k } }
                $script:selected = $t[($i + 1) % $t.Count].key
                $script:lastMsg = ''
                Redraw
                continue
            }
            if ($cfg.allow_actions -ne 'true') { $script:lastMsg = 'Actions are off. Set allow_actions=true in cad_config.txt'; continue }
            if (-not $cfg.callsign) { $script:lastMsg = 'Go on duty on the website first so the CAD knows your callsign'; continue }
            if ((EffStatus $me) -eq 'Off duty') { $script:lastMsg = 'You are off duty. Go on duty on the website first.'; continue }
            switch ($cmd.Trim()) {
                'status_next' {
                    $i = [array]::IndexOf($STATUSES, [string]$me.status)
                    $next = $STATUSES[($i + 1) % $STATUSES.Count]
                    $now = NowMs
                    $before = $me.status
                    # show it first, then send it; put it back if the CAD refuses
                    $me.status = $next; $me.updated = $now; $me.seen = $now
                    $script:lastMsg = "Status set to $next"
                    Redraw
                    try { Patch "units/$($cfg.discord_id)" @{ status = $next; updated = $now; seen = $now } }
                    catch { $me.status = $before; throw }
                }
                'respond_top' {
                    $sel = Selected $calls $panics
                    if (-not $sel) { $script:lastMsg = 'There is nothing to respond to'; break }
                    $who = if ($cfg.name) { $cfg.name } else { $cfg.callsign }
                    $now = NowMs
                    if ($sel.kind -eq 'panic') {
                        $p = $sel.doc
                        $unitsNow = @(); if ($p.units) { $unitsNow = @($p.units) }
                        $list = @(@($unitsNow + $cfg.callsign) | Select-Object -Unique | Select-Object -First 8)
                        Patch "panics/$($p.id)" @{ units = $list; status = 'acknowledged'; cleared_by = $cfg.callsign; updated = $now }
                        $p.units = $list; $p.status = 'acknowledged'
                        $script:lastMsg = "Responding to PANIC: $(Cut $p.callsign 12)"
                    } else {
                        $c = $sel.doc
                        Patch "calls/$($c.id)" @{ status = 'responding'; unit = $cfg.callsign; unit_name = (Cut $who 80); updated = $now }
                        $c.status = 'responding'; $c.unit = $cfg.callsign
                        $script:lastMsg = "Responding to: $(Cut $c.location 40)"
                    }
                    # show the unit as on the way
                    if ($me.status -ne 'En route') {
                        try { Patch "units/$($cfg.discord_id)" @{ status = 'En route'; updated = $now; seen = $now }; $me.status = 'En route'; $me.updated = $now; $me.seen = $now } catch { Log "could not set En route: $($_.Exception.Message)" }
                    }
                }
                'break_away' {
                    # leave whatever you are attached to: the highlighted one if it is yours, otherwise any that is
                    $mine = { param($t) ($t.kind -eq 'call' -and (($t.doc.unit -eq $cfg.callsign) -or ($t.doc.units -and (@($t.doc.units) -contains $cfg.callsign)))) -or ($t.kind -eq 'panic' -and $t.doc.units -and (@($t.doc.units) -contains $cfg.callsign)) }
                    $all = @(Targets $calls $panics)
                    $sel = Selected $calls $panics
                    $target = $null
                    if ($sel -and (& $mine $sel)) { $target = $sel } else { $target = $all | Where-Object { & $mine $_ } | Select-Object -First 1 }
                    if (-not $target) { $script:lastMsg = 'You are not attached to a call'; break }
                    $now = NowMs
                    $d = $target.doc
                    $left = @(); if ($d.units) { $left = @(@($d.units) | Where-Object { $_ -ne $cfg.callsign }) }
                    if ($target.kind -eq 'panic') {
                        $st = if ($left.Count -gt 0) { 'acknowledged' } else { 'active' }
                        Patch "panics/$($d.id)" @{ units = $left; status = $st; updated = $now }
                        $d.units = $left; $d.status = $st
                        $script:lastMsg = "You left the panic: $(Cut $d.callsign 12)"
                    } else {
                        $fields = @{ updated = $now }
                        if ($d.units) { $fields.units = $left; $d.units = $left }
                        if ($d.unit -eq $cfg.callsign) {
                            # hand it to another attached unit if there is one, otherwise it goes back to waiting
                            if ($left.Count -gt 0) { $fields.unit = [string]$left[0]; $fields.unit_name = ''; $d.unit = $left[0] }
                            else { $fields.unit = ''; $fields.unit_name = ''; $fields.status = 'open'; $d.unit = ''; $d.status = 'open' }
                        }
                        Patch "calls/$($d.id)" $fields
                        $script:lastMsg = "You left the call: $(Cut $d.location 36)"
                    }
                    if ($me.status -ne 'Available') {
                        try { Patch "units/$($cfg.discord_id)" @{ status = 'Available'; updated = $now; seen = $now }; $me.status = 'Available'; $me.updated = $now; $me.seen = $now } catch { Log "could not set Available: $($_.Exception.Message)" }
                    }
                }
                default { $script:lastMsg = "Unknown command: $cmd" }
            }
            Log "action '$cmd': $($script:lastMsg)"
        } catch {
            $script:lastMsg = "Action failed: $(Cut $_.Exception.Message 70)"
            Log "action '$cmd' failed: $($_.Exception.Message)"
        }
    }
}

function BuildPanel($cfg, $calls, $units, $panics, $me) {
    # Each line starts with a tag the mod uses for styling: T title, M me, A alert, H heading, B body, F footer.
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("T|STILTON COUNTY CAD     $(Get-Date -Format 'HH:mm')")
    if (-not $cfg.discord_id) {
        $L.Add('M|Not logged in  -  click Log in')
    } elseif ($cfg.callsign) {
        $L.Add("M|$(Cut $cfg.name 22)  |  $($cfg.callsign)  |  $(EffStatus $me)")
    } else {
        $L.Add("M|$(Cut $cfg.name 22)  |  off duty (go on duty on the website)")
    }
    $sel = Selected $calls $panics
    $selKey = if ($sel) { $sel.key } else { '' }
    foreach ($p in $panics) {
        $mark = if ($selKey -eq "p:$($p.id)") { '>> ' } else { '   ' }
        $who = if ($p.units -and @($p.units).Count -gt 0) { "  responding: $(Cut (@($p.units) -join ', ') 30)" } else { '  NO ONE RESPONDING' }
        $L.Add("A|$($mark)PANIC  $(Cut $p.callsign 12) ($(Cut $p.dept 8))  $(Age $p.created)")
        $L.Add("A|      $(Cut $p.location 40)$who")
    }
    $L.Add("H|CALLS  ($($calls.Count))")
    if ($calls.Count -eq 0) { $L.Add('B|No active calls') }
    $n = 0
    foreach ($c in $calls) {
        $n++; if ($n -gt 5) { $L.Add("B|+ $($calls.Count - 5) more"); break }
        $st = if ($c.status -eq 'responding') { "$(Cut $c.unit 12) responding" } else { 'WAITING' }
        $mark = if ($selKey -eq "c:$($c.id)") { '>>' } else { '  ' }
        $L.Add("B|$mark $n  $((Cut $c.dept 7).ToUpper())  $(Cut $c.location 30)")
        $L.Add("B|       $(Cut $c.details 46)")
        $L.Add("B|       $st  -  $(Age $c.created)")
    }
    $L.Add("H|UNITS ON DUTY  ($($units.Count))")
    if ($units.Count -eq 0) { $L.Add('B|No units on duty') }
    $n = 0
    foreach ($u in $units) {
        $n++; if ($n -gt 8) { $L.Add("B|+ $($units.Count - 8) more"); break }
        $L.Add(("B|{0,-9}{1,-9}{2}" -f (Cut $u.callsign 8), (Cut $u.dept 8), (EffStatus $u)))
    }
    if ($script:lastMsg) { $L.Add("F|$($script:lastMsg)") }
    if ((Slowdown) -gt 1) { $L.Add('F|CAD refresh slowed to stay inside the free database allowance') }
    $L.Add('F|Press F4 for the mouse, then click a button')
    WritePanelLines $L
}

$failures = 0
$script:haveData = $false
$script:unitsAt = $null; $script:allUnits = @(); $script:lastReadsLog = Get-Date
while ($true) {
    try {
        if (-not (Get-Process -Name 'BrickRigsSteam-Win64-Shipping' -ErrorAction SilentlyContinue)) { Log 'Brick Rigs closed, bridge exiting'; break }
        if ((ReadText $verPath) -ne $startVersion) { Log 'new version, bridge exiting so the mod restarts it'; break }
        if (-not $script:apiKey) { LoadSite }
        $cfg = ReadConfig
        $now = NowMs
        # calls and panics that are still open (closed ones are never read)
        $calls = @((QueryIn 'calls' 'status' @('open', 'responding') 30) | Where-Object { $_ -and (($now - (Num $_.created)) -lt 43200000) } |
            Sort-Object @{ Expression = { if ($null -eq $_.priority) { 2 } else { [double]$_.priority } }; Descending = $true }, @{ Expression = { Num $_.created }; Descending = $false })
        $panics = @()
        try { $panics = @((QueryIn 'panics' 'status' @('active', 'acknowledged') 10) | Where-Object { $_ -and (($now - (Num $_.created)) -lt 21600000) } | Sort-Object { Num $_.created } -Descending) } catch {}
        CountReads ([math]::Max(1, $calls.Count) + [math]::Max(1, $panics.Count))
        # units on duty change less urgently, so they are refreshed less often
        if (-not $script:unitsAt -or (((Get-Date) - $script:unitsAt).TotalMilliseconds -ge ($UNITS_MS * (Slowdown)))) {
            $script:allUnits = @(Query 'units' 'seen' ($now - $GRACE_MS) 60)
            $script:unitsAt = Get-Date
            CountReads ([math]::Max(1, $script:allUnits.Count))
        }
        $allUnits = $script:allUnits
        $units = @($allUnits | Where-Object { $_ -and (EffStatus $_) -ne 'Off duty' } | Sort-Object { [string]$_.callsign })
        $me = $null
        if ($cfg.discord_id) { $me = $allUnits | Where-Object { $_ -and $_.id -eq $cfg.discord_id } | Select-Object -First 1 }
        if ($me) {
            if (-not $cfg.callsign -and $me.callsign) { $cfg.callsign = [string]$me.callsign }
            if ($me.dept) { $cfg.dept = [string]$me.dept }
        }
        $script:cur = @{ cfg = $cfg; calls = $calls; units = $units; panics = $panics; me = $me }
        DoCommands $cfg $calls $panics $me
        # keep the duty heartbeat going while the game is open, like the website does while its tab is open
        if ($cfg.allow_actions -eq 'true' -and $me -and ((EffStatus $me) -ne 'Off duty') -and (((Get-Date) - $script:lastBeat).TotalSeconds -ge 45)) {
            try { Patch "units/$($cfg.discord_id)" @{ seen = (NowMs) }; $script:lastBeat = Get-Date } catch { Log "heartbeat failed: $($_.Exception.Message)" }
        }
        BuildPanel $cfg $calls $units $panics $me
        PanicAlarm $panics
        $script:haveData = $true
        if ($failures -gt 0) { Log 'recovered' }
        $failures = 0
    } catch {
        $failures++
        if ($failures -le 3 -or ($failures % 20) -eq 0) { Log "error ($failures): $($_.Exception.Message) [line $($_.InvocationInfo.ScriptLineNumber)]" }
        try {
            WritePanelLines @('T|STILTON COUNTY CAD', "B|Cannot reach the CAD: $(Cut $_.Exception.Message 60)", 'F|Retrying...')
        } catch {}
    }
    # Between polls, watch for key presses from the game so actions happen right away.
    # Refresh quickly while something just happened (you pressed a CAD key, or a call/panic is new or
    # was just updated) and more slowly when the CAD is quiet; slower still as the daily share runs out.
    $fresh = $false
    if ($script:haveData) {
        foreach ($d in @($calls) + @($panics)) { if ($d -and (((NowMs) - [math]::Max((Num $d.created), (Num $d.updated))) -lt 120000)) { $fresh = $true } }
    }
    $hot = $fresh -or ((Get-Date) -lt $script:hotUntil)
    $waitMs = $(if ($hot) { $ALERTS_HOT_MS } else { $ALERTS_MS }) * (Slowdown)
    if (((Get-Date) - $script:lastReadsLog).TotalMinutes -ge 10) {
        Log ("document reads today: {0} of this PC's {1} share (slowdown x{2})" -f $script:readsToday, $DAILY_READS, (Slowdown))
        $script:lastReadsLog = Get-Date
    }
    $until = (Get-Date).AddMilliseconds($waitMs)
    while ((Get-Date) -lt $until) {
        if ($script:haveData -and (Test-Path $cmdPath)) {
            try {
                $cfg = ReadConfig
                if ($me -and -not $cfg.callsign -and $me.callsign) { $cfg.callsign = [string]$me.callsign }
                $script:cur = @{ cfg = $cfg; calls = $calls; units = $units; panics = $panics; me = $me }
                DoCommands $cfg $calls $panics $me
                BuildPanel $cfg $calls $units $panics $me
            } catch { Log "command handling failed: $($_.Exception.Message)" }
        }
        Start-Sleep -Milliseconds 80
    }
}
