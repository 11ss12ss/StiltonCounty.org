# StiltonCAD bridge: reads the Stilton County CAD (Firestore) and writes a text panel for the Brick Rigs mod.
# Started by the mod; exits on its own when Brick Rigs closes. Signs in the same way the website does (anonymous Firebase sign-in).
param([string]$Dir)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$panelPath = Join-Path $Dir 'cad_panel.txt'
$logPath   = Join-Path $Dir 'bridge_log.txt'
$cfgPath   = Join-Path $Dir 'cad_config.txt'
$cmdPath   = Join-Path $Dir 'cad_cmd.txt'
$tokPath   = Join-Path $Dir 'bridge_token.txt'
$pidPath   = Join-Path $Dir 'bridge_pid.txt'
$idPath    = Join-Path $Dir 'cad_identity.txt'
$LOGIN_PORT = 47821
$verPath   = Join-Path $Dir 'Scripts\version.txt'
$SITE      = 'https://stiltoncounty.org'
$STATUSES  = @('Available', 'En route', 'On scene', 'Busy')
$GRACE_MS  = 180000
$script:hotUntil = [datetime]::MinValue

function Log($m) {
    try { Add-Content -Path $logPath -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) } catch {}
}
function NowMs { [int64]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) }
function ReadText($p) { if (Test-Path $p) { return [IO.File]::ReadAllText($p) } else { return '' } }

# Only one bridge at a time: the newest one replaces any older one.
try {
    $old = (ReadText $pidPath).Trim()
    if ($old -and ($old -ne "$PID")) {
        $proc = Get-Process -Id ([int]$old) -ErrorAction SilentlyContinue
        if ($proc -and $proc.ProcessName -like 'powershell*') { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    }
} catch {}
[IO.File]::WriteAllText($pidPath, "$PID")
$startVersion = ReadText $verPath
Log "bridge started (pid $PID)"

function ReadConfig {
    $c = @{ discord_id = ''; name = ''; callsign = ''; dept = 'Police'; allow_actions = 'false' }
    # identity from the Discord login first, then anything typed into cad_config.txt on top of it
    foreach ($path in @($idPath, $cfgPath)) {
        foreach ($line in ((ReadText $path) -split "`r?`n")) {
            if ($line -match '^\s*([a-z_]+)\s*=\s*(.*?)\s*$' -and ($Matches[2] -ne '' -or $Matches[1] -eq 'roles')) { $c[$Matches[1]] = $Matches[2] }
        }
    }
    # logging in with Discord is what switches the quick actions on
    if ((ReadText $idPath) -match 'discord_id\s*=\s*\d') { $c.allow_actions = 'true' }
    return $c
}

# Firebase project settings come from the website itself, so nothing is copied into this mod.
$script:apiKey = $null; $script:project = $null; $script:clientId = $null; $script:guildId = $null; $script:accessRoles = @()

# Who may see the CAD: 'login' (not logged in), 'relogin' (logged in before roles were saved), 'yes' or 'no'.
function Access($cfg) {
    if (-not $cfg.discord_id) { return 'login' }
    if (-not $cfg.ContainsKey('roles')) { return 'relogin' }
    $mine = @(([string]$cfg.roles) -split ',' | Where-Object { $_ })
    foreach ($r in $mine) { if ($script:accessRoles -contains $r) { return 'yes' } }
    return 'no'
}
function LoadSite {
    $html = (Invoke-WebRequest -Uri "$SITE/" -UseBasicParsing).Content
    $m = [regex]::Match($html, 'src="([^"]*app\.js[^"]*)"')
    $appUrl = if ($m.Success) { $m.Groups[1].Value } else { 'app.js' }
    if ($appUrl -notmatch '^https?://') { $appUrl = "$SITE/" + $appUrl.TrimStart('/') }
    $js = (Invoke-WebRequest -Uri $appUrl -UseBasicParsing).Content
    $k = [regex]::Match($js, 'apiKey\s*:\s*"([^"]+)"')
    $p = [regex]::Match($js, 'projectId\s*:\s*"([^"]+)"')
    if (-not ($k.Success -and $p.Success)) { throw 'could not find the Firebase settings on the website' }
    $script:apiKey = $k.Groups[1].Value
    $script:project = $p.Groups[1].Value
    $ci = [regex]::Match($js, 'DISCORD_CLIENT_ID\s*:\s*"(\d+)"')
    $gi = [regex]::Match($js, 'GUILD_ID\s*:\s*"(\d+)"')
    if ($ci.Success) { $script:clientId = $ci.Groups[1].Value }
    if ($gi.Success) { $script:guildId = $gi.Groups[1].Value }
    # Discord roles that may use the CAD: the police role and the emergency roles, same as the website
    $roles = @()
    $pr = [regex]::Match($js, 'POLICE_ROLE_ID\s*:\s*"(\d+)"')
    if ($pr.Success) { $roles += $pr.Groups[1].Value }
    $er = [regex]::Match($js, 'EMERGENCY_ROLE_IDS\s*:\s*\[([^\]]*)\]')
    if ($er.Success) { foreach ($m in [regex]::Matches($er.Groups[1].Value, '\d+')) { $roles += $m.Value } }
    $script:accessRoles = @($roles | Select-Object -Unique)
    Log "CAD roles from the website: $($script:accessRoles.Count)"
    Log "site settings loaded (project $($script:project))"
}

$script:idToken = $null; $script:tokenExpires = [datetime]::MinValue
function GetToken {
    if ($script:idToken -and ((Get-Date) -lt $script:tokenExpires)) { return $script:idToken }
    $refresh = (ReadText $tokPath).Trim()
    if ($refresh) {
        try {
            $r = Invoke-RestMethod -Method Post -Uri "https://securetoken.googleapis.com/v1/token?key=$($script:apiKey)" -ContentType 'application/x-www-form-urlencoded' -Body "grant_type=refresh_token&refresh_token=$refresh"
            $script:idToken = $r.id_token
            $script:tokenExpires = (Get-Date).AddSeconds([int]$r.expires_in - 300)
            [IO.File]::WriteAllText($tokPath, $r.refresh_token)
            return $script:idToken
        } catch { Log "token refresh failed, signing in again: $($_.Exception.Message)" }
    }
    $r = Invoke-RestMethod -Method Post -Uri "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$($script:apiKey)" -ContentType 'application/json' -Body '{"returnSecureToken":true}'
    $script:idToken = $r.idToken
    $script:tokenExpires = (Get-Date).AddSeconds([int]$r.expiresIn - 300)
    [IO.File]::WriteAllText($tokPath, $r.refreshToken)
    Log 'signed in (anonymous)'
    return $script:idToken
}

function Base { "https://firestore.googleapis.com/v1/projects/$($script:project)/databases/(default)/documents" }
function Headers { @{ Authorization = "Bearer $(GetToken)" } }

function Val($v) {
    if ($null -eq $v) { return $null }
    $names = $v.PSObject.Properties.Name
    if ($names -contains 'stringValue')  { return [string]$v.stringValue }
    if ($names -contains 'integerValue') { return [double]$v.integerValue }
    if ($names -contains 'doubleValue')  { return [double]$v.doubleValue }
    if ($names -contains 'booleanValue') { return [bool]$v.booleanValue }
    if ($names -contains 'arrayValue') {
        $out = @()
        if ($v.arrayValue -and ($v.arrayValue.PSObject.Properties.Name -contains 'values')) { foreach ($x in $v.arrayValue.values) { $out += , (Val $x) } }
        return , $out
    }
    return $null
}
function Doc($d) {
    $o = @{ id = ($d.name -split '/')[-1] }
    if ($d.PSObject.Properties.Name -contains 'fields') { foreach ($p in $d.fields.PSObject.Properties) { $o[$p.Name] = Val $p.Value } }
    return $o
}
# Read the newest documents of a collection whose $field is at least $min. Asking only for recent
# documents matters: Firestore bills (and rate-limits) per document read, and this runs constantly.
function Query($collection, $field, $min, $limit) {
    $q = @{
        from    = @(@{ collectionId = $collection })
        where   = @{ fieldFilter = @{ field = @{ fieldPath = $field }; op = 'GREATER_THAN_OR_EQUAL'; value = @{ integerValue = "$([int64]$min)" } } }
        orderBy = @(@{ field = @{ fieldPath = $field }; direction = 'DESCENDING' })
        limit   = $limit
    }
    $body = @{ structuredQuery = $q } | ConvertTo-Json -Depth 10
    $r = Invoke-RestMethod -Method Post -Uri ((Base) + ':runQuery') -Headers (Headers) -ContentType 'application/json' -Body $body
    $docs = @()
    foreach ($e in @($r)) { if ($e -and ($e.PSObject.Properties.Name -contains 'document')) { $docs += , (Doc $e.document) } }
    return $docs
}
# Read only the documents of a collection whose $field is one of $values (e.g. calls that are still open).
function QueryIn($collection, $field, $values, $limit) {
    $q = @{
        from  = @(@{ collectionId = $collection })
        where = @{ fieldFilter = @{ field = @{ fieldPath = $field }; op = 'IN'; value = @{ arrayValue = @{ values = @($values | ForEach-Object { @{ stringValue = $_ } }) } } } }
        limit = $limit
    }
    $body = @{ structuredQuery = $q } | ConvertTo-Json -Depth 12
    $r = Invoke-RestMethod -Method Post -Uri ((Base) + ':runQuery') -Headers (Headers) -ContentType 'application/json' -Body $body
    $docs = @()
    foreach ($e in @($r)) { if ($e -and ($e.PSObject.Properties.Name -contains 'document')) { $docs += , (Doc $e.document) } }
    return $docs
}

# --- Staying inside Firestore's free allowance -------------------------------------------------
# The free plan allows a limited number of document reads per day for the whole project (website
# included). This helper counts its own reads per day and slows itself down as it nears its share.
$DAILY_READS   = 8000      # this PC's share of the daily allowance
$ALERTS_HOT_MS = 2000      # calls + panics refresh while something just happened
$ALERTS_MS     = 6000      # calls + panics refresh otherwise
$UNITS_MS      = 15000     # units-on-duty refresh
$readsPath = Join-Path $Dir 'bridge_reads.txt'
$script:readsDay = ''; $script:readsToday = 0
function CountReads($n) {
    $today = Get-Date -Format 'yyyy-MM-dd'
    if ($script:readsDay -ne $today) {
        $script:readsDay = $today; $script:readsToday = 0
        $saved = (ReadText $readsPath).Trim()
        if ($saved -match "^$today=(\d+)$") { $script:readsToday = [int]$Matches[1] }
    }
    $script:readsToday += $n
    try { [IO.File]::WriteAllText($readsPath, "$today=$($script:readsToday)") } catch {}
}
function Slowdown {
    $used = $script:readsToday / $DAILY_READS
    if ($used -ge 1.0) { return 10 } elseif ($used -ge 0.85) { return 4 } elseif ($used -ge 0.6) { return 2 } else { return 1 }
}

function ListAll($collection) {
    $r = Invoke-RestMethod -Method Get -Uri ((Base) + "/$collection" + '?pageSize=300') -Headers (Headers)
    $docs = @()
    if ($r.PSObject.Properties.Name -contains 'documents') { foreach ($d in $r.documents) { $docs += , (Doc $d) } }
    return $docs
}
function Patch($path, $fields) {
    $mask = ($fields.Keys | ForEach-Object { "updateMask.fieldPaths=$_" }) -join '&'
    $f = @{}
    foreach ($k in $fields.Keys) {
        $v = $fields[$k]
        if ($v -is [array]) { $f[$k] = @{ arrayValue = @{ values = @($v | ForEach-Object { @{ stringValue = [string]$_ } }) } } }
        elseif ($v -is [string]) { $f[$k] = @{ stringValue = $v } }
        else { $f[$k] = @{ integerValue = "$([int64]$v)" } }
    }
    $body = @{ fields = $f } | ConvertTo-Json -Depth 10
    Invoke-RestMethod -Method Patch -Uri ((Base) + "/$path" + "?$mask&currentDocument.exists=true") -Headers (Headers) -ContentType 'application/json' -Body $body | Out-Null
}

function Num($x) { if ($null -eq $x) { return 0 } else { return [double]$x } }
function LastSeen($u) { [math]::Max((Num $u.seen), (Num $u.updated)) }
function EffStatus($u) {
    if ($u -and $u.status -and ($u.status -ne 'Off duty') -and (((NowMs) - (LastSeen $u)) -lt $GRACE_MS)) { return [string]$u.status }
    return 'Off duty'
}
function Age($ms) {
    $m = [math]::Max(0, [math]::Round(((NowMs) - (Num $ms)) / 60000))
    if ($m -lt 1) { return 'just now' } elseif ($m -lt 60) { return "$m min ago" } else { return ("{0}h {1}m ago" -f [math]::Floor($m / 60), ($m % 60)) }
}
function Cut($s, $n) { $s = ([string]$s -replace '\s+', ' ').Trim(); if ($s.Length -gt $n) { return $s.Substring(0, $n - 1) + '~' } else { return $s } }

$script:lastMsg = ''
$script:seenPanics = $null     # ids of panic alerts already announced (null until the first poll)

# Play an alarm through Windows when a new panic alert comes in.
function PanicAlarm($panics) {
    $ids = @($panics | ForEach-Object { $_.id })
    if ($null -eq $script:seenPanics) { $script:seenPanics = @{}; foreach ($i in $ids) { $script:seenPanics[$i] = $true }; return }
    $new = @($ids | Where-Object { -not $script:seenPanics.ContainsKey($_) })
    foreach ($i in $new) { $script:seenPanics[$i] = $true }
    if ($new.Count -eq 0) { return }
    Log "panic alert: playing alarm ($($new.Count) new)"
    try {
        $wav = Join-Path $Dir 'panic.wav'
        if (-not (Test-Path $wav)) { $wav = Join-Path $env:WINDIR 'Media\Alarm05.wav' }
        if (Test-Path $wav) {
            $player = New-Object System.Media.SoundPlayer $wav
            $script:alarmPlayer = $player   # keep a reference so it is not cleaned up mid-sound
            $player.Play()
        } else {
            1..3 | ForEach-Object { [System.Media.SystemSounds]::Hand.Play(); Start-Sleep -Milliseconds 700 }
        }
    } catch { Log "alarm failed: $($_.Exception.Message)" }
}
$script:lastBeat = [datetime]::MinValue


function WritePanelLines($lines) {
    $all = @("ts=$([int64]([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()))") + $lines
    $tmp = "$panelPath.tmp"
    [IO.File]::WriteAllLines($tmp, [string[]]$all)
    Move-Item -Path $tmp -Destination $panelPath -Force
}

function Reply($ctx, $html) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($html)
    $ctx.Response.ContentType = 'text/html; charset=utf-8'
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.Close()
}

# Log in with Discord: opens the browser, Discord sends the player back to a page served by this helper on
# this PC only. The login token is used once to read the player's Discord ID and server nickname, then dropped.
function DoLogin {
    if (-not $script:clientId) { $script:lastMsg = 'Login is not available: the website settings are missing.'; return }
    Add-Type -AssemblyName System.Web
    $state = [guid]::NewGuid().ToString('N')
    $redirect = "http://localhost:$LOGIN_PORT/"
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add($redirect)
    try { $listener.Start() } catch { $script:lastMsg = "Login could not start (port $LOGIN_PORT is busy)."; Log "login listener failed: $($_.Exception.Message)"; return }
    try {
        WritePanelLines @('T|STILTON COUNTY CAD', 'M|Waiting for your Discord login...', 'B|A browser window has opened. Approve the login there,', 'B|then come back to the game.')
        Start-Process ("https://discord.com/oauth2/authorize?client_id=$($script:clientId)&response_type=token&scope=identify+guilds.members.read&redirect_uri=" + [uri]::EscapeDataString($redirect) + "&state=$state")
        $page = '<!doctype html><html><head><meta charset="utf-8"><title>Stilton CAD login</title></head><body style="font-family:sans-serif;background:#16181d;color:#eee;text-align:center;padding-top:15vh"><h2>Stilton County CAD</h2><p id="m">Finishing login...</p><script>var h=location.hash.slice(1);var m=document.getElementById("m");if(h){fetch("/t?"+h).then(function(r){return r.text()}).then(function(t){m.textContent=t;history.replaceState(null,"","/")}).catch(function(){m.textContent="Could not reach the game helper. Go back to Brick Rigs and try again."})}else{m.textContent="No login was received. Go back to Brick Rigs and click Log in again."}</script></body></html>'
        $deadline = (Get-Date).AddSeconds(150)
        $task = $listener.GetContextAsync()
        $done = $false
        while (-not $done -and ((Get-Date) -lt $deadline)) {
            if (-not $task.Wait(500)) { continue }
            $ctx = $task.Result
            $task = $listener.GetContextAsync()
            if ($ctx.Request.Url.AbsolutePath -ne '/t') { Reply $ctx $page; continue }
            $q = [System.Web.HttpUtility]::ParseQueryString($ctx.Request.Url.Query)
            $done = $true
            if ($q['error']) { Reply $ctx 'Login was cancelled. You can close this tab.'; $script:lastMsg = 'Discord login was cancelled.'; break }
            if (($q['state'] -ne $state) -or (-not $q['access_token'])) { Reply $ctx 'Login could not be verified. Go back to Brick Rigs and try again.'; $script:lastMsg = 'Discord login could not be verified.'; break }
            try {
                $h = @{ Authorization = "Bearer $($q['access_token'])" }
                $user = Invoke-RestMethod -Uri 'https://discord.com/api/v10/users/@me' -Headers $h
                $name = if ($user.global_name) { $user.global_name } else { $user.username }
                $roleList = ''
                if ($script:guildId) {
                    try {
                        $member = Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me/guilds/$($script:guildId)/member" -Headers $h
                        if ($member.nick) { $name = $member.nick }
                        $roleList = (@($member.roles) | Where-Object { $_ -match '^\d+$' }) -join ','
                    } catch {
                        Reply $ctx 'You need to be a member of the Republic of Stilton Discord to use the CAD.'
                        $script:lastMsg = 'Login refused: not a member of the ROS Discord.'
                        break
                    }
                }
                $name = ([string]$name -replace '[\r\n=]', ' ').Trim()
                [IO.File]::WriteAllLines($idPath, [string[]]@("discord_id=$($user.id)", "name=$name", "roles=$roleList"))
                Reply $ctx "Logged in as $([System.Web.HttpUtility]::HtmlEncode($name)). You can close this tab and go back to Brick Rigs."
                $script:lastMsg = "Logged in as $name"
                Log "logged in as $name ($($user.id))"
            } catch {
                Reply $ctx 'Discord did not answer. Go back to Brick Rigs and try again.'
                $script:lastMsg = 'Login failed: Discord did not answer.'
                Log "login failed: $($_.Exception.Message)"
            }
        }
        if (-not $done) { $script:lastMsg = 'Login timed out. Click Log in to try again.' }
    } finally {
        try { $listener.Stop(); $listener.Close() } catch {}
    }
}

# ===== Bank (roleplay money from stiltoncounty.org) ===========================================
# The website locks each bank account to the browser that opened it. Its "Link Brick Rigs" button
# hands that browser's sign-in to this helper (through a page on this PC only), so the game acts
# as the same browser and the bank's own rules apply to everything done here.
$bankPath    = Join-Path $Dir 'bank_link.txt'
$playersPath = Join-Path $Dir 'game_players.txt'
$BANK_PORT   = 47822
$script:bk = @{ id = ''; uid = ''; rt = ''; tok = $null; exp = [datetime]::MinValue
                acct = 'me'; bal = $null; coBal = $null; coName = ''; hasCo = $false
                mode = 'idle'; amount = 100; targets = @(); ti = 0
                incoming = @(); sent = @{}; msg = ''; hotUntil = [datetime]::MinValue
                balAt = [datetime]::MinValue; chgAt = [datetime]::MinValue; gamerAt = [datetime]::MinValue; gamerName = '' }

function BankLoad {
    $t = ReadText $bankPath
    $script:bk.id = ''; $script:bk.uid = ''; $script:bk.rt = ''
    foreach ($line in ($t -split "`r?`n")) {
        if ($line -match '^(id|uid|rt)=(.+)$') { $script:bk[$Matches[1]] = $Matches[2].Trim() }
    }
}
function BankLinked { return [bool]($script:bk.id -and $script:bk.uid -and $script:bk.rt) }

function BankToken {
    if ($script:bk.tok -and ((Get-Date) -lt $script:bk.exp)) { return $script:bk.tok }
    $r = Invoke-RestMethod -Method Post -Uri "https://securetoken.googleapis.com/v1/token?key=$($script:apiKey)" -ContentType 'application/x-www-form-urlencoded' -Body "grant_type=refresh_token&refresh_token=$($script:bk.rt)"
    if ([string]$r.user_id -ne $script:bk.uid) { throw 'the saved bank link belongs to a different browser' }
    $script:bk.tok = $r.id_token
    $script:bk.exp = (Get-Date).AddSeconds([int]$r.expires_in - 300)
    if ($r.refresh_token -and $r.refresh_token -ne $script:bk.rt) {
        $script:bk.rt = $r.refresh_token
        [IO.File]::WriteAllLines($bankPath, [string[]]@("id=$($script:bk.id)", "uid=$($script:bk.uid)", "rt=$($script:bk.rt)"))
    }
    return $script:bk.tok
}
function BankHeaders { @{ Authorization = "Bearer $(BankToken)" } }
function DocName($path) { "projects/$($script:project)/databases/(default)/documents/$path" }
function BankGet($path) {
    try { return Doc (Invoke-RestMethod -Method Get -Uri ((Base) + "/$path") -Headers (BankHeaders)) }
    catch { if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 404) { return $null } else { throw } }
}
function BankCommit($writes) {
    $body = @{ writes = $writes } | ConvertTo-Json -Depth 12
    Invoke-RestMethod -Method Post -Uri ((Base) + ':commit') -Headers (BankHeaders) -ContentType 'application/json' -Body $body | Out-Null
}
function NewId {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $b = New-Object byte[] 20; $rng.GetBytes($b)
    return -join ($b | ForEach-Object { $chars[$_ % 62] })
}
function SB($n) { return ('{0:N0} SB' -f [double]$n) }
function MyAcct { if ($script:bk.acct -eq 'co' -and $script:bk.hasCo) { return "c_$($script:bk.id)" } else { return $script:bk.id } }
function MyBal { if ($script:bk.acct -eq 'co' -and $script:bk.hasCo) { return $script:bk.coBal } else { return $script:bk.bal } }

# The same three writes the website's Send button makes, saved together: a ledger entry, money out
# of one account, money into the other. $extra adds one more write to the same save (a charge being paid).
function TransferWrites($from, $to, $amount, $note, $ledgerId) {
    $now = NowMs
    $acct = {
        param($id, $delta)
        @{ update = @{ name = (DocName "accounts/$id"); fields = @{ lastTx = @{ stringValue = $ledgerId }; updated = @{ integerValue = "$now" } } }
           updateMask = @{ fieldPaths = @('lastTx', 'updated') }
           updateTransforms = @(@{ fieldPath = 'bank'; increment = @{ integerValue = "$delta" } })
           currentDocument = @{ exists = $true } }
    }
    return @(
        @{ update = @{ name = (DocName "ledger/$ledgerId"); fields = @{
            type = @{ stringValue = 'transfer' }; from = @{ stringValue = $from }; to = @{ stringValue = $to }
            amount = @{ integerValue = "$amount" }; at = @{ integerValue = "$now" }; note = @{ stringValue = $note } } } },
        (& $acct $from (-$amount)),
        (& $acct $to $amount)
    )
}
function BankError($e) {
    $code = 0
    try { $code = [int]$e.Exception.Response.StatusCode } catch {}
    if ($code -eq 403) { return 'The bank refused it: not enough money, the other account is not open, or the bank rules are not updated yet.' }
    return "The bank did not answer ($(Cut $e.Exception.Message 50))."
}

function BankRefresh {
    $a = BankGet "accounts/$($script:bk.id)"
    if ($a) { $script:bk.bal = Num $a.bank } else { $script:bk.bal = $null }
    $c = BankGet "accounts/c_$($script:bk.id)"
    $script:bk.hasCo = [bool]$c
    if ($c) { $script:bk.coBal = Num $c.bank; $script:bk.coName = [string]$c.name }
    CountReads 2
    $script:bk.balAt = Get-Date
}
function BankChargesPoll {
    # charges waiting for me to answer
    $q = @{
        from  = @(@{ collectionId = 'charges' })
        where = @{ compositeFilter = @{ op = 'AND'; filters = @(
            @{ fieldFilter = @{ field = @{ fieldPath = 'payer' }; op = 'EQUAL'; value = @{ stringValue = $script:bk.id } } },
            @{ fieldFilter = @{ field = @{ fieldPath = 'status' }; op = 'EQUAL'; value = @{ stringValue = 'pending' } } }) } }
        limit = 5
    }
    $body = @{ structuredQuery = $q } | ConvertTo-Json -Depth 14
    $r = Invoke-RestMethod -Method Post -Uri ((Base) + ':runQuery') -Headers (BankHeaders) -ContentType 'application/json' -Body $body
    $docs = @()
    foreach ($e in @($r)) { if ($e -and ($e.PSObject.Properties.Name -contains 'document')) { $docs += , (Doc $e.document) } }
    $script:bk.incoming = @($docs | Where-Object { ((NowMs) - (Num $_.created)) -lt 1800000 } | Sort-Object { Num $_.created })
    CountReads ([math]::Max(1, $docs.Count))
    # charges I sent: has the customer answered?
    foreach ($cid in @($script:bk.sent.Keys)) {
        $d = BankGet "charges/$cid"
        CountReads 1
        if (-not $d) { $script:bk.sent.Remove($cid); continue }
        if ($d.status -ne 'pending') {
            $who = $script:bk.sent[$cid]
            $script:bk.sent.Remove($cid)
            switch ($d.status) {
                'paid'     { $script:bk.msg = "$who paid $(SB $d.amount)."; $script:bk.balAt = [datetime]::MinValue }
                'declined' { $script:bk.msg = "$who declined the charge of $(SB $d.amount)." }
                default    { $script:bk.msg = "Charge to $who was $($d.status)." }
            }
        }
    }
    $script:bk.chgAt = Get-Date
}
# Tell other players with the mod which in-game name belongs to this bank account.
function BankAnnounce($myName) {
    if (-not $myName) { return }
    if ($myName -eq $script:bk.gamerName -and (((Get-Date) - $script:bk.gamerAt).TotalMinutes -lt 5)) { return }
    $now = NowMs
    BankCommit @(@{ update = @{ name = (DocName "gamers/$($script:bk.id)"); fields = @{ name = @{ stringValue = (Cut $myName 80) }; seen = @{ integerValue = "$now" } } } })
    $script:bk.gamerName = $myName
    $script:bk.gamerAt = Get-Date
}
function SessionPlayers {
    $me = ''; $others = @()
    foreach ($line in ((ReadText $playersPath) -split "`r?`n")) {
        if ($line -match '^me=(.+)$') { $me = $Matches[1].Trim() }
        elseif ($line -match '^p=(.+)$') { $others += $Matches[1].Trim() }
    }
    return @{ me = $me; others = $others }
}
# Players in this game session who have linked their bank: the people you can pay or charge.
function BankTargets {
    $sp = SessionPlayers
    $here = @{}
    foreach ($n in $sp.others) { if ($n -and $n -ne $sp.me) { $here[$n.ToLowerInvariant()] = $n } }
    $list = @()
    if ($here.Count -gt 0) {
        $gamers = @(Query 'gamers' 'seen' ((NowMs) - 1800000) 100)
        CountReads ([math]::Max(1, $gamers.Count))
        foreach ($g in $gamers) {
            if ($g.id -eq $script:bk.id) { continue }
            $k = ([string]$g.name).ToLowerInvariant()
            if ($here.ContainsKey($k)) { $list += @{ id = $g.id; name = $here[$k] } }
        }
    }
    $script:bk.targets = @($list | Sort-Object { $_.name })
    $script:bk.ti = 0
}

function BankTick {
    if (-not (BankLinked)) { return }
    $hot = (Get-Date) -lt $script:bk.hotUntil
    try {
        BankAnnounce (SessionPlayers).me
        if (((Get-Date) - $script:bk.balAt).TotalSeconds -ge $(if ($hot) { 8 } else { 120 }) * (Slowdown)) { BankRefresh }
        $chgWait = $(if ($hot -or $script:bk.sent.Count -gt 0) { 4 } else { 30 }) * (Slowdown)
        if (((Get-Date) - $script:bk.chgAt).TotalSeconds -ge $chgWait) { BankChargesPoll }
    } catch {
        $script:bk.msg = BankError $_
        $script:bk.balAt = Get-Date; $script:bk.chgAt = Get-Date     # do not retry in a tight loop
        Log "bank: $($_.Exception.Message)"
    }
}

# Bank buttons from the game. Returns $true when the command was a bank command.
function BankCommand($cmd) {
    $cmd = $cmd.Trim()
    if ($cmd -notlike 'bank_*') { return $false }
    $script:bk.hotUntil = (Get-Date).AddSeconds(90)
    if ($cmd -eq 'bank_link') {
        Start-Process "$SITE/"
        $script:bk.msg = 'On the website: open Bank, then press Link Brick Rigs.'
        return $true
    }
    if (-not (BankLinked)) { $script:bk.msg = 'Link your bank first.'; return $true }
    try {
        switch -Regex ($cmd) {
            '^bank_(pay|charge)$' {
                $script:bk.mode = $Matches[1]; $script:bk.msg = ''
                BankTargets
                if ($script:bk.targets.Count -eq 0) { $script:bk.msg = 'No one in this game has linked their bank yet.' }
            }
            '^bank_next$' { if ($script:bk.targets.Count -gt 0) { $script:bk.ti = ($script:bk.ti + 1) % $script:bk.targets.Count } }
            '^bank_amt:([+-]\d+)$' { $script:bk.amount = [math]::Max(1, [math]::Min(1000000000, $script:bk.amount + [int]$Matches[1])) }
            '^bank_cancel$' { $script:bk.mode = 'idle'; $script:bk.msg = '' }
            '^bank_acct$' {
                if ($script:bk.hasCo) { $script:bk.acct = $(if ($script:bk.acct -eq 'co') { 'me' } else { 'co' }) }
                else { $script:bk.msg = 'You have no company account (open one on the website).' }
            }
            '^bank_send$' {
                if ($script:bk.targets.Count -eq 0) { $script:bk.msg = 'No one to send to.'; break }
                $t = $script:bk.targets[$script:bk.ti]
                $amt = [int64]$script:bk.amount
                $from = MyAcct
                if ($script:bk.mode -eq 'pay') {
                    if ($null -ne (MyBal) -and (MyBal) -lt $amt) { $script:bk.msg = "Not enough money: you have $(SB (MyBal))."; break }
                    BankCommit (TransferWrites $from $t.id $amt 'Brick Rigs payment' (NewId))
                    $script:bk.msg = "Sent $(SB $amt) to $($t.name)."
                    Log "bank: sent $amt to $($t.id)"
                    $script:bk.balAt = [datetime]::MinValue
                } elseif ($script:bk.mode -eq 'charge') {
                    $cid = NewId; $now = NowMs
                    $shopName = $(if ($from -like 'c_*' -and $script:bk.coName) { $script:bk.coName } else { (SessionPlayers).me })
                    BankCommit @(@{ update = @{ name = (DocName "charges/$cid"); fields = @{
                            shop = @{ stringValue = $from }; shopName = @{ stringValue = (Cut $shopName 80) }; payer = @{ stringValue = $t.id }
                            amount = @{ integerValue = "$amt" }; note = @{ stringValue = 'Brick Rigs' }; status = @{ stringValue = 'pending' }
                            created = @{ integerValue = "$now" }; updated = @{ integerValue = "$now" } } }
                        currentDocument = @{ exists = $false } })
                    $script:bk.sent[$cid] = $t.name
                    $script:bk.msg = "Asked $($t.name) to pay $(SB $amt). Waiting for them to accept..."
                    Log "bank: charge $cid of $amt to $($t.id)"
                }
                $script:bk.mode = 'idle'
            }
            '^bank_(accept|decline)$' {
                $c = @($script:bk.incoming)[0]
                if (-not $c) { $script:bk.msg = 'Nothing to answer.'; break }
                $now = NowMs
                if ($Matches[1] -eq 'accept') {
                    $amt = [int64](Num $c.amount)
                    if ($null -ne $script:bk.bal -and $script:bk.bal -lt $amt) { $script:bk.msg = "Not enough money: you have $(SB $script:bk.bal)."; break }
                    $lid = NewId
                    $w = @(TransferWrites $c.payer $c.shop $amt "Charge $($c.id)" $lid)
                    $w += @{ update = @{ name = (DocName "charges/$($c.id)"); fields = @{ status = @{ stringValue = 'paid' }; updated = @{ integerValue = "$now" }; ledger = @{ stringValue = $lid } } }
                             updateMask = @{ fieldPaths = @('status', 'updated', 'ledger') }; currentDocument = @{ exists = $true } }
                    BankCommit $w
                    $script:bk.msg = "Paid $(SB $amt) to $($c.shopName)."
                    Log "bank: paid charge $($c.id)"
                    $script:bk.balAt = [datetime]::MinValue
                } else {
                    BankCommit @(@{ update = @{ name = (DocName "charges/$($c.id)"); fields = @{ status = @{ stringValue = 'declined' }; updated = @{ integerValue = "$now" } } }
                                    updateMask = @{ fieldPaths = @('status', 'updated') }; currentDocument = @{ exists = $true } })
                    $script:bk.msg = "Declined $($c.shopName)'s charge."
                }
                $script:bk.incoming = @($script:bk.incoming | Select-Object -Skip 1)
                $script:bk.chgAt = [datetime]::MinValue
            }
        }
    } catch {
        $script:bk.msg = BankError $_
        Log "bank command '$cmd' failed: $($_.Exception.Message)"
    }
    return $true
}

# Panel lines for the bank (shown to every player, whether or not they may see the CAD).
#   Q|mode tells the game which bank buttons to show: unlinked, idle, incoming, pay, charge.
function BankLines {
    # messages fade after a while
    if ($script:bk.msg -ne $script:bk.msgSeen) { $script:bk.msgSeen = $script:bk.msg; $script:bk.msgSince = Get-Date }
    elseif ($script:bk.msg -and ((Get-Date) - $script:bk.msgSince).TotalSeconds -gt 25) { $script:bk.msg = ''; $script:bk.msgSeen = '' }
    $L = @()
    if (-not (BankLinked)) {
        $L += 'Q|unlinked'
        $L += 'K|BANK   not linked'
        if ($script:bk.msg) { $L += "K|$($script:bk.msg)" }
        return $L
    }
    $mode = $script:bk.mode
    if ($mode -eq 'idle' -and @($script:bk.incoming).Count -gt 0) { $mode = 'incoming' }
    $L += "Q|$mode"
    $which = $(if ($script:bk.acct -eq 'co' -and $script:bk.hasCo) { "company: $(Cut $script:bk.coName 20)" } else { 'personal' })
    $bal = MyBal
    $L += "K|BANK   $(if ($null -ne $bal) { SB $bal } else { '...' })   ($which)"
    if ($mode -eq 'incoming') {
        $c = @($script:bk.incoming)[0]
        $L += "K|$(Cut $c.shopName 24) asks you to pay $(SB $c.amount)"
    } elseif ($mode -eq 'pay' -or $mode -eq 'charge') {
        $verb = $(if ($mode -eq 'pay') { 'PAY' } else { 'CHARGE' })
        if ($script:bk.targets.Count -gt 0) {
            $t = $script:bk.targets[$script:bk.ti]
            $L += "K|$verb  $(Cut $t.name 24)   $(SB $script:bk.amount)"
        } else { $L += "K|$verb   $(SB $script:bk.amount)" }
    }
    if ($script:bk.msg) { $L += "K|$($script:bk.msg)" }
    return $L
}

# The local page the website's "Link Brick Rigs" button opens. It only answers on this PC.
$script:bankListener = $null; $script:bankTask = $null
function BankListen {
    if ($script:bankListener) { return }
    try {
        $l = New-Object System.Net.HttpListener
        $l.Prefixes.Add("http://localhost:$BANK_PORT/")
        $l.Start()
        $script:bankListener = $l
        $script:bankTask = $l.GetContextAsync()
    } catch { $script:bankListener = 'failed'; Log "bank link listener could not start: $($_.Exception.Message)" }
}
function BankPollLink {
    if (-not $script:bankTask -or -not $script:bankTask.IsCompleted) { return }
    $ctx = $null
    try { $ctx = $script:bankTask.Result } catch {}
    $script:bankTask = $script:bankListener.GetContextAsync()
    if (-not $ctx) { return }
    $path = $ctx.Request.Url.AbsolutePath
    if ($path -eq '/update') {
        # the "Update my mods" button on the website
        Reply $ctx (UpdatePage (WebUpdate))
        return
    }
    if ($path -ne '/bank-link') {
        $page = '<!doctype html><html><head><meta charset="utf-8"><title>Link Brick Rigs</title></head><body style="font-family:sans-serif;background:#16181d;color:#eee;text-align:center;padding-top:15vh"><h2>Stilton County bank</h2><p id="m">Linking Brick Rigs...</p><script>var h=location.hash.slice(1);var m=document.getElementById("m");history.replaceState(null,"","/bank");if(h){fetch("/bank-link?"+h).then(function(r){return r.text()}).then(function(t){m.textContent=t}).catch(function(){m.textContent="Could not reach the game. Start Brick Rigs with the Stilton Mod Pack, then press Link Brick Rigs again."})}else{m.textContent="Nothing to link. Go back to the website and press Link Brick Rigs."}</script></body></html>'
        Reply $ctx $page
        return
    }
    Add-Type -AssemblyName System.Web
    $q = [System.Web.HttpUtility]::ParseQueryString($ctx.Request.Url.Query)
    $id = [string]$q['id']; $uid = [string]$q['uid']; $rt = [string]$q['rt']
    if (-not ($id -match '^\d{15,25}$' -and $uid -and $rt)) { Reply $ctx 'The link was incomplete. Go back to the website and press Link Brick Rigs again.'; return }
    $old = $script:bk.Clone()
    try {
        if (-not $script:apiKey) { LoadSite }
        $script:bk.id = $id; $script:bk.uid = $uid; $script:bk.rt = $rt; $script:bk.tok = $null
        $acct = BankGet "accounts/$id"
        if (-not $acct) { throw 'You have no bank account yet. Open one on the website first.' }
        if ([string]$acct.owner -ne $uid) { throw 'This bank account is linked to a different browser. Use the browser you opened it with.' }
        [IO.File]::WriteAllLines($bankPath, [string[]]@("id=$id", "uid=$uid", "rt=$($script:bk.rt)"))
        $script:bk.acct = 'me'; $script:bk.mode = 'idle'; $script:bk.balAt = [datetime]::MinValue; $script:bk.chgAt = [datetime]::MinValue
        $script:bk.gamerAt = [datetime]::MinValue
        $script:bk.msg = 'Bank linked.'
        $script:bankJustLinked = $true
        Log "bank linked to account $id"
        Reply $ctx 'Brick Rigs is linked to your bank. You can close this tab and go back to the game.'
    } catch {
        $script:bk = $old
        $why = $_.Exception.Message
        if ($why -notmatch '^(You have|This bank)') { $why = 'Linking failed: ' + (Cut $why 80) }
        Log "bank link failed: $($_.Exception.Message)"
        Reply $ctx $why
    }
}
BankLoad

# ===== Mod pack updates =========================================================================
# The website keeps a small version file next to the pack. When it is newer than this install, the
# game shows an "Update mods" button. The update is downloaded straight away and installed the
# moment Brick Rigs closes, because the game keeps its mod files open while it runs.
$ProgressPreference = 'SilentlyContinue'     # a progress bar makes downloads in Windows PowerShell very slow
$packVersionPath = Join-Path $Dir 'pack_version.txt'
$UPDATE_ZIP_URL  = "$SITE/downloads/StiltonModPack.zip"
$UPDATE_VER_URL  = "$SITE/downloads/StiltonModPack.version.txt"
$stageRoot       = Join-Path $Dir 'update_staged'
$script:up = @{ state = ''; remote = ''; msg = ''; checkAt = (Get-Date).AddSeconds(20) }
if (Test-Path (Join-Path $stageRoot 'StiltonModPack')) { $script:up.state = 'ready' }

function PackVersion { return (ReadText $packVersionPath).Trim() }
function VersionNewer($a, $b) {
    if (-not $b) { return $true }
    try { return ([version]$a) -gt ([version]$b) } catch { return $false }
}

function UpdateCheck {
    if ((Get-Date) -lt $script:up.checkAt) { return }
    $script:up.checkAt = (Get-Date).AddMinutes(30)
    if ($script:up.state -eq 'downloading' -or $script:up.state -eq 'ready') { return }
    try {
        $r = (Invoke-WebRequest -Uri ($UPDATE_VER_URL + '?t=' + (NowMs)) -UseBasicParsing -TimeoutSec 15).Content
        if ($r -is [byte[]]) { $r = [Text.Encoding]::UTF8.GetString($r) }
        $remote = ([string]$r).Trim()
        if ($remote -match '^\d{4}\.\d{1,2}\.\d{1,2}\.\d+$' -and (VersionNewer $remote (PackVersion))) {
            if ($script:up.state -ne 'available') { Log "update available: $remote (installed: $(PackVersion))" }
            $script:up.state = 'available'; $script:up.remote = $remote
        } elseif ($script:up.state -eq 'available') { $script:up.state = '' }
    } catch {
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 404) { return }   # the site has no version file yet
        Log "update check failed: $($_.Exception.Message)"
    }
}

function UpdateDownload {
    if ($script:up.state -eq 'ready') { $script:up.msg = ''; return }
    $script:up.state = 'downloading'
    try { Redraw } catch {}
    $tmp = Join-Path $env:TEMP "StiltonModPack-update-$PID.zip"
    try {
        Invoke-WebRequest -Uri ($UPDATE_ZIP_URL + '?t=' + (NowMs)) -OutFile $tmp -UseBasicParsing -TimeoutSec 300
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        if (Test-Path $stageRoot) { Remove-Item $stageRoot -Recurse -Force }
        [IO.Compression.ZipFile]::ExtractToDirectory($tmp, $stageRoot)
        $pack = Join-Path $stageRoot 'StiltonModPack'
        if (-not (Test-Path (Join-Path $pack 'ue4ss\Mods\StiltonCAD\bridge.ps1'))) {
            Remove-Item $stageRoot -Recurse -Force -ErrorAction SilentlyContinue
            throw 'the download is not a Stilton Mod Pack'
        }
        $script:up.remote = (ReadText (Join-Path $pack 'ue4ss\Mods\StiltonCAD\pack_version.txt')).Trim()
        $script:up.state = 'ready'
        Log "update $($script:up.remote) downloaded; it installs when Brick Rigs closes"
    } catch {
        $script:up.state = 'error'
        $script:up.msg = Cut $_.Exception.Message 60
        Log "update download failed: $($_.Exception.Message)"
    } finally {
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    }
}

# Runs after the game has closed: copy the downloaded pack over this install.
# Only files that come with the pack are replaced; logins, bank links and logs are left alone.
function UpdateApply {
    $pack = Join-Path $stageRoot 'StiltonModPack'
    if (-not (Test-Path $pack)) { return }
    if (Get-Process -Name 'BrickRigs*-Win64-Shipping' -ErrorAction SilentlyContinue) { return }
    Start-Sleep -Seconds 3           # let Windows release the game's files
    try {
        $win64 = (Resolve-Path (Join-Path $Dir '..\..\..')).Path
        if (-not (Get-ChildItem -LiteralPath $win64 -Filter 'BrickRigs*-Win64-Shipping.exe' -File -ErrorAction SilentlyContinue)) { throw "game folder not found at $win64" }
        $src = Join-Path $pack 'ue4ss'
        $dstRoot = Join-Path $win64 'ue4ss'
        $failed = 0
        foreach ($f in (Get-ChildItem -LiteralPath $src -Recurse -File)) {
            $rel = $f.FullName.Substring($src.Length + 1)
            if ($rel -eq 'Mods\mods.txt' -or $rel -eq 'Mods\mods.json') { continue }      # keep the player's own on/off choices
            $dst = Join-Path $dstRoot $rel
            try {
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
                Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
            } catch { $failed++; Log "update: could not replace $rel : $($_.Exception.Message)" }
        }
        try { Copy-Item -LiteralPath (Join-Path $pack 'dwmapi.dll') -Destination $win64 -Force } catch { Log "update: dwmapi.dll not replaced: $($_.Exception.Message)" }
        # any mod that is new in this version gets switched on
        $txt = Join-Path $dstRoot 'Mods\mods.txt'
        $json = Join-Path $dstRoot 'Mods\mods.json'
        foreach ($d in (Get-ChildItem -LiteralPath (Join-Path $src 'Mods') -Directory)) {
            $mod = $d.Name
            if ($mod -eq 'shared' -or $mod -eq 'Keybinds') { continue }
            if ((Test-Path $txt) -and ((Get-Content $txt -Raw) -notmatch "(?m)^\s*$([regex]::Escape($mod))\s*:")) {
                [IO.File]::WriteAllText($txt, "$mod : 1`r`n" + (Get-Content $txt -Raw))
            }
            if (Test-Path $json) {
                $list = @(Get-Content $json -Raw | ConvertFrom-Json)
                if (-not ($list | Where-Object { $_.mod_name -eq $mod })) {
                    $list = @([pscustomobject]@{ mod_name = $mod; mod_enabled = $true }) + $list
                    [IO.File]::WriteAllText($json, (ConvertTo-Json -InputObject $list -Depth 4))
                }
            }
        }
        if ($failed -eq 0) {
            Remove-Item $stageRoot -Recurse -Force -ErrorAction SilentlyContinue
            Log "update installed: $(PackVersion)"
        } else { Log "update partly installed ($failed files failed); it will be tried again next time the game closes" }
    } catch { Log "update install failed: $($_.Exception.Message)" }
}

# Panel line for the game: U|state|version|message
function UpdateLines {
    if (-not $script:up.state) { return @() }
    return @("U|$($script:up.state)|$($script:up.remote)|$($script:up.msg)")
}

# The website's "Update my mods" button opens http://localhost:47822/update while the game runs.
function WebUpdate {
    if ($script:up.state -eq 'ready') { return "Update $($script:up.remote) is already downloaded. Close Brick Rigs to install it; it is ready the next time you start the game." }
    $script:up.checkAt = [datetime]::MinValue
    UpdateCheck
    if ($script:up.state -eq 'available' -or $script:up.state -eq 'error') {
        UpdateDownload
        if ($script:up.state -eq 'ready') { return "Update $($script:up.remote) downloaded. Close Brick Rigs to install it; it is ready the next time you start the game." }
        return "The update could not be downloaded ($($script:up.msg)). Try again in a minute."
    }
    return "Your mods are up to date (version $(PackVersion))."
}
function UpdatePage($msg) {
    $m = [System.Net.WebUtility]::HtmlEncode($msg)
    return '<!doctype html><html><head><meta charset="utf-8"><title>Stilton Mod Pack</title></head><body style="font-family:sans-serif;background:#081326;color:#eef3fb;text-align:center;padding-top:15vh"><h2>Stilton Mod Pack</h2><p>' + $m + '</p><p style="color:#9db0d0">You can close this tab.</p></body></html>'
}

# ===== 911, panic button and automatic fire calls ============================================
# In-game positions are written into the call's location text ("In game X 123 Y -45 Z 6", metres),
# because the calls and panics on the website have no other place for them. The CAD reads them
# back from there to show a waypoint.
$firePath = Join-Path $Dir 'fire_reports.txt'     # written by the Realistic Fire mod on the host's PC
$script:last911 = [datetime]::MinValue
$script:fireCalled = @{}
$script:emsg = ''; $script:emsgAt = [datetime]::MinValue

function EMsg($m) { $script:emsg = $m; $script:emsgAt = Get-Date }
function PosText($x, $y, $z) { return ('In game X {0:0} Y {1:0} Z {2:0}' -f ([double]$x / 100), ([double]$y / 100), ([double]$z / 100)) }
function ParsePos($s) {
    $m = [regex]::Match([string]$s, 'X (-?\d+) Y (-?\d+) Z (-?\d+)')
    if (-not $m.Success) { return $null }
    return @{ x = [double]$m.Groups[1].Value * 100; y = [double]$m.Groups[2].Value * 100; z = [double]$m.Groups[3].Value * 100 }
}
function ParseXYZ($s) {
    $p = ([string]$s).Split(',')
    if ($p.Count -ne 3) { return $null }
    try { return @{ x = [double]::Parse($p[0], [Globalization.CultureInfo]::InvariantCulture); y = [double]::Parse($p[1], [Globalization.CultureInfo]::InvariantCulture); z = [double]::Parse($p[2], [Globalization.CultureInfo]::InvariantCulture) } } catch { return $null }
}
# Create a new document with exactly these fields, the way the website's .set() does.
function CreateDoc($path, $fields) {
    $f = @{}
    foreach ($k in $fields.Keys) {
        $v = $fields[$k]
        if ($v -is [string]) { $f[$k] = @{ stringValue = $v } } else { $f[$k] = @{ integerValue = "$([int64]$v)" } }
    }
    $body = @{ fields = $f } | ConvertTo-Json -Depth 10
    Invoke-RestMethod -Method Patch -Uri ((Base) + "/$path" + '?currentDocument.exists=false') -Headers (Headers) -ContentType 'application/json' -Body $body | Out-Null
}
function WriteError($e) {
    $code = 0
    try { $code = [int]$e.Exception.Response.StatusCode } catch {}
    if ($code -eq 403) { return 'The database refused it (the website rules may need updating).' }
    return "Could not reach the CAD ($(Cut $e.Exception.Message 40))."
}

# 911 from the game, for every player: call911|Police|x,y,z
function Call911($cmd) {
    $parts = $cmd.Split('|')
    $dept = $parts[1]
    if (@('Police', 'EMS', 'Fire') -notcontains $dept) { return }
    $cfg = ReadConfig
    if (-not $cfg.discord_id) { EMsg 'Click Log in once so 911 knows who is calling.'; return }
    if (((Get-Date) - $script:last911).TotalSeconds -lt 60) { EMsg 'Please wait a minute before calling 911 again.'; return }
    $pos = ParseXYZ $parts[2]
    if (-not $pos) { EMsg 'Could not find your position in the game.'; return }
    $me = (SessionPlayers).me
    $who = $(if ($cfg.name) { $cfg.name } else { 'Unknown' })
    try {
        if (-not $script:apiKey) { LoadSite }
        CreateDoc "calls/$(NewId)" @{
            dept = $dept; location = (PosText $pos.x $pos.y $pos.z)
            details = (Cut "911 call from Brick Rigs$(if ($me) { " by $me" }). $dept needed at the caller's position." 400)
            by_id = [string]$cfg.discord_id; by_name = (Cut $who 80); status = 'open'; created = (NowMs) }
        $script:last911 = Get-Date
        EMsg "911 called: $dept is on the way. Stay where you are."
        Log "911 call ($dept) sent"
    } catch { EMsg (WriteError $_); Log "911 failed: $($_.Exception.Message)" }
}

# Panic from the game, for SCPD/SCFD on duty: panic|x,y,z  (checked for duty before this is called)
function SendPanic($cmd, $cfg) {
    $pos = ParseXYZ ($cmd.Split('|')[1])
    if (-not $pos) { $script:lastMsg = 'Could not find your position in the game.'; return }
    $who = $(if ($cfg.name) { $cfg.name } else { $cfg.callsign })
    CreateDoc "panics/$(NewId)" @{
        by_id = [string]$cfg.discord_id; by_name = (Cut $who 80); callsign = (Cut $cfg.callsign 12)
        dept = (Cut $(if ($cfg.dept) { $cfg.dept } else { 'Police' }) 20)
        location = (PosText $pos.x $pos.y $pos.z); note = 'Panic button pressed in Brick Rigs'
        status = 'active'; created = (NowMs) }
    $script:lastMsg = 'PANIC SENT. All units have been alerted.'
    $script:hotUntil = (Get-Date).AddSeconds(60)
}

# Big fires reported by the Realistic Fire mod (host only) become one SCFD call each.
function FireCalls($calls) {
    if (-not (Test-Path $firePath)) { return }
    $lines = @((ReadText $firePath) -split "`r?`n" | Where-Object { $_.Trim() })
    Remove-Item $firePath -Force -ErrorAction SilentlyContinue
    $cfg = ReadConfig
    $by = $(if ($cfg.discord_id) { [string]$cfg.discord_id } elseif ($script:bk.id) { [string]$script:bk.id } else { '' })
    foreach ($line in $lines) {
        $p = $line.Split('|')
        if ($p[0] -ne 'fire' -or $p.Count -lt 6) { continue }
        $pos = ParseXYZ "$($p[1]),$($p[2]),$($p[3])"
        if (-not $pos) { continue }
        $cell = '{0}:{1}' -f [math]::Floor($pos.x / 30000), [math]::Floor($pos.y / 30000)
        if ($script:fireCalled[$cell] -and ((Get-Date) - $script:fireCalled[$cell]).TotalMinutes -lt 15) { continue }
        # an open fire call close to it already? then leave it
        $near = $false
        foreach ($c in @($calls)) {
            $cp = ParsePos $c.location
            if ($c.dept -eq 'Fire' -and $cp -and [math]::Sqrt([math]::Pow($cp.x - $pos.x, 2) + [math]::Pow($cp.y - $pos.y, 2)) -lt 15000) { $near = $true }
        }
        if ($near) { $script:fireCalled[$cell] = Get-Date; continue }
        if (-not $by) { Log 'fire call skipped: log in (or link the bank) on the host PC so calls have a sender'; continue }
        try {
            if (-not $script:apiKey) { LoadSite }
            CreateDoc "calls/$(NewId)" @{
                dept = 'Fire'; location = (PosText $pos.x $pos.y $pos.z)
                details = (Cut "Automatic fire alarm: about $($p[4]) burning bricks$(if ($p[5]) { " ($($p[5]))" }). Fire is spreading." 400)
                by_id = $by; by_name = 'Automatic fire alarm'; status = 'open'; created = (NowMs) }
            $script:fireCalled[$cell] = Get-Date
            Log "automatic fire call sent ($($p[4]) bricks burning)"
        } catch { Log "automatic fire call failed: $($_.Exception.Message)" }
    }
}

# Where the waypoint should point: the call or panic you are on, else the highlighted one.
function WaypointLine($cfg, $calls, $panics) {
    $t = $null
    if ($cfg.callsign) {
        $t = @(Targets $calls $panics) | Where-Object { ($_.kind -eq 'call' -and (($_.doc.unit -eq $cfg.callsign) -or ($_.doc.units -and (@($_.doc.units) -contains $cfg.callsign)))) -or ($_.kind -eq 'panic' -and $_.doc.units -and (@($_.doc.units) -contains $cfg.callsign)) } | Select-Object -First 1
    }
    if (-not $t) { $t = Selected $calls $panics }
    if (-not $t) { return $null }
    $pos = ParsePos $t.doc.location
    if (-not $pos) { return $null }
    $label = $(if ($t.kind -eq 'panic') { "PANIC $(Cut $t.doc.callsign 10)" } else { "$((Cut $t.doc.dept 6).ToUpper()) CALL" })
    return "W|$($pos.x)|$($pos.y)|$($pos.z)|$label"
}

# Emergency messages for every player (911 feedback); they fade after a while.
function EmergencyLines {
    if ($script:emsg -and ((Get-Date) - $script:emsgAt).TotalSeconds -gt 30) { $script:emsg = '' }
    if ($script:emsg) { return @("E|$($script:emsg)") }
    return @()
}

# Commands from the game that are not CAD commands (bank buttons, the update button, 911).
function ExtraCommand($cmd) {
    if ($cmd.Trim() -eq 'update_now') { UpdateDownload; return $true }
    if ($cmd.Trim() -like 'call911|*') { Call911 $cmd.Trim(); return $true }
    return (BankCommand $cmd)
}


BankListen

$script:selected = ''      # id of the highlighted panic/call ("p:<id>" or "c:<id>")

# Everything a unit can respond to, panics first, in the order the panel lists them.
function Targets($calls, $panics) {
    $t = @()
    foreach ($p in $panics) { $t += , @{ key = "p:$($p.id)"; kind = 'panic'; doc = $p } }
    $n = 0
    foreach ($c in $calls) { $n++; if ($n -gt 5) { break }; $t += , @{ key = "c:$($c.id)"; kind = 'call'; doc = $c } }
    return $t
}
function Selected($calls, $panics) {
    $t = @(Targets $calls $panics)
    if ($t.Count -eq 0) { $script:selected = ''; return $null }
    $cur = $t | Where-Object { $_.key -eq $script:selected } | Select-Object -First 1
    if (-not $cur) {
        # default: the first one nobody is handling yet, else the first
        $cur = $t | Where-Object { ($_.kind -eq 'panic' -and $_.doc.status -eq 'active') -or ($_.kind -eq 'call' -and $_.doc.status -eq 'open') } | Select-Object -First 1
        if (-not $cur) { $cur = $t[0] }
        $script:selected = $cur.key
    }
    return $cur
}

# Redraw the panel from the data we already hold (used to show a change before the network confirms it).
$script:cur = $null
function Redraw { if ($script:cur) { try { BuildPanel $script:cur.cfg $script:cur.calls $script:cur.units $script:cur.panics $script:cur.me } catch {} } }

function DoCommands($cfg, $calls, $panics, $me) {
    if (-not (Test-Path $cmdPath)) { return }
    $lines = @((ReadText $cmdPath) -split "`r?`n" | Where-Object { $_.Trim() })
    Remove-Item $cmdPath -Force -ErrorAction SilentlyContinue
    foreach ($cmd in $lines) {
        if (ExtraCommand $cmd) { continue }
        $script:hotUntil = (Get-Date).AddSeconds(30)
        try {
            if ($cmd.Trim() -eq 'login') {
                if ($cfg.discord_id) { $script:lastMsg = "Already logged in as $($cfg.name)" } else { DoLogin }
                continue
            }
            if (-not $cfg.discord_id) { $script:lastMsg = 'Click Log in first'; continue }
            if ($cmd.Trim() -eq 'panic_clear') {
                $mine = @($panics | Where-Object { [string]$_.by_id -eq [string]$cfg.discord_id -and $_.status -ne 'cleared' })
                foreach ($p in $mine) { Patch "panics/$($p.id)" @{ status = 'cleared'; cleared_by = (Cut $(if ($cfg.callsign) { $cfg.callsign } else { 'caller' }) 12); updated = (NowMs) } }
                $script:lastMsg = $(if ($mine.Count) { 'Panic cancelled. Units have been told you are OK.' } else { 'You have no open panic.' })
                Log "panic cancelled from the game ($($mine.Count))"
                continue
            }
            if ($cmd.Trim() -like 'panic|*' -and -not $cfg.callsign) { $script:lastMsg = 'Go on duty on the website first, then the panic button works.'; continue }
            if ($cmd.Trim() -eq 'select_next') {
                $t = @(Targets $calls $panics)
                if ($t.Count -eq 0) { $script:lastMsg = 'Nothing to select'; continue }
                $cur = Selected $calls $panics
                $i = 0; for ($k = 0; $k -lt $t.Count; $k++) { if ($t[$k].key -eq $cur.key) { $i = $k } }
                $script:selected = $t[($i + 1) % $t.Count].key
                $script:lastMsg = ''
                Redraw
                continue
            }
            if ($cfg.allow_actions -ne 'true') { $script:lastMsg = 'Actions are off. Set allow_actions=true in cad_config.txt'; continue }
            if (-not $cfg.callsign) { $script:lastMsg = 'Go on duty on the website first so the CAD knows your callsign'; continue }
            if ((EffStatus $me) -eq 'Off duty') { $script:lastMsg = 'You are off duty. Go on duty on the website first.'; continue }
            if ($cmd.Trim() -like 'panic|*') { SendPanic $cmd.Trim() $cfg; Log "panic sent from the game"; continue }
            switch ($cmd.Trim()) {
                'status_next' {
                    $i = [array]::IndexOf($STATUSES, [string]$me.status)
                    $next = $STATUSES[($i + 1) % $STATUSES.Count]
                    $now = NowMs
                    $before = $me.status
                    # show it first, then send it; put it back if the CAD refuses
                    $me.status = $next; $me.updated = $now; $me.seen = $now
                    $script:lastMsg = "Status set to $next"
                    Redraw
                    try { Patch "units/$($cfg.discord_id)" @{ status = $next; updated = $now; seen = $now } }
                    catch { $me.status = $before; throw }
                }
                'respond_top' {
                    $sel = Selected $calls $panics
                    if (-not $sel) { $script:lastMsg = 'There is nothing to respond to'; break }
                    $who = if ($cfg.name) { $cfg.name } else { $cfg.callsign }
                    $now = NowMs
                    if ($sel.kind -eq 'panic') {
                        $p = $sel.doc
                        $unitsNow = @(); if ($p.units) { $unitsNow = @($p.units) }
                        $list = @(@($unitsNow + $cfg.callsign) | Select-Object -Unique | Select-Object -First 8)
                        Patch "panics/$($p.id)" @{ units = $list; status = 'acknowledged'; cleared_by = $cfg.callsign; updated = $now }
                        $p.units = $list; $p.status = 'acknowledged'
                        $script:lastMsg = "Responding to PANIC: $(Cut $p.callsign 12)"
                    } else {
                        $c = $sel.doc
                        Patch "calls/$($c.id)" @{ status = 'responding'; unit = $cfg.callsign; unit_name = (Cut $who 80); updated = $now }
                        $c.status = 'responding'; $c.unit = $cfg.callsign
                        $script:lastMsg = "Responding to: $(Cut $c.location 40)"
                    }
                    # show the unit as on the way
                    if ($me.status -ne 'En route') {
                        try { Patch "units/$($cfg.discord_id)" @{ status = 'En route'; updated = $now; seen = $now }; $me.status = 'En route'; $me.updated = $now; $me.seen = $now } catch { Log "could not set En route: $($_.Exception.Message)" }
                    }
                }
                'break_away' {
                    # leave whatever you are attached to: the highlighted one if it is yours, otherwise any that is
                    $mine = { param($t) ($t.kind -eq 'call' -and (($t.doc.unit -eq $cfg.callsign) -or ($t.doc.units -and (@($t.doc.units) -contains $cfg.callsign)))) -or ($t.kind -eq 'panic' -and $t.doc.units -and (@($t.doc.units) -contains $cfg.callsign)) }
                    $all = @(Targets $calls $panics)
                    $sel = Selected $calls $panics
                    $target = $null
                    if ($sel -and (& $mine $sel)) { $target = $sel } else { $target = $all | Where-Object { & $mine $_ } | Select-Object -First 1 }
                    if (-not $target) { $script:lastMsg = 'You are not attached to a call'; break }
                    $now = NowMs
                    $d = $target.doc
                    $left = @(); if ($d.units) { $left = @(@($d.units) | Where-Object { $_ -ne $cfg.callsign }) }
                    if ($target.kind -eq 'panic') {
                        $st = if ($left.Count -gt 0) { 'acknowledged' } else { 'active' }
                        Patch "panics/$($d.id)" @{ units = $left; status = $st; updated = $now }
                        $d.units = $left; $d.status = $st
                        $script:lastMsg = "You left the panic: $(Cut $d.callsign 12)"
                    } else {
                        $fields = @{ updated = $now }
                        if ($d.units) { $fields.units = $left; $d.units = $left }
                        if ($d.unit -eq $cfg.callsign) {
                            # hand it to another attached unit if there is one, otherwise it goes back to waiting
                            if ($left.Count -gt 0) { $fields.unit = [string]$left[0]; $fields.unit_name = ''; $d.unit = $left[0] }
                            else { $fields.unit = ''; $fields.unit_name = ''; $fields.status = 'open'; $d.unit = ''; $d.status = 'open' }
                        }
                        Patch "calls/$($d.id)" $fields
                        $script:lastMsg = "You left the call: $(Cut $d.location 36)"
                    }
                    if ($me.status -ne 'Available') {
                        try { Patch "units/$($cfg.discord_id)" @{ status = 'Available'; updated = $now; seen = $now }; $me.status = 'Available'; $me.updated = $now; $me.seen = $now } catch { Log "could not set Available: $($_.Exception.Message)" }
                    }
                }
                default { $script:lastMsg = "Unknown command: $cmd" }
            }
            Log "action '$cmd': $($script:lastMsg)"
        } catch {
            $script:lastMsg = "Action failed: $(Cut $_.Exception.Message 70)"
            Log "action '$cmd' failed: $($_.Exception.Message)"
        }
    }
}

function BuildPanel($cfg, $calls, $units, $panics, $me) {
    # Each line starts with a tag the mod uses for styling: T title, M me, A alert, H heading, B body, F footer.
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add('V|yes')
    foreach ($b in (BankLines)) { $L.Add($b) }
    foreach ($u in (UpdateLines)) { $L.Add($u) }
    foreach ($e in (EmergencyLines)) { $L.Add($e) }
    $w = WaypointLine $cfg $calls $panics
    if ($w) { $L.Add($w) }
    if ($cfg.discord_id -and @($panics | Where-Object { [string]$_.by_id -eq [string]$cfg.discord_id -and $_.status -ne 'cleared' }).Count -gt 0) { $L.Add('P|mine') }
    $L.Add("T|STILTON COUNTY CAD     $(Get-Date -Format 'HH:mm')")
    if (-not $cfg.discord_id) {
        $L.Add('M|Not logged in  -  click Log in')
    } elseif ($cfg.callsign) {
        $L.Add("M|$(Cut $cfg.name 22)  |  $($cfg.callsign)  |  $(EffStatus $me)")
    } else {
        $L.Add("M|$(Cut $cfg.name 22)  |  off duty (go on duty on the website)")
    }
    $sel = Selected $calls $panics
    $selKey = if ($sel) { $sel.key } else { '' }
    foreach ($p in $panics) {
        $mark = if ($selKey -eq "p:$($p.id)") { '>> ' } else { '   ' }
        $who = if ($p.units -and @($p.units).Count -gt 0) { "  responding: $(Cut (@($p.units) -join ', ') 30)" } else { '  NO ONE RESPONDING' }
        $L.Add("A|$($mark)PANIC  $(Cut $p.callsign 12) ($(Cut $p.dept 8))  $(Age $p.created)")
        $L.Add("A|      $(Cut $p.location 40)$who")
    }
    $L.Add("H|CALLS  ($($calls.Count))")
    if ($calls.Count -eq 0) { $L.Add('B|No active calls') }
    $n = 0
    foreach ($c in $calls) {
        $n++; if ($n -gt 5) { $L.Add("B|+ $($calls.Count - 5) more"); break }
        $st = if ($c.status -eq 'responding') { "$(Cut $c.unit 12) responding" } else { 'WAITING' }
        $mark = if ($selKey -eq "c:$($c.id)") { '>>' } else { '  ' }
        $L.Add("B|$mark $n  $((Cut $c.dept 7).ToUpper())  $(Cut $c.location 30)")
        $L.Add("B|       $(Cut $c.details 46)")
        $L.Add("B|       $st  -  $(Age $c.created)")
    }
    $L.Add("H|UNITS ON DUTY  ($($units.Count))")
    if ($units.Count -eq 0) { $L.Add('B|No units on duty') }
    $n = 0
    foreach ($u in $units) {
        $n++; if ($n -gt 8) { $L.Add("B|+ $($units.Count - 8) more"); break }
        $L.Add(("B|{0,-9}{1,-9}{2}" -f (Cut $u.callsign 8), (Cut $u.dept 8), (EffStatus $u)))
    }
    if ($script:lastMsg) { $L.Add("F|$($script:lastMsg)") }
    if ((Slowdown) -gt 1) { $L.Add('F|CAD refresh slowed to stay inside the free database allowance') }
    $L.Add('F|Press F4 for the mouse, then click a button')
    WritePanelLines $L
}

$failures = 0
$script:haveData = $false
$script:unitsAt = $null; $script:allUnits = @(); $script:lastReadsLog = Get-Date
while ($true) {
    try {
        if (-not (Get-Process -Name 'BrickRigs*-Win64-Shipping' -ErrorAction SilentlyContinue)) { Log 'Brick Rigs closed, bridge exiting'; break }
        if ((ReadText $verPath) -ne $startVersion) { Log 'new version, bridge exiting so the mod restarts it'; break }
        if (-not $script:apiKey) { LoadSite }
        $cfg = ReadConfig
        $access = Access $cfg
        BankTick
        UpdateCheck
        if ($access -ne 'yes') {
            try { FireCalls @() } catch { Log "fire calls: $($_.Exception.Message)" }
            # No CAD for this player: read nothing from the database, only wait for a login.
            switch ($access) {
                'login'   { $msg = 'Log in with Discord to use the CAD (SCPD and SCFD only).' }
                'relogin' { $msg = 'Click Log in once more so the CAD can check your department role.' }
                default   { $msg = 'The CAD is for SCPD and SCFD members only.' }
            }
            $lines = @("V|$access", 'T|STILTON COUNTY CAD', "B|$msg")
            if ($script:lastMsg) { $lines += "F|$($script:lastMsg)" }
            $lines += @(BankLines)
            $lines += @(UpdateLines)
            $lines += @(EmergencyLines)
            WritePanelLines $lines
            # wait for buttons; come round sooner while the bank is in use
            $bankBusy = ((Get-Date) -lt $script:bk.hotUntil) -or ($script:bk.sent.Count -gt 0) -or [bool]$script:emsg
            $until = (Get-Date).AddSeconds($(if ($bankBusy) { 3 } else { 10 }))
            while ((Get-Date) -lt $until -and -not (Test-Path $cmdPath)) {
                BankPollLink
                if ($script:bankJustLinked) { $script:bankJustLinked = $false; break }
                Start-Sleep -Milliseconds 150
            }
            if (Test-Path $cmdPath) {
                $cmds = @((ReadText $cmdPath) -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                Remove-Item $cmdPath -Force -ErrorAction SilentlyContinue
                foreach ($c in $cmds) {
                    if ($c -eq 'login') { DoLogin } else { [void](ExtraCommand $c) }
                }
            }
            $script:haveData = $false
            continue
        }
        $now = NowMs
        # calls and panics that are still open (closed ones are never read)
        $calls = @((QueryIn 'calls' 'status' @('open', 'responding') 30) | Where-Object { $_ -and (($now - (Num $_.created)) -lt 43200000) } |
            Sort-Object @{ Expression = { if ($null -eq $_.priority) { 2 } else { [double]$_.priority } }; Descending = $true }, @{ Expression = { Num $_.created }; Descending = $false })
        $panics = @()
        try { $panics = @((QueryIn 'panics' 'status' @('active', 'acknowledged') 10) | Where-Object { $_ -and (($now - (Num $_.created)) -lt 900000) } | Sort-Object { Num $_.created } -Descending) } catch {}
        CountReads ([math]::Max(1, $calls.Count) + [math]::Max(1, $panics.Count))
        # units on duty change less urgently, so they are refreshed less often
        if (-not $script:unitsAt -or (((Get-Date) - $script:unitsAt).TotalMilliseconds -ge ($UNITS_MS * (Slowdown)))) {
            $script:allUnits = @(Query 'units' 'seen' ($now - $GRACE_MS) 60)
            $script:unitsAt = Get-Date
            CountReads ([math]::Max(1, $script:allUnits.Count))
        }
        $allUnits = $script:allUnits
        $units = @($allUnits | Where-Object { $_ -and (EffStatus $_) -ne 'Off duty' } | Sort-Object { [string]$_.callsign })
        $me = $null
        if ($cfg.discord_id) { $me = $allUnits | Where-Object { $_ -and $_.id -eq $cfg.discord_id } | Select-Object -First 1 }
        if ($me) {
            if (-not $cfg.callsign -and $me.callsign) { $cfg.callsign = [string]$me.callsign }
            if ($me.dept) { $cfg.dept = [string]$me.dept }
        }
        $script:cur = @{ cfg = $cfg; calls = $calls; units = $units; panics = $panics; me = $me }
        DoCommands $cfg $calls $panics $me
        try { FireCalls $calls } catch { Log "fire calls: $($_.Exception.Message)" }
        # keep the duty heartbeat going while the game is open, like the website does while its tab is open
        if ($cfg.allow_actions -eq 'true' -and $me -and ((EffStatus $me) -ne 'Off duty') -and (((Get-Date) - $script:lastBeat).TotalSeconds -ge 45)) {
            try { Patch "units/$($cfg.discord_id)" @{ seen = (NowMs) }; $script:lastBeat = Get-Date } catch { Log "heartbeat failed: $($_.Exception.Message)" }
        }
        BuildPanel $cfg $calls $units $panics $me
        PanicAlarm $panics
        $script:haveData = $true
        if ($failures -gt 0) { Log 'recovered' }
        $failures = 0
    } catch {
        $failures++
        if ($failures -le 3 -or ($failures % 20) -eq 0) { Log "error ($failures): $($_.Exception.Message) [line $($_.InvocationInfo.ScriptLineNumber)]" }
        try {
            WritePanelLines @('T|STILTON COUNTY CAD', "B|Cannot reach the CAD: $(Cut $_.Exception.Message 60)", 'F|Retrying...')
        } catch {}
    }
    # Between polls, watch for key presses from the game so actions happen right away.
    # Refresh quickly while something just happened (you pressed a CAD key, or a call/panic is new or
    # was just updated) and more slowly when the CAD is quiet; slower still as the daily share runs out.
    $fresh = $false
    if ($script:haveData) {
        foreach ($d in @($calls) + @($panics)) { if ($d -and (((NowMs) - [math]::Max((Num $d.created), (Num $d.updated))) -lt 120000)) { $fresh = $true } }
    }
    $hot = $fresh -or ((Get-Date) -lt $script:hotUntil)
    $waitMs = $(if ($hot) { $ALERTS_HOT_MS } else { $ALERTS_MS }) * (Slowdown)
    if (((Get-Date) - $script:lastReadsLog).TotalMinutes -ge 10) {
        Log ("document reads today: {0} of this PC's {1} share (slowdown x{2})" -f $script:readsToday, $DAILY_READS, (Slowdown))
        $script:lastReadsLog = Get-Date
    }
    $until = (Get-Date).AddMilliseconds($waitMs)
    $nextBank = (Get-Date).AddSeconds(3)
    while ((Get-Date) -lt $until) {
        BankPollLink
        if ((Get-Date) -ge $nextBank) {
            $nextBank = (Get-Date).AddSeconds(3)
            $before = ($script:bk.bal, $script:bk.incoming.Count, $script:bk.msg) -join '|'
            BankTick
            if ((($script:bk.bal, $script:bk.incoming.Count, $script:bk.msg) -join '|') -ne $before) { Redraw }
        }
        if ($script:haveData -and (Test-Path $cmdPath)) {
            try {
                $cfg = ReadConfig
                if ($me -and -not $cfg.callsign -and $me.callsign) { $cfg.callsign = [string]$me.callsign }
                $script:cur = @{ cfg = $cfg; calls = $calls; units = $units; panics = $panics; me = $me }
                DoCommands $cfg $calls $panics $me
                BuildPanel $cfg $calls $units $panics $me
            } catch { Log "command handling failed: $($_.Exception.Message)" }
        }
        Start-Sleep -Milliseconds 80
    }
}

# The game has closed (or this helper is being replaced): install a downloaded update now.
UpdateApply
