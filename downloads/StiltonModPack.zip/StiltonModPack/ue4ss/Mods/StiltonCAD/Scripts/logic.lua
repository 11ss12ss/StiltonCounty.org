-- StiltonCAD logic (re-read by main.lua whenever version.txt changes)
local ROOT = CAD.root
local PANEL = ROOT .. "\\cad_panel.txt"
local CMD   = ROOT .. "\\cad_cmd.txt"
local LOG   = ROOT .. "\\mod_log.txt"
-- The other mods run separately, so their on/off switches go through small files in their folders.
local MODS_DIR = ROOT .. "\\.."
local FIRE_STATE, FIRE_CMD     = MODS_DIR .. "\\RealisticFire\\state.txt", MODS_DIR .. "\\RealisticFire\\command.txt"
local DEBRIS_STATE, DEBRIS_CMD = MODS_DIR .. "\\SolidDebris\\state.txt", MODS_DIR .. "\\SolidDebris\\command.txt"

-- Panel sections, top to bottom. style = the game's text style, color = the game's colour style.
--   text styles: 0 default, 1 bold, 3 small, 4 small italic, 5 large    colours: 0 default, 3 secondary, 4 highlight, 6 negative
local SECTIONS = {
    { tag = "E", style = 1, color = 6 },   -- 911 messages (for everyone)
    { tag = "U", style = 1, color = 4 },   -- mod pack update (for everyone)
    { tag = "K", style = 1, color = 3 },   -- bank (for everyone)
    { tag = "T", style = 5, color = 4 },   -- title
    { tag = "M", style = 0, color = 3 },   -- who you are
    { tag = "A", style = 5, color = 6 },   -- panic alerts (bold, warning colour)
    { tag = "B", style = 0, color = 3 },   -- calls and units (headings are folded in here)
    { tag = "F", style = 3, color = 3 },   -- last action + key help
}
local MARGIN_TOP  = 96.0                   -- distance from the top of the screen (clears the Input help button)
local BTN_W, BTN_H, BTN_GAP, BTN_PER_ROW = 140.0, 30.0, 5.0, 3   -- button size and spacing
local UI_SCALE    = 1.0                    -- overall size of the panel and its buttons (1.0 = the game's own text size)
local MARGIN_SIDE = 10.0                   -- distance from the screen edge

-- Buttons in the top-right corner. Press F4 to get the mouse cursor, then click them.
-- Mod switches, for everyone (the label shows the current state):
local MOD_BUTTONS = {
    { id = "fire",   mod = true },
    { id = "hose",   mod = true },
    { id = "debris", mod = true },
}
-- CAD buttons, only for SCPD and SCFD members:
local CAD_BUTTONS = {
    { id = "status",  label = "Status" },
    { id = "select",  label = "Next call" },
    { id = "respond", label = "Respond" },
    { id = "break",   label = "Break away" },
    { id = "login",   label = "Log in" },
    { id = "hide",    label = "Hide" },
    { id = "panic",   label = "PANIC" },
}
-- 911, for everyone: one button, which opens a choice of who to send.
local E911_BUTTONS = { { id = "911", label = "Call 911" } }
local E911_PICK = { { id = "911_Police", label = "911: Police" }, { id = "911_EMS", label = "911: EMS" },
                    { id = "911_Fire", label = "911: Fire" }, { id = "911_cancel", label = "Cancel" } }
-- Before logging in, only this one:
local LOGIN_BUTTONS = {
    { id = "login", label = "Log in" },
}
-- Bank buttons, for everyone; which ones show depends on what you are doing.
local BANK_BUTTONS = {
    unlinked = { { id = "bank_link", label = "Link bank" } },
    idle     = { { id = "bank_pay", label = "Pay" }, { id = "bank_charge", label = "Charge" }, { id = "bank_acct", label = "Account" } },
    incoming = { { id = "bank_accept", label = "Accept" }, { id = "bank_decline", label = "Decline" } },
    pay      = { { id = "bank_amt:-1000", label = "-1000" }, { id = "bank_amt:-100", label = "-100" }, { id = "bank_amt:+100", label = "+100" },
                 { id = "bank_amt:+1000", label = "+1000" }, { id = "bank_next", label = "Next player" }, { id = "bank_cancel", label = "Cancel" },
                 { id = "bank_send", label = "Send" } },
}
BANK_BUTTONS.charge = BANK_BUTTONS.pay
-- Shown when a newer mod pack is on the website (or the last download failed).
local UPDATE_BUTTONS = { { id = "update_now", label = "Update mods" } }
local PLAYERS = ROOT .. "\\game_players.txt"

CAD.parts      = CAD.parts or {}           -- tag -> text for that section
CAD.lastLaunch = CAD.lastLaunch or 0
CAD.shown      = {}
CAD.clicks     = 0

local function note(s)
    local f = io.open(LOG, "a")
    if f then f:write(os.date() .. "  " .. s .. "\n") f:close() end
end

-- drop a panel left over from an older version of this logic so it is rebuilt
if CAD.widget then
    local old = CAD.widget
    CAD.widget, CAD.labels, CAD.label, CAD.broken = nil, nil, nil, nil
    ExecuteInGameThread(function() pcall(function() if old:IsValid() then old:RemoveFromParent() end end) end)
end

local function launchBridge()
    CAD.lastLaunch = os.time()
    note("starting the CAD helper")
    os.execute('start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' .. ROOT .. '\\bridge.ps1" -Dir "' .. ROOT .. '"')
end

local function setParts(lines)
    local parts = {}
    local wp = nil
    for _, line in ipairs(lines) do
        local tag, text = line:match("^(%u)|(.*)$")
        if tag == "V" then
            CAD.access = text           -- yes / no / login / relogin, decided by the helper from your Discord roles
            tag = nil
        elseif tag == "Q" then
            CAD.bankMode = text         -- unlinked / idle / incoming / pay / charge
            tag = nil
        elseif tag == "W" then
            -- waypoint: x|y|z|label (game units)
            local x, y, z, label = text:match("^([-%d%.]+)|([-%d%.]+)|([-%d%.]+)|(.*)$")
            if x then wp = { x = tonumber(x), y = tonumber(y), z = tonumber(z), label = label } end
            tag = nil
        elseif tag == "U" then
            -- mod pack update: state|version|message
            local st, ver, msg = text:match("^([^|]*)|([^|]*)|(.*)$")
            st = st or text
            CAD.updateState = st
            if st == "available" then text = "Mod pack update " .. (ver or "") .. " is ready to download."
            elseif st == "downloading" then text = "Downloading the mod pack update..."
            elseif st == "ready" then text = "Update downloaded. It installs when you close Brick Rigs."
            elseif st == "error" then text = "Update failed (" .. (msg or "") .. "). Click Update mods to try again."
            else tag = nil end
        elseif tag == "H" then
            -- headings sit inside the body block, set apart by a blank line
            tag, text = "B", ((parts.B and "\n" or "") .. text)
        end
        if tag then parts[tag] = (parts[tag] and (parts[tag] .. "\n") or "") .. text end
    end
    if not parts.U then CAD.updateState = nil end
    CAD.waypoint = wp
    -- a 911 message shown before the helper answers stays until it does
    if CAD.e911Msg and not parts.E then
        if os.time() - CAD.e911Msg.at < 8 then parts.E = CAD.e911Msg.text else CAD.e911Msg = nil end
    elseif parts.E then CAD.e911Msg = nil end
    -- keep a just-pressed status on screen until the helper catches up
    local p = CAD.pending
    if p then
        if os.time() > p.untilT or parts.M == p.M then CAD.pending = nil else parts.M = p.M end
    end
    CAD.parts = parts
end

-- Off the game thread: read the panel text the helper wrote; (re)start the helper if it has gone quiet.
local function readState(path)
    local s = CAD.readFile(path)
    if not s then return nil end
    return s:match("^%s*(%a+)")
end

function CAD.background()
    -- the other mods' on/off state, shown on their buttons (nil = that mod is not running)
    local now = os.time()
    local pend = CAD.modPending or {}
    local ms = { fire = readState(FIRE_STATE), hose = nil, debris = readState(DEBRIS_STATE) }
    local hs = CAD.readFile(FIRE_STATE)
    if hs then ms.hose = hs:match("hose=(%a+)") or "off" end
    for id, p in pairs(pend) do
        if ms[id] == p.want or now > p.untilT then pend[id] = nil elseif ms[id] ~= nil then ms[id] = p.want end
    end
    CAD.modPending, CAD.modState = pend, ms
    local s = CAD.readFile(PANEL)
    local fresh = false
    if s then
        local ts, rest = s:match("^ts=(%d+)[\r\n]+(.*)$")
        if ts then
            fresh = (os.time() - tonumber(ts)) < 40
            if fresh then
                local lines = {}
                for line in (rest:gsub("\r", "")):gmatch("[^\n]+") do lines[#lines + 1] = line end
                setParts(lines)
            end
        end
    end
    if not fresh and os.time() - CAD.lastLaunch > 60 then launchBridge() end
    if not fresh then
        setParts({ "T|STILTON COUNTY CAD", (os.time() - CAD.lastLaunch > 45) and "B|No data from the CAD helper (see bridge_log.txt)" or "B|Connecting..." })
    end
end

local function command(c)
    local f = io.open(CMD, "a")
    if f then f:write(c .. "\n") f:close() end
end

local function toText(s)
    return StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(s)
end

-- Your own player controller, found once and remembered (searching the whole game for it is costly).
local function localController()
    local pc = CAD.pc
    if pc and pc:IsValid() then return pc end
    CAD.pc = nil
    if CAD.pcSearchAt and os.time() - CAD.pcSearchAt < 3 then return nil end
    CAD.pcSearchAt = os.time()
    for _, c in ipairs(FindAllOf("BrickPlayerController") or {}) do
        if c:IsValid() and c:IsLocalPlayerController() then CAD.pc = c return c end
    end
    return nil
end

-- Screen width in the units the UI is laid out in, and the mouse position in the same units.
local function screenWidth(pc)
    local layout = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
    local size = layout:GetViewportSize(pc)
    local scale = layout:GetViewportScale(pc)
    if not scale or scale <= 0 then scale = 1 end
    return size.X / scale
end
local function mousePos(pc)
    local m = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary"):GetMousePositionOnViewport(pc)
    return m.X, m.Y
end

-- What the screen should show right now: which button rows, and whether the CAD panel is there at all.
-- The mod buttons (fire, hose, solid debris) are for everyone; the CAD is only for SCPD and SCFD members.
local function layout()
    local rows = {}
    local mods = {}
    for _, def in ipairs(MOD_BUTTONS) do
        if CAD.modState and CAD.modState[def.id] ~= nil then mods[#mods + 1] = def end
    end
    if #mods > 0 then rows[#rows + 1] = mods end
    local picking = CAD.e911Until and os.time() < CAD.e911Until
    if picking then
        rows[#rows + 1] = { E911_PICK[1], E911_PICK[2], E911_PICK[3] }
        rows[#rows + 1] = { E911_PICK[4] }
    elseif CAD.bankMode then          -- the helper is running
        rows[#rows + 1] = E911_BUTTONS
    end
    local upd = CAD.updateState
    if upd == "available" or upd == "error" then rows[#rows + 1] = UPDATE_BUTTONS end
    local bank = BANK_BUTTONS[CAD.bankMode or ""] or {}
    for i = 1, #bank, BTN_PER_ROW do
        local row = {}
        for j = i, math.min(i + BTN_PER_ROW - 1, #bank) do row[#row + 1] = bank[j] end
        rows[#rows + 1] = row
    end
    local a = CAD.access
    local cadText = (a == "yes" or a == "login" or a == "relogin")
    local panel = cadText or CAD.bankMode ~= nil
    local cadButtons = (a == "yes") and CAD_BUTTONS or (cadText and LOGIN_BUTTONS or {})
    for i = 1, #cadButtons, BTN_PER_ROW do
        local row = {}
        for j = i, math.min(i + BTN_PER_ROW - 1, #cadButtons) do row[#row + 1] = cadButtons[j] end
        rows[#rows + 1] = row
    end
    local key = tostring(a) .. ":" .. tostring(CAD.bankMode) .. ":" .. tostring(upd) .. ":" .. tostring(picking) .. ":" .. tostring(#mods)
    for _, m in ipairs(mods) do key = key .. m.id end
    return rows, panel, key
end

local function modLabel(id)
    local st = CAD.modState and CAD.modState[id]
    if id == "fire" then return st == "on" and "Fire: real" or "Fire: normal" end
    if id == "hose" then return st == "on" and "Hose: on" or "Hose: off" end
    if id == "debris" then return st == "on" and "Debris: solid" or "Debris: off" end
    return " " .. id .. " "
end

-- The screen is an invisible full-screen layer holding the button rows at known positions in the
-- top-right corner and the info box under them. The mod itself works out which button the mouse is
-- on from those positions, because the game does not report it for widgets made this way.
local function build()
    local gi = CAD.gi
    if not (gi and gi:IsValid()) then
        if CAD.giSearchAt and os.time() - CAD.giSearchAt < 3 then return false end
        CAD.giSearchAt = os.time()
        gi = FindFirstOf("BrickGameInstance")
        CAD.gi = gi
    end
    if not (gi and gi:IsValid()) then return false end
    pcall(function() if CAD.widget and CAD.widget:IsValid() then CAD.widget:RemoveFromParent() end end)
    local pc = localController()
    local W = 1920.0
    if pc then pcall(function() W = screenWidth(pc) end) end
    local rowsDef, showPanel, key = layout()
    local w = StaticConstructObject(StaticFindObject("/Script/UMG.UserWidget"), gi)
    w.WidgetTree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
    local tree = w.WidgetTree
    local textClass = StaticFindObject("/Script/BrickRigs.BrickTextBlock")   -- the game's own text (engine text has no font here)
    local borderClass = StaticFindObject("/Script/BrickRigs.BrickBorder")
    local screen = StaticConstructObject(StaticFindObject("/Script/UMG.Overlay"), tree)
    local BTN_W, BTN_H, BTN_GAP = BTN_W * UI_SCALE, BTN_H * UI_SCALE, BTN_GAP * UI_SCALE
    -- a scale box makes its content (text included) bigger; if it is not available it is shown at normal size
    local function scaled(content)
        local holder = content
        local okS, errS = pcall(function()
            local sb = StaticConstructObject(StaticFindObject("/Script/UMG.ScaleBox"), tree)
            sb:SetStretch(7)                       -- 7 = scale by the number given below
            sb:SetUserSpecifiedScale(UI_SCALE)
            sb:SetContent(content)
            holder = sb
        end)
        if not okS and not CAD.scaleNoted then CAD.scaleNoted = true note("scale box not available: " .. tostring(errS)) end
        return holder
    end

    -- info box (only for players who may see the CAD, or still need to log in)
    local labels = {}
    if showPanel then
        local box = StaticConstructObject(StaticFindObject("/Script/BrickRigs.BrickVerticalBox"), tree)
        for _, sec in ipairs(SECTIONS) do
            local tb = StaticConstructObject(textClass, tree)
            box:AddChildToVerticalBox(tb)
            pcall(function() tb:SetTextStyle(sec.style) end)
            pcall(function() tb:SetColorStyle(sec.color) end)
            labels[sec.tag] = tb
        end
        local panel = StaticConstructObject(borderClass, tree)
        panel:SetContent(box)
        local slot = screen:AddChildToOverlay(UI_SCALE ~= 1.0 and scaled(panel) or panel)
        slot:SetHorizontalAlignment(3)      -- right
        slot:SetVerticalAlignment(1)        -- top
        slot:SetPadding({ Left = 0.0, Top = MARGIN_TOP + #rowsDef * (BTN_H + BTN_GAP) + 2.0, Right = MARGIN_SIDE, Bottom = 0.0 })
    end

    -- buttons, one row at a time, right-aligned
    local buttons = {}
    local rowWidth = BTN_PER_ROW * BTN_W + (BTN_PER_ROW - 1) * BTN_GAP
    local okR, errR = pcall(function()
        for r, row in ipairs(rowsDef) do
            for col0, def in ipairs(row) do
                local col = col0 - 1 + (BTN_PER_ROW - #row)          -- short rows sit at the right edge
                local x = W - MARGIN_SIDE - rowWidth + col * (BTN_W + BTN_GAP)
                local y = MARGIN_TOP + (r - 1) * (BTN_H + BTN_GAP)
                local sizer = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
                sizer:SetWidthOverride(BTN_W)
                sizer:SetHeightOverride(BTN_H)
                local face = StaticConstructObject(borderClass, tree)
                local text = StaticConstructObject(textClass, tree)
                face:SetContent(UI_SCALE ~= 1.0 and scaled(text) or text)
                pcall(function() face:SetHorizontalAlignment(2) end)    -- centre the label
                pcall(function() face:SetVerticalAlignment(2) end)
                sizer:SetContent(face)
                local s = screen:AddChildToOverlay(sizer)
                s:SetHorizontalAlignment(1)     -- left
                s:SetVerticalAlignment(1)       -- top
                s:SetPadding({ Left = x, Top = y, Right = 0.0, Bottom = 0.0 })
                pcall(function() text:SetTextStyle(3) end)            -- small text, so labels fit inside the buttons
                pcall(function() text:SetColorStyle(3) end)
                local label = def.mod and modLabel(def.id) or def.label
                text:SetText(toText(label))
                buttons[#buttons + 1] = { id = def.id, mod = def.mod, x = x, y = y, w = BTN_W, h = BTN_H, text = text, hot = false, label = label }
            end
        end
    end)
    if not okR then note("buttons not available: " .. tostring(errR)) end
    -- waypoint box (moved by CAD.marker)
    pcall(function()
        local mw, mh = 190.0, 26.0
        local sizer = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
        sizer:SetWidthOverride(mw)
        sizer:SetHeightOverride(mh)
        local face = StaticConstructObject(borderClass, tree)
        local text = StaticConstructObject(textClass, tree)
        face:SetContent(text)
        pcall(function() face:SetHorizontalAlignment(2) end)
        pcall(function() face:SetVerticalAlignment(2) end)
        pcall(function() text:SetTextStyle(1) end)
        pcall(function() text:SetColorStyle(4) end)
        sizer:SetContent(face)
        local s = screen:AddChildToOverlay(sizer)
        s:SetHorizontalAlignment(1)
        s:SetVerticalAlignment(1)
        sizer:SetVisibility(2)
        CAD.markerBox = { box = sizer, label = text, slot = s, w = mw, h = mh, shown = false }
    end)
    tree.RootWidget = screen
    w:AddToViewport(60)
    pcall(function() w:SetVisibility(3) end)   -- 3 = shown, but the mouse passes through to the game
    CAD.widget, CAD.labels, CAD.buttons, CAD.shown, CAD.shownVisible, CAD.builtWidth, CAD.builtKey = w, labels, buttons, {}, nil, W, key
    note(string.format("panel created (screen width %.0f, %d buttons, CAD access %s)", W, #buttons, tostring(CAD.access)))
    return true
end

-- Which button, if any, is at this point?
local function buttonAt(mx, my)
    for _, b in ipairs(CAD.buttons or {}) do
        if mx >= b.x and mx <= b.x + b.w and my >= b.y and my <= b.y + b.h then return b end
    end
    return nil
end

-- On the game thread: keep the on-screen panel in step with CAD.parts.
function CAD.draw()
    if CAD.broken then return end
    local ok, err = pcall(function()
        local alive = CAD.widget and CAD.widget:IsValid() and CAD.labels
        if alive then for _, tb in pairs(CAD.labels) do if not tb:IsValid() then alive = false end end end
        -- rebuild when the window size changes (button positions depend on it) or a player first exists
        local pc = localController()
        if alive and pc then
            local okW, W = pcall(screenWidth, pc)
            if okW and math.abs(W - (CAD.builtWidth or 0)) > 1 then alive = false end
        end
        if alive then
            local _, _, key = layout()
            if key ~= CAD.builtKey then alive = false end      -- access or running mods changed
        end
        if not alive and not build() then return end
        if CAD.shownVisible ~= CAD.visible then
            CAD.shownVisible = CAD.visible
            CAD.widget:SetVisibility(CAD.visible and 3 or 1)        -- 3 shown (clicks pass through), 1 collapsed
        end
        local over = nil
        if CAD.mouse and pc then
            local okM, mx, my = pcall(mousePos, pc)
            if okM then over = buttonAt(mx, my) end
        end
        for _, b in ipairs(CAD.buttons or {}) do
            if b.mod then
                local want = modLabel(b.id)
                if want ~= b.label then b.label = want b.text:SetText(toText(want)) end
            elseif b.id == "panic" then
                local armed = CAD.panicArmed and os.time() - CAD.panicArmed <= 4
                local want = armed and "CONFIRM?" or "PANIC"
                if want ~= b.label then b.label = want b.text:SetText(toText(want)) end
            end
            local hot = (b == over)
            if hot ~= b.hot then
                b.hot = hot
                b.text:SetColorStyle(hot and 4 or 3)      -- highlight the button under the cursor
            end
        end
        local a = CAD.access
        local cadText = (a == "yes" or a == "login" or a == "relogin")
        for tag, tb in pairs(CAD.labels) do
            local want = CAD.parts[tag] or ""
            if tag ~= "K" and tag ~= "U" and tag ~= "E" and not cadText then want = "" end
            if CAD.shown[tag] ~= want then
                CAD.shown[tag] = want
                tb:SetText(toText(want))
                tb:SetVisibility(want == "" and 1 or 0)             -- empty sections take no space
            end
        end
    end)
    if not ok then CAD.broken = true note("panel failed, switched off: " .. tostring(err)) end
    pcall(CAD.writePlayers)
    if not CAD.fastMarker then pcall(CAD.marker) end       -- older loader: move the marker here instead
end

-- Where you are in the game (your character, or the vehicle you are driving).
local function myPos(pc)
    local loc = nil
    pcall(function()
        local pawn = pc:K2_GetPawn()
        if pawn and pawn:IsValid() then loc = pawn:K2_GetActorLocation() end
    end)
    if not loc then pcall(function() loc = pc.PlayerCameraManager:GetCameraLocation() end) end
    if not loc then return nil end
    return string.format("%.0f,%.0f,%.0f", loc.X, loc.Y, loc.Z)
end

-- The waypoint: a small box over the call you are on, with the distance. When the call is off
-- screen or behind you, the box sits at the left or right edge pointing the way to turn.
function CAD.marker()
    local m = CAD.markerBox
    if not (m and m.box and m.box:IsValid()) then return end
    local wp = CAD.waypoint
    local pc = localController()
    if not (wp and pc and CAD.visible) then
        if m.shown then m.shown = false m.box:SetVisibility(2) end     -- 2 = hidden
        return
    end
    local cam = pc.PlayerCameraManager
    local c = cam:GetCameraLocation()
    local dx, dy, dz = wp.x - c.X, wp.y - c.Y, wp.z - c.Z
    local dist = math.sqrt(dx * dx + dy * dy + dz * dz) / 100
    local layoutLib = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
    local size = layoutLib:GetViewportSize(pc)
    local scale = layoutLib:GetViewportScale(pc)
    if not scale or scale <= 0 then scale = 1 end
    local W, H = size.X / scale, size.Y / scale
    local yaw = cam:GetCameraRotation().Yaw
    local rel = math.deg(math.atan(dy, dx)) - yaw
    while rel > 180 do rel = rel - 360 end
    while rel < -180 do rel = rel + 360 end
    local sx, sy = nil, nil
    if math.abs(rel) < 85 then
        local okP = pcall(function()
            local out = {}
            if pc:ProjectWorldLocationToScreen({ X = wp.x, Y = wp.y, Z = wp.z }, out, false) and out.X then
                sx, sy = out.X / scale, out.Y / scale
            end
        end)
        if not okP and not CAD.projNoted then CAD.projNoted = true note("waypoint: screen projection not available, using edge arrows only") end
    end
    local text, x, y
    local dtext = dist >= 1000 and string.format("%.1f km", dist / 1000) or string.format("%.0f m", dist)
    if sx and sx >= 0 and sx <= W and sy >= 0 and sy <= H then
        text = "v  " .. wp.label .. "  " .. dtext
        x, y = sx - m.w / 2, sy - m.h - 6
    elseif rel < 0 then
        text = "<<  " .. wp.label .. "  " .. dtext
        x, y = 12, H / 2
    else
        text = wp.label .. "  " .. dtext .. "  >>"
        x, y = W - m.w - 12, H / 2
    end
    x = math.max(0, math.min(W - m.w, x))
    y = math.max(0, math.min(H - m.h, y))
    if text ~= m.text then m.text = text m.label:SetText(toText(text)) end
    local px, py = math.floor(x + 0.5), math.floor(y + 0.5)
    if px ~= m.x or py ~= m.y then
        m.x, m.y = px, py
        m.slot:SetPadding({ Left = px, Top = py, Right = 0.0, Bottom = 0.0 })
    end
    if not m.shown then m.shown = true m.box:SetVisibility(3) end
end

-- Names of the players in this game, for the bank's "pay / charge a player" (the helper matches them
-- to bank accounts). Game thread; every 5 seconds at most, and only once the bank is linked.
function CAD.writePlayers()
    if not CAD.bankMode or CAD.bankMode == "unlinked" then return end
    if CAD.playersAt and os.time() - CAD.playersAt < 5 then return end
    CAD.playersAt = os.time()
    local function nameOf(ps)
        local n = nil
        pcall(function() n = ps:GetPlayerName():ToString() end)
        if not n or n == "" then pcall(function() n = ps.PlayerNamePrivate:ToString() end) end
        if n then n = n:gsub("[\r\n]", " ") end
        return n
    end
    local gs = CAD.gameState
    if not (gs and gs:IsValid()) then
        gs = FindFirstOf("GameStateBase")
        CAD.gameState = gs
    end
    if not (gs and gs:IsValid()) then return end
    local lines = {}
    local pc = localController()
    if pc then
        local okP, ps = pcall(function() return pc.PlayerState end)
        local me = okP and ps and ps:IsValid() and nameOf(ps)
        if me then lines[#lines + 1] = "me=" .. me end
    end
    local arr = gs.PlayerArray
    for i = 1, #arr do
        local okE, ps = pcall(function() return arr[i]:get() end)
        if okE and ps and ps:IsValid() then
            local n = nameOf(ps)
            if n and n ~= "" then lines[#lines + 1] = "p=" .. n end
        end
    end
    local text = table.concat(lines, "\n") .. "\n"
    if text == CAD.playersText then return end
    local f = io.open(PLAYERS, "w")
    if f then f:write(text) f:close() CAD.playersText = text end
end

local STATUSES = { "Available", "En route", "On scene", "Busy" }

-- Show a status change on the panel the moment the key is pressed; the helper confirms it a moment later.
local function showNextStatus()
    local m = CAD.parts and CAD.parts.M
    if not m then return end
    local head, cur = m:match("^(.*|%s+)([%a ]+)$")
    if not head then return end
    for i, st in ipairs(STATUSES) do
        if st == cur then
            local text = head .. STATUSES[(i % #STATUSES) + 1]
            CAD.parts.M = text
            CAD.pending = { M = text, untilT = os.time() + 3 }
            return
        end
    end
end

-- Mouse mode: show the cursor so the panel's buttons can be clicked. Game thread only.
function CAD.setMouse(on)
    CAD.mouse = on
    local ok, err = pcall(function()
        local pc = localController()
        if not pc then return end
        local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
        if on then
            pc.bShowMouseCursor = true
            wbl:SetInputMode_GameAndUIEx(pc, nil, 0, false)
        else
            pc.bShowMouseCursor = false
            wbl:SetInputMode_GameOnly(pc)
        end
    end)
    if not ok then note("mouse mode failed: " .. tostring(err)) end
    if on then CAD.visible = true end
end

-- Every action comes through here, whether from a button or a key. Runs on the game thread.
local function act(name)
    if name == "update_now" then
        command(name)
        CAD.updateState = "downloading"
        if CAD.parts then CAD.parts.U = "Downloading the mod pack update..." end
        return
    end
    if name == "911" then
        CAD.e911Until = os.time() + 20
        pcall(CAD.draw)
        return
    end
    if name == "911_cancel" then
        CAD.e911Until = nil
        pcall(CAD.draw)
        return
    end
    if name:sub(1, 4) == "911_" then
        local dept = name:sub(5)
        local pc = localController()
        local pos = pc and myPos(pc)
        CAD.e911Until = nil
        if pos then
            command("call911|" .. dept .. "|" .. pos)
            CAD.e911Msg = { text = "Calling 911 (" .. dept .. ")...", at = os.time() }
        else
            CAD.e911Msg = { text = "Could not find your position. Try again.", at = os.time() }
        end
        if CAD.parts then CAD.parts.E = CAD.e911Msg.text end
        pcall(CAD.draw)
        return
    end
    if name == "panic" then
        if CAD.panicArmed and os.time() - CAD.panicArmed <= 4 then
            CAD.panicArmed = nil
            local pc = localController()
            local pos = pc and myPos(pc)
            if pos then
                command("panic|" .. pos)
                if CAD.parts then CAD.parts.F = "Sending PANIC..." end
            elseif CAD.parts then CAD.parts.F = "Could not find your position. Try again." end
        else
            CAD.panicArmed = os.time()          -- a second click within 4 seconds sends it
            if CAD.parts then CAD.parts.F = "Click PANIC again to send it." end
        end
        pcall(CAD.draw)
        return
    end
    if name:sub(1, 5) == "bank_" then
        command(name)
        if name == "bank_link" then CAD.setMouse(false) end   -- the browser is about to take over
        return
    end
    if name == "mouse" or name == "toggle" then
        CAD.setMouse(not CAD.mouse)
    elseif name == "hide" then
        CAD.visible = false
        CAD.setMouse(false)
    elseif name == "status" then
        command("status_next")
        showNextStatus()
        if CAD.parts then CAD.parts.F = "Changing status..." end
    elseif name == "respond" then
        command("respond_top")
        if CAD.parts then CAD.parts.F = "Responding..." end
    elseif name == "break" then
        command("break_away")
        if CAD.parts then CAD.parts.F = "Leaving the call..." end
    elseif name == "select" then
        command("select_next")
    elseif name == "login" then
        command("login")
        CAD.setMouse(false)          -- the browser is about to take over
    elseif name == "fire" or name == "hose" or name == "debris" then
        local f = io.open((name == "debris") and DEBRIS_CMD or FIRE_CMD, "a")
        if f then f:write(((name == "fire" or name == "debris") and "toggle" or "hose") .. "\n") f:close() end
        -- show the new state straight away; the mod confirms it a moment later
        local cur = CAD.modState and CAD.modState[name]
        local want = (cur == "on") and "off" or "on"
        CAD.modPending = CAD.modPending or {}
        CAD.modPending[name] = { want = want, untilT = os.time() + 3 }
        if CAD.modState then CAD.modState[name] = want end
    end
    pcall(CAD.draw)
end

-- Safe to call from any thread: the work is handed to the game thread.
function CAD.key(name)
    ExecuteInGameThread(function()
        local ok, err = pcall(act, name)
        if not ok then note("action '" .. tostring(name) .. "' failed: " .. tostring(err)) end
    end)
end

-- Left mouse button: if mouse mode is on and the cursor is over one of our buttons, press it. Game thread only.
function CAD.click()
    if not (CAD.mouse and CAD.visible and CAD.buttons) then return end
    CAD.clicks = (CAD.clicks or 0) + 1
    local pc = localController()
    if not pc then return end
    local okM, mx, my = pcall(mousePos, pc)
    if not okM then
        if CAD.clicks <= 6 then note("click: could not read the mouse position: " .. tostring(mx)) end
        return
    end
    local b = buttonAt(mx, my)
    if CAD.clicks <= 12 then
        local first = CAD.buttons[1]
        note(string.format("click at %.0f,%.0f -> %s (first button at %.0f,%.0f size %.0fx%.0f)", mx, my, b and b.id or "no button",
            first and first.x or -1, first and first.y or -1, first and first.w or 0, first and first.h or 0))
    end
    if b then act(b.id) end
end

if not CAD.keysBound then
    -- fresh game start: only F4 (mouse on/off) and the mouse button are bound
    CAD.keysBound, CAD.selectKeyBound, CAD.loginKeyBound, CAD.mouseBound, CAD.f4Bound = true, true, true, true, true
    RegisterKeyBind(Key.F4, function() CAD.key("mouse") end)
    RegisterKeyBind(Key.LEFT_MOUSE_BUTTON, function() ExecuteInGameThread(function() pcall(CAD.click) end) end)
end
-- game was already running when this version arrived: add the mouse button; older number keys stay until a restart
if not CAD.mouseBound then
    CAD.mouseBound = true
    RegisterKeyBind(Key.LEFT_MOUSE_BUTTON, function() ExecuteInGameThread(function() pcall(CAD.click) end) end)
end
if not CAD.f4Bound then
    CAD.f4Bound = true
    RegisterKeyBind(Key.F4, function() CAD.key("mouse") end)
end

note("logic loaded")
