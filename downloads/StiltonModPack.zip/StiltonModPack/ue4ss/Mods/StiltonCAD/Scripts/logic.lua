-- StiltonCAD logic (re-read by main.lua whenever version.txt changes)
local ROOT = CAD.root
local PANEL = ROOT .. "\\cad_panel.txt"
local CMD   = ROOT .. "\\cad_cmd.txt"
local LOG   = ROOT .. "\\mod_log.txt"

-- Panel sections, top to bottom. style = the game's text style, color = the game's colour style.
--   text styles: 0 default, 1 bold, 3 small, 4 small italic, 5 large    colours: 0 default, 3 secondary, 4 highlight, 6 negative
local SECTIONS = {
    { tag = "T", style = 1, color = 4 },   -- title
    { tag = "M", style = 3, color = 3 },   -- who you are
    { tag = "A", style = 1, color = 6 },   -- panic alerts (bold, warning colour)
    { tag = "B", style = 3, color = 3 },   -- calls and units (headings are folded in here)
    { tag = "F", style = 4, color = 3 },   -- last action + key help
}
local MARGIN_TOP  = 48.0                   -- distance from the top of the screen (clears the Input help button)
local BTN_W, BTN_H, BTN_GAP, BTN_PER_ROW = 104.0, 24.0, 4.0, 3   -- button size and spacing
local MARGIN_SIDE = 10.0                   -- distance from the screen edge

-- Buttons along the bottom of the panel. Press F4 to get the mouse cursor, then click them.
local BUTTONS = {
    { id = "status",  label = " Next status " },
    { id = "select",  label = " Select call " },
    { id = "respond", label = " Respond " },
    { id = "break",   label = " Break away " },
    { id = "login",   label = " Log in " },
    { id = "hide",    label = " Hide " },
}

CAD.parts      = CAD.parts or {}           -- tag -> text for that section
CAD.lastLaunch = CAD.lastLaunch or 0
CAD.shown      = {}
CAD.clicks     = 0

local function note(s)
    local f = io.open(LOG, "a")
    if f then f:write(os.date() .. "  " .. s .. "\n") f:close() end
end

-- drop a panel left over from an older version of this logic so it is rebuilt
if CAD.widget then
    local old = CAD.widget
    CAD.widget, CAD.labels, CAD.label, CAD.broken = nil, nil, nil, nil
    ExecuteInGameThread(function() pcall(function() if old:IsValid() then old:RemoveFromParent() end end) end)
end

local function launchBridge()
    CAD.lastLaunch = os.time()
    note("starting the CAD helper")
    os.execute('start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' .. ROOT .. '\\bridge.ps1" -Dir "' .. ROOT .. '"')
end

local function setParts(lines)
    local parts = {}
    for _, line in ipairs(lines) do
        local tag, text = line:match("^(%u)|(.*)$")
        if tag == "H" then
            -- headings sit inside the body block, set apart by a blank line
            tag, text = "B", ((parts.B and "\n" or "") .. text)
        end
        if tag then parts[tag] = (parts[tag] and (parts[tag] .. "\n") or "") .. text end
    end
    -- keep a just-pressed status on screen until the helper catches up
    local p = CAD.pending
    if p then
        if os.time() > p.untilT or parts.M == p.M then CAD.pending = nil else parts.M = p.M end
    end
    CAD.parts = parts
end

-- Off the game thread: read the panel text the helper wrote; (re)start the helper if it has gone quiet.
function CAD.background()
    local s = CAD.readFile(PANEL)
    local fresh = false
    if s then
        local ts, rest = s:match("^ts=(%d+)[\r\n]+(.*)$")
        if ts then
            fresh = (os.time() - tonumber(ts)) < 40
            if fresh then
                local lines = {}
                for line in (rest:gsub("\r", "")):gmatch("[^\n]+") do lines[#lines + 1] = line end
                setParts(lines)
            end
        end
    end
    if not fresh and os.time() - CAD.lastLaunch > 60 then launchBridge() end
    if not fresh then
        setParts({ "T|STILTON COUNTY CAD", (os.time() - CAD.lastLaunch > 45) and "B|No data from the CAD helper (see bridge_log.txt)" or "B|Connecting..." })
    end
end

local function command(c)
    local f = io.open(CMD, "a")
    if f then f:write(c .. "\n") f:close() end
end

local function toText(s)
    return StaticFindObject("/Script/Engine.Default__KismetTextLibrary"):Conv_StringToText(s)
end

local function localController()
    for _, pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
        if pc:IsValid() and pc:IsLocalPlayerController() then return pc end
    end
    return nil
end

-- Screen width in the units the UI is laid out in, and the mouse position in the same units.
local function screenWidth(pc)
    local layout = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
    local size = layout:GetViewportSize(pc)
    local scale = layout:GetViewportScale(pc)
    if not scale or scale <= 0 then scale = 1 end
    return size.X / scale
end
local function mousePos(pc)
    local m = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary"):GetMousePositionOnViewport(pc)
    return m.X, m.Y
end

-- The panel is an invisible full-screen layer holding (a) two rows of buttons at known positions in the
-- top-right corner and (b) the info box under them. The mod itself works out which button the mouse is
-- on from those positions, because the game does not report it for widgets made this way.
local function build()
    local gi = FindFirstOf("BrickGameInstance")
    if not (gi and gi:IsValid()) then return false end
    pcall(function() if CAD.widget and CAD.widget:IsValid() then CAD.widget:RemoveFromParent() end end)
    local pc = localController()
    local W = 1920.0
    if pc then pcall(function() W = screenWidth(pc) end) end
    local w = StaticConstructObject(StaticFindObject("/Script/UMG.UserWidget"), gi)
    w.WidgetTree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
    local tree = w.WidgetTree
    local textClass = StaticFindObject("/Script/BrickRigs.BrickTextBlock")   -- the game's own text (engine text has no font here)
    local borderClass = StaticFindObject("/Script/BrickRigs.BrickBorder")
    local screen = StaticConstructObject(StaticFindObject("/Script/UMG.Overlay"), tree)

    -- info box
    local labels = {}
    local box = StaticConstructObject(StaticFindObject("/Script/BrickRigs.BrickVerticalBox"), tree)
    for _, sec in ipairs(SECTIONS) do
        local tb = StaticConstructObject(textClass, tree)
        box:AddChildToVerticalBox(tb)
        pcall(function() tb:SetTextStyle(sec.style) end)
        pcall(function() tb:SetColorStyle(sec.color) end)
        labels[sec.tag] = tb
    end
    local panel = StaticConstructObject(borderClass, tree)
    panel:SetContent(box)
    local rows = math.ceil(#BUTTONS / BTN_PER_ROW)
    local slot = screen:AddChildToOverlay(panel)
    slot:SetHorizontalAlignment(3)      -- right
    slot:SetVerticalAlignment(1)        -- top
    slot:SetPadding({ Left = 0.0, Top = MARGIN_TOP + rows * (BTN_H + BTN_GAP) + 2.0, Right = MARGIN_SIDE, Bottom = 0.0 })

    -- buttons
    local buttons = {}
    local rowWidth = BTN_PER_ROW * BTN_W + (BTN_PER_ROW - 1) * BTN_GAP
    local okR, errR = pcall(function()
        for i, def in ipairs(BUTTONS) do
            local col = (i - 1) % BTN_PER_ROW
            local row = math.floor((i - 1) / BTN_PER_ROW)
            local x = W - MARGIN_SIDE - rowWidth + col * (BTN_W + BTN_GAP)
            local y = MARGIN_TOP + row * (BTN_H + BTN_GAP)
            local sizer = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
            sizer:SetWidthOverride(BTN_W)
            sizer:SetHeightOverride(BTN_H)
            local face = StaticConstructObject(borderClass, tree)
            local text = StaticConstructObject(textClass, tree)
            face:SetContent(text)
            pcall(function() face:SetHorizontalAlignment(2) end)    -- centre the label
            pcall(function() face:SetVerticalAlignment(2) end)
            sizer:SetContent(face)
            local s = screen:AddChildToOverlay(sizer)
            s:SetHorizontalAlignment(1)     -- left
            s:SetVerticalAlignment(1)       -- top
            s:SetPadding({ Left = x, Top = y, Right = 0.0, Bottom = 0.0 })
            pcall(function() text:SetTextStyle(3) end)
            pcall(function() text:SetColorStyle(3) end)
            text:SetText(toText(def.label))
            buttons[#buttons + 1] = { id = def.id, x = x, y = y, w = BTN_W, h = BTN_H, text = text, hot = false }
        end
    end)
    if not okR then note("buttons not available: " .. tostring(errR)) end
    tree.RootWidget = screen
    w:AddToViewport(60)
    pcall(function() w:SetVisibility(3) end)   -- 3 = shown, but the mouse passes through to the game
    CAD.widget, CAD.labels, CAD.buttons, CAD.shown, CAD.shownVisible, CAD.builtWidth = w, labels, buttons, {}, nil, W
    note(string.format("panel created (screen width %.0f, %d buttons)", W, #buttons))
    return true
end

-- Which button, if any, is at this point?
local function buttonAt(mx, my)
    for _, b in ipairs(CAD.buttons or {}) do
        if mx >= b.x and mx <= b.x + b.w and my >= b.y and my <= b.y + b.h then return b end
    end
    return nil
end

-- On the game thread: keep the on-screen panel in step with CAD.parts.
function CAD.draw()
    if CAD.broken then return end
    local ok, err = pcall(function()
        local alive = CAD.widget and CAD.widget:IsValid() and CAD.labels
        if alive then for _, tb in pairs(CAD.labels) do if not tb:IsValid() then alive = false end end end
        -- rebuild when the window size changes (button positions depend on it) or a player first exists
        local pc = localController()
        if alive and pc then
            local okW, W = pcall(screenWidth, pc)
            if okW and math.abs(W - (CAD.builtWidth or 0)) > 1 then alive = false end
        end
        if not alive and not build() then return end
        if CAD.shownVisible ~= CAD.visible then
            CAD.shownVisible = CAD.visible
            CAD.widget:SetVisibility(CAD.visible and 3 or 1)        -- 3 shown (clicks pass through), 1 collapsed
        end
        local over = nil
        if CAD.mouse and pc then
            local okM, mx, my = pcall(mousePos, pc)
            if okM then over = buttonAt(mx, my) end
        end
        for _, b in ipairs(CAD.buttons or {}) do
            local hot = (b == over)
            if hot ~= b.hot then
                b.hot = hot
                b.text:SetColorStyle(hot and 4 or 3)      -- highlight the button under the cursor
            end
        end
        for tag, tb in pairs(CAD.labels) do
            local want = CAD.parts[tag] or ""
            if CAD.shown[tag] ~= want then
                CAD.shown[tag] = want
                tb:SetText(toText(want))
                tb:SetVisibility(want == "" and 1 or 0)             -- empty sections take no space
            end
        end
    end)
    if not ok then CAD.broken = true note("panel failed, switched off: " .. tostring(err)) end
end

local STATUSES = { "Available", "En route", "On scene", "Busy" }

-- Show a status change on the panel the moment the key is pressed; the helper confirms it a moment later.
local function showNextStatus()
    local m = CAD.parts and CAD.parts.M
    if not m then return end
    local head, cur = m:match("^(.*|%s+)([%a ]+)$")
    if not head then return end
    for i, st in ipairs(STATUSES) do
        if st == cur then
            local text = head .. STATUSES[(i % #STATUSES) + 1]
            CAD.parts.M = text
            CAD.pending = { M = text, untilT = os.time() + 3 }
            return
        end
    end
end

-- Mouse mode: show the cursor so the panel's buttons can be clicked. Game thread only.
function CAD.setMouse(on)
    CAD.mouse = on
    local ok, err = pcall(function()
        local pc = localController()
        if not pc then return end
        local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
        if on then
            pc.bShowMouseCursor = true
            wbl:SetInputMode_GameAndUIEx(pc, nil, 0, false)
        else
            pc.bShowMouseCursor = false
            wbl:SetInputMode_GameOnly(pc)
        end
    end)
    if not ok then note("mouse mode failed: " .. tostring(err)) end
    if on then CAD.visible = true end
end

-- Every action comes through here, whether from a button or a key. Runs on the game thread.
local function act(name)
    if name == "mouse" or name == "toggle" then
        CAD.setMouse(not CAD.mouse)
    elseif name == "hide" then
        CAD.visible = false
        CAD.setMouse(false)
    elseif name == "status" then
        command("status_next")
        showNextStatus()
        if CAD.parts then CAD.parts.F = "Changing status..." end
    elseif name == "respond" then
        command("respond_top")
        if CAD.parts then CAD.parts.F = "Responding..." end
    elseif name == "break" then
        command("break_away")
        if CAD.parts then CAD.parts.F = "Leaving the call..." end
    elseif name == "select" then
        command("select_next")
    elseif name == "login" then
        command("login")
        CAD.setMouse(false)          -- the browser is about to take over
    end
    pcall(CAD.draw)
end

-- Safe to call from any thread: the work is handed to the game thread.
function CAD.key(name)
    ExecuteInGameThread(function()
        local ok, err = pcall(act, name)
        if not ok then note("action '" .. tostring(name) .. "' failed: " .. tostring(err)) end
    end)
end

-- Left mouse button: if mouse mode is on and the cursor is over one of our buttons, press it. Game thread only.
function CAD.click()
    if not (CAD.mouse and CAD.visible and CAD.buttons) then return end
    CAD.clicks = (CAD.clicks or 0) + 1
    local pc = localController()
    if not pc then return end
    local okM, mx, my = pcall(mousePos, pc)
    if not okM then
        if CAD.clicks <= 6 then note("click: could not read the mouse position: " .. tostring(mx)) end
        return
    end
    local b = buttonAt(mx, my)
    if CAD.clicks <= 12 then
        local first = CAD.buttons[1]
        note(string.format("click at %.0f,%.0f -> %s (first button at %.0f,%.0f size %.0fx%.0f)", mx, my, b and b.id or "no button",
            first and first.x or -1, first and first.y or -1, first and first.w or 0, first and first.h or 0))
    end
    if b then act(b.id) end
end

if not CAD.keysBound then
    -- fresh game start: only F4 (mouse on/off) and the mouse button are bound
    CAD.keysBound, CAD.selectKeyBound, CAD.loginKeyBound, CAD.mouseBound, CAD.f4Bound = true, true, true, true, true
    RegisterKeyBind(Key.F4, function() CAD.key("mouse") end)
    RegisterKeyBind(Key.LEFT_MOUSE_BUTTON, function() ExecuteInGameThread(function() pcall(CAD.click) end) end)
end
-- game was already running when this version arrived: add the mouse button; older number keys stay until a restart
if not CAD.mouseBound then
    CAD.mouseBound = true
    RegisterKeyBind(Key.LEFT_MOUSE_BUTTON, function() ExecuteInGameThread(function() pcall(CAD.click) end) end)
end
if not CAD.f4Bound then
    CAD.f4Bound = true
    RegisterKeyBind(Key.F4, function() CAD.key("mouse") end)
end

note("logic loaded")
