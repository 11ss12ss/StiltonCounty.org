-- StiltonCAD for Brick Rigs (UE4SS Lua mod) - loader
-- Shows the Stilton County CAD (calls, units, panic alerts) in a panel on screen.
-- The data is fetched by bridge.ps1 (a small background helper this mod starts), because a game
-- script cannot talk to the internet itself. Behaviour lives in logic.lua and is re-read when
-- version.txt changes.
-- Press F4 for the mouse cursor, then click the panel's buttons.

local ROOT = [[C:\Program Files (x86)\Steam\steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64\ue4ss\Mods\StiltonCAD]]
CAD = CAD or { visible = true }
pcall(function()
    local here = debug.getinfo(1, "S").source:match("^@?(.*)[\\/][Ss]cripts[\\/][^\\/]+$")
    local f = here and io.open(here .. "\\Scripts\\main.lua", "r")
    if f then f:close() else here = nil end
    if here then ROOT = here:gsub("/", "\\") end
end)
CAD.root = ROOT
local loadedVersion = nil
local queuedAt = 0
local markerQueued = 0
local tickN = 0
CAD.fastMarker = true

local function readFile(p)
    -- never throws: a file that is being written by the helper at the same moment just reads as nil
    local ok, s = pcall(function()
        local f = io.open(p, "r")
        if not f then return nil end
        local okR, t = pcall(function() return f:read("*a") end)
        pcall(function() f:close() end)
        return okR and t or nil
    end)
    return ok and s or nil
end
CAD.readFile = readFile

local function tick()
    -- the waypoint moves 10 times a second; everything else 3 times a second
    tickN = tickN + 1
    if CAD.marker and CAD.waypoint and (markerQueued == 0 or os.time() - markerQueued > 4) then
        markerQueued = os.time()
        ExecuteInGameThread(function() pcall(CAD.marker) markerQueued = 0 end)
    end
    if tickN % 3 ~= 0 then return false end
    -- this part runs off the game thread: file reading and starting the helper never stall the game
    local v = readFile(ROOT .. "\\Scripts\\version.txt") or "none"
    if v ~= loadedVersion then
        loadedVersion = v
        local ok, err = pcall(dofile, ROOT .. "\\Scripts\\logic.lua")
        if not ok then print("[StiltonCAD] logic error: " .. tostring(err) .. "\n") end
    end
    if CAD.background then pcall(CAD.background) end
    -- drawing has to happen on the game thread
    if CAD.draw and (queuedAt == 0 or os.time() - queuedAt > 4) then
        queuedAt = os.time()
        ExecuteInGameThread(function() pcall(CAD.draw) queuedAt = 0 end)
    end
    return false
end

-- an error inside the loop would stop it for good (the panel freezes), so every tick is protected
LoopAsync(100, function()
    local ok, err = pcall(tick)
    if not ok then print("[StiltonCAD] tick error: " .. tostring(err) .. "\n") end
    return false
end)

print("[StiltonCAD] loaded\n")
