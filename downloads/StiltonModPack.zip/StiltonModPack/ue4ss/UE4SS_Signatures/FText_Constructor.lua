-- Placeholder: UE4SS 3.0.1 cannot find FText's constructor in Brick Rigs and refuses to start without one.
-- No mod here builds FText values, so this just points at an unrelated unique function to let startup continue.
function Register()
    return "48 89 5C 24 08 57 48 83 EC 20 33 C9 FF 15 E6 B2 D3 02 33 D2 33 C9 FF 15"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
