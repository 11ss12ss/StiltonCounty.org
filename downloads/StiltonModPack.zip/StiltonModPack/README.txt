Stilton Mod Pack for Brick Rigs
===============================
Republic of Stilton (ROS) - one download with all four of our Brick Rigs mods.

What is in it
  Solid Debris    Bricks that break off a build are solid in multiplayer, like in singleplayer.
                  A dust cloud plays where a build breaks apart.            Key 9 = off/on
  Realistic Fire  Fire burns longer, climbs, follows materials (wood burns, metal does not),
                  weakens buildings until burned parts give way, and throws tall smoke.
                  Key 8 = off/on. Key 7 = switch the extinguisher to a long-reach fire hose.
  Medical         Injuries heal far more slowly, and a badly hurt character blacks out
                  until they recover or someone helps them.
  Stilton CAD     The Stilton County CAD on screen: calls, units, your status, panic alerts.
                  Press F4 for the mouse cursor, then click the panel's buttons.
                  Click Login once to sign in with Discord.

Who needs it
  Solid Debris, Realistic Fire and Medical change the game for everyone only when the HOST runs them.
  Stilton CAD works for anyone who installs it, host or not.

Install (easy way)
  1. Close Brick Rigs.
  2. Extract this whole zip to a folder (right-click the zip > Extract All).
  3. Double-click "Install.bat". It finds your Brick Rigs folder and copies the mods in.
     Windows may ask whether to run it because it came from the internet; choose Run / More info > Run anyway.
  4. Start the game. The first start takes about a minute longer than usual.

Install (by hand, if you prefer)
  1. Close Brick Rigs.
  2. In Steam: right-click Brick Rigs > Manage > Browse local files, then open BrickRigs > Binaries > Win64.
  3. Copy "dwmapi.dll" and the "ue4ss" folder from this zip into that Win64 folder
     (they sit next to BrickRigsSteam-Win64-Shipping.exe).

Switching one mod off for good
  Open ue4ss\Mods\mods.txt in the Win64 folder and change the 1 after that mod's name to 0.

Remove
  Double-click "Uninstall.bat", or delete "dwmapi.dll" and the "ue4ss" folder from the Win64 folder by hand.

Good to know
  - This uses UE4SS, an unofficial script loader for Unreal Engine games (MIT licence, included).
    It is not made or supported by the Brick Rigs developers, and a game update can break it.
  - Made for Brick Rigs 1.11.8. If the game will not start after an update, remove the pack.
  - Stilton CAD runs a small hidden PowerShell helper while the game is open. It talks to the
    Stilton County site's database and closes itself when the game closes.
  - Bigger flames and smoke columns are only drawn on the host's screen.
  - Each mod keeps a small log (status.txt / mod_log.txt) in its folder under ue4ss\Mods.
