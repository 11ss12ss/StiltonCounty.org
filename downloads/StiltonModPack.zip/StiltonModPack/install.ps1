# Stilton Mod Pack for Brick Rigs - installer. Run it with "Install.bat".
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$MODS = @('SolidDebris', 'RealisticFire', 'StiltonCAD', 'Medical')
function Finish($code) { Write-Host ''; Read-Host 'Press Enter to close' | Out-Null; exit $code }

Write-Host ''
Write-Host '  Stilton Mod Pack for Brick Rigs - installer' -ForegroundColor Cyan
Write-Host ''

if (-not (Test-Path (Join-Path $here 'ue4ss\UE4SS.dll'))) {
    Write-Host 'The mod files are not next to this installer.' -ForegroundColor Yellow
    Write-Host 'Extract the whole zip to a folder first (right-click the zip > Extract All), then run Install.bat from there.'
    Finish 1
}

# Is this the folder with the game's program in it? (the program name differs between copies of the game)
function Test-Win64($w) {
    if (-not $w -or -not (Test-Path -LiteralPath $w -PathType Container)) { return $false }
    return [bool](Get-ChildItem -LiteralPath $w -Filter 'BrickRigs*-Win64-Shipping.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1)
}

# Turn whatever folder the user pasted into the game's Binaries\Win64 folder.
# Accepts the game folder, the BrickRigs folder inside it, Binaries, Win64, or the path of a file in any of them.
function Resolve-Win64($typed) {
    if (-not $typed) { return $null }
    $p = $typed.Trim().Trim('"').Trim("'").Trim().TrimEnd('\', '/')
    if (-not $p) { return $null }
    if (Test-Path -LiteralPath $p -PathType Leaf) { $p = Split-Path -Parent $p }
    $dir = $p
    for ($i = 0; $i -lt 6 -and $dir; $i++) {
        foreach ($c in @($dir, (Join-Path $dir 'Win64'), (Join-Path $dir 'Binaries\Win64'), (Join-Path $dir 'BrickRigs\Binaries\Win64'))) {
            if (Test-Win64 $c) { return $c }
        }
        $dir = Split-Path -Parent $dir
    }
    return $null
}

# Find Brick Rigs through Steam's list of library folders, then the usual places on every drive.
function Find-Game {
    $roots = @()
    foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        try {
            $p = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($n in 'SteamPath', 'InstallPath') {
                if (($p.PSObject.Properties.Name -contains $n) -and $p.$n) { $roots += ($p.$n -replace '/', '\') }
            }
        } catch {}
    }
    $libs = @()
    foreach ($r in ($roots | Select-Object -Unique)) {
        $libs += $r
        foreach ($vdf in @((Join-Path $r 'steamapps\libraryfolders.vdf'), (Join-Path $r 'config\libraryfolders.vdf'))) {
            if (Test-Path -LiteralPath $vdf) {
                foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
            }
        }
    }
    try {
        foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction Stop)) {
            $root = $d.Root
            foreach ($sub in 'SteamLibrary', 'Steam', 'Games\Steam', 'Games\SteamLibrary', 'Program Files (x86)\Steam', 'Program Files\Steam') {
                $libs += (Join-Path $root $sub)
            }
        }
    } catch {}
    foreach ($l in ($libs | Select-Object -Unique)) {
        $w = Join-Path $l 'steamapps\common\Brick Rigs\BrickRigs\Binaries\Win64'
        if (Test-Win64 $w) { return $w }
    }
    return $null
}

$win64 = Find-Game
while (-not $win64) {
    Write-Host 'Could not find Brick Rigs automatically.' -ForegroundColor Yellow
    Write-Host 'In Steam: right-click Brick Rigs > Manage > Browse local files, click the address bar at the top of'
    Write-Host 'that window, copy the folder path, then paste it here (right-click pastes) and press Enter.'
    Write-Host 'Leave it empty and press Enter to give up.'
    $typed = Read-Host 'Brick Rigs folder'
    if (-not $typed -or -not $typed.Trim()) { Write-Host 'Nothing was changed.'; Finish 1 }
    $win64 = Resolve-Win64 $typed
    if (-not $win64) { Write-Host "Brick Rigs is not in that folder: $typed" -ForegroundColor Red; Write-Host '' }
}
Write-Host "Brick Rigs found at: $win64"

if (Get-Process -Name 'BrickRigs*-Win64-Shipping' -ErrorAction SilentlyContinue) {
    Write-Host 'Brick Rigs is running. Close the game, then run Install.bat again. Nothing was changed.' -ForegroundColor Yellow
    Finish 1
}

try {
    $target = Join-Path $win64 'ue4ss'
    if (Test-Path (Join-Path $target 'UE4SS.dll')) {
        # A script loader is already installed: leave it and its other mods alone, just add this mod.
        Write-Host 'A UE4SS loader is already installed here - keeping it and adding the mods to it.'
        foreach ($mod in $MODS) {
            Copy-Item -Path (Join-Path $here "ue4ss\Mods\$mod") -Destination (Join-Path $target 'Mods') -Recurse -Force
            $txt = Join-Path $target 'Mods\mods.txt'
            if ((Test-Path $txt) -and ((Get-Content $txt -Raw) -notmatch "(?m)^\s*$mod\s*:")) {
                [IO.File]::WriteAllText($txt, "$mod : 1`r`n" + (Get-Content $txt -Raw))
            }
            $json = Join-Path $target 'Mods\mods.json'
            if (Test-Path $json) {
                $list = @(Get-Content $json -Raw | ConvertFrom-Json)
                if (-not ($list | Where-Object { $_.mod_name -eq $mod })) {
                    $list = @([pscustomobject]@{ mod_name = $mod; mod_enabled = $true }) + $list
                    [IO.File]::WriteAllText($json, (ConvertTo-Json -InputObject $list -Depth 4))
                }
            }
        }
    } else {
        Copy-Item -Path (Join-Path $here 'dwmapi.dll') -Destination $win64 -Force
        Copy-Item -Path (Join-Path $here 'ue4ss') -Destination $win64 -Recurse -Force
        [IO.File]::WriteAllText((Join-Path $target 'installed_by_StiltonModPack.txt'), 'The UE4SS loader in this folder was installed by the Stilton Mod Pack installer.')
    }
} catch {
    Write-Host ''
    Write-Host "Could not copy the files: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'If it says access is denied: right-click Install.bat > Run as administrator.'
    Finish 1
}

Write-Host ''
Write-Host 'Installed.' -ForegroundColor Green
Write-Host 'Start Brick Rigs (the first start takes about a minute longer).'
Write-Host 'In game: press F4 for the mouse cursor, then use the buttons in the top-right corner.'
Write-Host 'To remove it later, run Uninstall.bat.'
Finish 0
